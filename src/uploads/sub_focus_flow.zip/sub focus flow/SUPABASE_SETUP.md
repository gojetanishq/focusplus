# Supabase Setup Guide for FocusFlow

## Step 1: Create a Supabase Project

1. Go to [https://supabase.com](https://supabase.com)
2. Sign up or log in
3. Click "New Project"
4. Fill in:
   - **Name**: FocusFlow (or your preferred name)
   - **Database Password**: Choose a strong password (save it!)
   - **Region**: Choose closest to your users
5. Click "Create new project"
6. Wait for the project to be set up (takes ~2 minutes)

## Step 2: Get Your API Credentials

1. In your Supabase project dashboard, go to **Settings** → **API**
2. Copy these values:
   - **Project URL** (under "Project URL")
   - **anon/public key** (under "Project API keys")

## Step 3: Set Up Environment Variables

1. In your project root, create a `.env` file (or edit the existing one)
2. Add your Supabase credentials:

```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

3. **Important**: Never commit `.env` to git! It's already in `.gitignore`

## Step 4: Create Database Tables

1. In Supabase dashboard, go to **SQL Editor**
2. Click "New query"
3. Copy and paste the entire contents of `supabase/schema.sql`
4. Click "Run" (or press Ctrl+Enter)
5. You should see "Success. No rows returned"

## Step 5: Set Up Authentication (Optional but Recommended)

### Option A: Email/Password Authentication

1. Go to **Authentication** → **Providers**
2. Enable "Email" provider
3. Configure email templates if needed

### Option B: Magic Link (Passwordless)

1. Go to **Authentication** → **Providers**
2. Enable "Email" provider
3. Enable "Enable email confirmations" if you want verification

### Option C: Social Auth (Google, GitHub, etc.)

1. Go to **Authentication** → **Providers**
2. Enable your preferred provider
3. Follow the setup instructions for each provider

## Step 6: Set Up Storage (For File Uploads)

1. Go to **Storage** in Supabase dashboard
2. Click "Create a new bucket"
3. Name it: `files`
4. Make it **Public** (or Private if you prefer)
5. Click "Create bucket"

### Set Storage Policies (if bucket is Private)

Go to **Storage** → **Policies** → `files` bucket and add:

```sql
-- Allow authenticated users to upload files
CREATE POLICY "Users can upload own files"
ON storage.objects FOR INSERT
WITH CHECK (auth.uid()::text = (storage.foldername(name))[1]);

-- Allow users to view own files
CREATE POLICY "Users can view own files"
ON storage.objects FOR SELECT
USING (auth.uid()::text = (storage.foldername(name))[1]);

-- Allow users to delete own files
CREATE POLICY "Users can delete own files"
ON storage.objects FOR DELETE
USING (auth.uid()::text = (storage.foldername(name))[1]);
```

## Step 7: Test the Connection

1. Restart your dev server:
   ```bash
   npm run dev
   ```

2. Open your app in the browser
3. Check the browser console for any Supabase connection errors
4. If you see warnings about missing credentials, double-check your `.env` file

## Step 8: Migrate Existing Data (Optional)

If you have existing data in localStorage:

1. The app will automatically use Supabase once configured
2. Existing localStorage data will remain until you clear it
3. To migrate manually, you can export from localStorage and import to Supabase

## Troubleshooting

### "User not authenticated" warnings
- Make sure you've set up authentication in Supabase
- Users need to sign up/login before data can be saved

### "No table mapping for key" warnings
- Check that you've run the schema.sql script
- Verify tables exist in Supabase dashboard → **Table Editor**

### Connection errors
- Verify your `.env` file has correct values
- Make sure `.env` is in the project root (not in `src/`)
- Restart your dev server after changing `.env`

### RLS (Row Level Security) errors
- All tables have RLS enabled for security
- Make sure users are authenticated before accessing data
- Check that RLS policies were created (they're in schema.sql)

## Next Steps

1. ✅ Set up Supabase project
2. ✅ Configure environment variables
3. ✅ Create database tables
4. ✅ Set up authentication
5. ✅ Test the connection
6. 🚀 Start using your app with Supabase!

## Useful Links

- [Supabase Documentation](https://supabase.com/docs)
- [Supabase JavaScript Client](https://supabase.com/docs/reference/javascript/introduction)
- [Supabase Auth Guide](https://supabase.com/docs/guides/auth)
- [Supabase Storage Guide](https://supabase.com/docs/guides/storage)

## Support

If you encounter issues:
1. Check the browser console for errors
2. Check Supabase dashboard → **Logs** for server-side errors
3. Verify all environment variables are set correctly
4. Make sure you've run the schema.sql script

