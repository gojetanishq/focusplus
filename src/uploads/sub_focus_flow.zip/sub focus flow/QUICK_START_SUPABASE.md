# Quick Start: Supabase Integration

## 🚀 5-Minute Setup

### Step 1: Create Supabase Project
1. Go to [supabase.com](https://supabase.com) and sign up/login
2. Click "New Project"
3. Fill in project details and wait ~2 minutes

### Step 2: Get Your Credentials
1. Go to **Settings** → **API**
2. Copy:
   - **Project URL**
   - **anon/public key**

### Step 3: Configure Environment
1. Create `.env` file in project root:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

### Step 4: Create Database Tables
1. In Supabase dashboard → **SQL Editor**
2. Click "New query"
3. Copy entire contents of `supabase/schema.sql`
4. Click "Run"

### Step 5: Set Up Auth (Choose One)

**Option A: Email/Password**
- Go to **Authentication** → **Providers**
- Enable "Email" provider

**Option B: Magic Link (Passwordless)**
- Enable "Email" provider
- Users get login links via email

**Option C: Social Auth**
- Enable Google/GitHub/etc.
- Follow provider setup instructions

### Step 6: Test It!
1. Restart dev server: `npm run dev`
2. Open app in browser
3. Sign up/login
4. Create a task - it should save to Supabase! 🎉

## ✅ That's It!

Your app now uses Supabase for:
- ✅ Tasks
- ✅ Study Sessions
- ✅ Files
- ✅ User Stats
- ✅ All data synced across devices

## 🔄 How It Works

- **Without Supabase**: Uses localStorage (works offline, single device)
- **With Supabase**: Uses database (syncs across devices, requires auth)

The app automatically detects if Supabase is configured and switches accordingly!

## 🆘 Troubleshooting

**"User not authenticated"**
→ Set up authentication in Supabase

**"No table mapping"**
→ Run `supabase/schema.sql` in SQL Editor

**Connection errors**
→ Check `.env` file has correct values

**Need help?**
→ See `SUPABASE_SETUP.md` for detailed guide

