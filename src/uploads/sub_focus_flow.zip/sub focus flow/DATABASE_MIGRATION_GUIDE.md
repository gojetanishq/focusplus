# Database Migration Guide

## Current Setup
- **Storage**: localStorage (via Context API)
- **Status**: ✅ Working perfectly for development

## When to Migrate
Migrate to a database when you need:
- ✅ Multi-device sync
- ✅ User authentication & multi-user support
- ✅ Data backup & recovery
- ✅ Large file storage
- ✅ Real-time collaboration
- ✅ Production deployment

## Migration Steps (When Ready)

### Step 1: Choose Your Database
Popular options:
- **Firebase** - Easy setup, real-time sync
- **Supabase** - PostgreSQL, open-source Firebase alternative
- **MongoDB Atlas** - NoSQL, flexible schema
- **PostgreSQL** - SQL, robust & scalable
- **PocketBase** - Self-hosted, simple setup

### Step 2: Update Storage Adapter
1. Open `src/services/storage.ts`
2. Replace `LocalStorageAdapter` with `DatabaseAdapter`
3. Update the `DatabaseAdapter` implementation with your API calls

```typescript
// In src/services/storage.ts
const storage: StorageAdapter = new DatabaseAdapter('https://your-api.com');
```

### Step 3: Update Context Files
Your contexts already use the storage service, so they'll automatically work with the database!

### Step 4: Add Authentication
- Add user authentication (Firebase Auth, Supabase Auth, etc.)
- Update storage keys to include user ID: `tasks_${userId}`

### Step 5: Test Migration
1. Export localStorage data
2. Import to database
3. Verify all features work

## Current Data Structure

### Tasks
```typescript
{
  id: number;
  text: string;
  completed: boolean;
}
```

### Study Sessions
```typescript
{
  id: string;
  examId: string;
  subject: string;
  topic: string;
  date: string; // yyyy-MM-dd
  duration: number; // minutes
  completed: boolean;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}
```

### Files
```typescript
{
  id: number;
  name: string;
  size: string;
  type: string;
  subject: string;
  date: string; // ISO string
}
```

## Recommended Database Schema (PostgreSQL Example)

```sql
-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Tasks table
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  text TEXT NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Study sessions table
CREATE TABLE study_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  exam_id UUID,
  subject VARCHAR(255),
  topic TEXT,
  date DATE NOT NULL,
  duration INTEGER,
  completed BOOLEAN DEFAULT FALSE,
  difficulty VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Files table
CREATE TABLE files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  size VARCHAR(50),
  type VARCHAR(100),
  subject VARCHAR(255),
  file_url TEXT, -- URL to actual file storage (S3, etc.)
  created_at TIMESTAMP DEFAULT NOW()
);
```

## Quick Migration Checklist
- [ ] Choose database provider
- [ ] Set up database/backend
- [ ] Update `storage.ts` adapter
- [ ] Add authentication
- [ ] Update storage keys with user IDs
- [ ] Test all CRUD operations
- [ ] Migrate existing localStorage data
- [ ] Deploy and test in production

---

**For now**: Keep building features! The abstraction layer is ready when you need it. 🚀

