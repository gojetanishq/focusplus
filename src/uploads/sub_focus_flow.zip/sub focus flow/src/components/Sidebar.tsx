
import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, CheckSquare, FolderOpen, Trophy, Settings, LogOut, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { buttonHover } from '@/lib/motion';
import { ThemeToggle } from './theme/ThemeToggle';
import { useAuth } from '@/context/AuthContext';

export default function Sidebar() {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/landing' },
    { icon: BookOpen, label: 'Study Planner', path: '/study' },
    { icon: CheckSquare, label: 'Tasks', path: '/tasks' },
    { icon: FolderOpen, label: 'Files', path: '/files' },
    { icon: Trophy, label: 'Achievements', path: '/achievements' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  return (
    <nav
      className={cn(
        "relative flex flex-col justify-between py-6 z-20 transition-all duration-300 border-r border-gray-200 dark:border-white/5 bg-white/95 dark:bg-[#0a0b1e]/95 backdrop-blur-xl",
        isCollapsed ? "w-20" : "w-20 lg:w-64"
      )}
    >
      {/* Collapse Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-8 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full p-1 text-gray-500 dark:text-gray-400 hover:text-indigo-500 transition-colors shadow-sm hidden lg:block z-50"
      >
        {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>

      <div className="space-y-8">
        {/* Logo */}
        <div className={cn("flex items-center gap-3 px-3", isCollapsed ? "justify-center" : "lg:justify-start lg:px-6")}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 shrink-0">
            <span className="font-bold text-xl text-white">F</span>
          </div>
          {!isCollapsed && (
            <span className="hidden lg:block font-bold text-xl tracking-tight text-gray-900 dark:text-white truncate">
              FocusPlus
            </span>
          )}
        </div>

        {/* Nav Items */}
        <div className="space-y-2 px-3">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              title={isCollapsed ? item.label : undefined}
              className={({ isActive }) => cn(
                "relative flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group",
                isActive
                  ? "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400"
                  : "text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 hover:text-gray-900 dark:hover:text-gray-200",
                isCollapsed && "justify-center"
              )}
            >
              {({ isActive }) => (
                <>
                  {isActive && (
                    <motion.div
                      layoutId="activePill"
                      className="absolute left-0 w-1 h-8 bg-indigo-500 rounded-r-full"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}

                  <item.icon size={22} className={cn("relative z-10 shrink-0", isActive && "text-indigo-400")} />

                  {!isCollapsed && (
                    <span className="hidden lg:block font-medium relative z-10 truncate">{item.label}</span>
                  )}
                </>
              )}
            </NavLink>
          ))}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="px-3 space-y-3">
        <div className={cn("w-full flex", isCollapsed ? "justify-center" : "lg:justify-start lg:px-2")}>
          <div className={cn("transition-all duration-300", isCollapsed ? "scale-75" : "scale-100")}>
            <ThemeToggle />
          </div>
        </div>
        <motion.button
          variants={buttonHover}
          initial="rest"
          whileHover="hover"
          whileTap="tap"
          onClick={handleLogout}
          title={isCollapsed ? "Log Out" : undefined}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-3 rounded-xl text-gray-400 hover:bg-red-500/10 hover:text-red-400 transition-colors",
            isCollapsed && "justify-center"
          )}
        >
          <LogOut size={22} className="shrink-0" />
          {!isCollapsed && (
            <span className="hidden lg:block font-medium truncate">Log Out</span>
          )}
        </motion.button>
      </div>
    </nav>
  );
}
