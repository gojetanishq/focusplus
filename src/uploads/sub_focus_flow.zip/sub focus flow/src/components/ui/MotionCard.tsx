import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';
import { cardEnter } from '@/lib/motion';

interface MotionCardProps extends HTMLMotionProps<"div"> {
    glass?: boolean;
}

const MotionCard = React.forwardRef<HTMLDivElement, MotionCardProps>(
    ({ className, glass = true, children, variants = cardEnter, ...props }, ref) => {
        return (
            <motion.div
                ref={ref}
                variants={variants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className={cn(
                    "rounded-2xl p-6",
                    glass && "bg-white/60 dark:bg-white/10 backdrop-blur-md border border-gray-200 dark:border-white/10 shadow-lg dark:shadow-xl",
                    !glass && "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700",
                    className
                )}
                {...props}
            >
                {children}
            </motion.div>
        );
    }
);

MotionCard.displayName = "MotionCard";
export default MotionCard;
