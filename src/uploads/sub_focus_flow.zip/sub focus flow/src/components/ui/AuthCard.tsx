import React from 'react';
import { motion } from 'framer-motion';
import MotionCard from './MotionCard';
import { float } from '@/lib/motion';

interface AuthCardProps {
    children: React.ReactNode;
    title: string;
    subtitle: string;
}

export default function AuthCard({ children, title, subtitle }: AuthCardProps) {
    return (
        <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[#0a0b1e] overflow-hidden relative">
            {/* Background Blobs */}
            <motion.div
                variants={float}
                animate="animate"
                className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] -z-10"
            />
            <motion.div
                variants={float}
                animate="animate"
                transition={{ delay: 2 }}
                className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px] -z-10"
            />

            <MotionCard className="w-full max-w-md relative z-10">
                <div className="text-center mb-8">
                    <h1 className="text-3xl font-bold text-white mb-2">{title}</h1>
                    <p className="text-gray-400">{subtitle}</p>
                </div>
                {children}
            </MotionCard>
        </div>
    );
}
