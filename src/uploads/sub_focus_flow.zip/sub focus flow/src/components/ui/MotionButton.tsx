import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';
import { buttonHover } from '@/lib/motion';

interface MotionButtonProps extends HTMLMotionProps<"button"> {
    variant?: 'primary' | 'secondary' | 'ghost' | 'outline';
    size?: 'sm' | 'md' | 'lg';
}

const MotionButton = React.forwardRef<HTMLButtonElement, MotionButtonProps>(
    ({ className, variant = 'primary', size = 'md', children, ...props }, ref) => {

        const variants = {
            primary: "bg-indigo-500 hover:bg-indigo-400 text-white shadow-lg shadow-indigo-500/30",
            secondary: "bg-gray-700 hover:bg-gray-600 text-white",
            ghost: "bg-transparent hover:bg-white/5 text-gray-300 hover:text-white",
            outline: "bg-transparent border border-gray-600 hover:border-gray-500 text-gray-300 hover:text-white",
        };

        const sizes = {
            sm: "px-3 py-1.5 text-sm",
            md: "px-6 py-3 text-base",
            lg: "px-8 py-4 text-lg font-semibold",
        };

        return (
            <motion.button
                ref={ref}
                variants={buttonHover}
                initial="rest"
                whileHover="hover"
                whileTap="tap"
                className={cn(
                    "rounded-xl font-medium flex items-center justify-center transition-colors",
                    variants[variant],
                    sizes[size],
                    className
                )}
                {...props}
            >
                {children}
            </motion.button>
        );
    }
);

MotionButton.displayName = "MotionButton";
export default MotionButton;
