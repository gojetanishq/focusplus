
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Clock, BookOpen, BarChart, Sparkles, BrainCircuit, CheckCircle2, AlertCircle } from 'lucide-react';
import MotionButton from '@/components/ui/MotionButton';
import DifficultyDisplay from '@/components/ai/DifficultyDisplay';

interface AddSessionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onAdd: (session: any) => void;
    selectedDate: Date | null;
}

export default function AddSessionModal({ isOpen, onClose, onAdd, selectedDate }: AddSessionModalProps) {
    const [title, setTitle] = useState('');
    const [time, setTime] = useState('10:00');
    const [duration, setDuration] = useState('60');
    const [type, setType] = useState('Self-Study');
    const [difficulty, setDifficulty] = useState('Medium');

    // AI State
    const [xaiResult, setXaiResult] = useState<any>(null);

    // Reset form when opening
    useEffect(() => {
        if (isOpen) {
            setTitle('');
            setTime('10:00');
            setDuration('60');
            setType('Self-Study');
            setDifficulty('Medium');
            setXaiResult(null);
        }
    }, [isOpen]);

    const handleAnalyze = (result: any) => {
        setXaiResult(result);
        // Auto-select difficulty based on label
        const difficultyLabel = result.difficulty?.toLowerCase() || result.difficulty_label?.toLowerCase() || 'medium';
        if (difficultyLabel.includes('very_hard') || difficultyLabel.includes('hard')) {
            setDifficulty('High');
        } else if (difficultyLabel.includes('medium')) {
            setDifficulty('Medium');
        } else {
            setDifficulty('Low');
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (title.trim() && selectedDate) {
            // Create a date object with the selected time
            const [hours, minutes] = time.split(':').map(Number);
            const sessionDate = new Date(selectedDate);
            sessionDate.setHours(hours, minutes);

            onAdd({
                id: Date.now().toString(),
                title,
                date: sessionDate,
                duration: `${duration}m`,
                type,
                difficulty,
                // Attach full AI Metadata if available
                aiReasoning: xaiResult ? {
                    score: xaiResult.difficulty_score,
                    reasoning_summary: xaiResult.reasoning_summary,
                    reasoning_signals: xaiResult.provenance?.reasoning_signals || [],
                    sources: xaiResult.sources || [],
                    confidence: xaiResult.confidence
                } : undefined
            });
            onClose();
        }
    };

    const formatDate = (date: Date | null) => {
        if (!date) return '';
        return date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    {/* Backdrop */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
                    />

                    {/* Modal */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
                    >
                        <div className="bg-white dark:bg-gray-900 w-full max-w-lg rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 pointer-events-auto flex flex-col max-h-[90vh]">
                            <form onSubmit={handleSubmit} className="flex flex-col h-full">
                                <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 rounded-t-2xl shrink-0">
                                    <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                                        <Calendar size={18} className="text-indigo-500" />
                                        {selectedDate ? 'Plan Session' : 'New Session'}
                                    </h3>
                                    <button
                                        type="button"
                                        onClick={onClose}
                                        className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>

                                <div className="p-6 space-y-4 overflow-y-auto custom-scrollbar flex-1">
                                    {selectedDate && (
                                        <div className="text-sm text-indigo-500 font-medium bg-indigo-50 dark:bg-indigo-500/10 px-3 py-2 rounded-lg inline-block w-full text-center">
                                            {formatDate(selectedDate)}
                                        </div>
                                    )}

                                    <div className="space-y-2">
                                        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Subject / Topic</label>
                                        <div className="flex gap-2">
                                            <input
                                                type="text"
                                                value={title}
                                                onChange={(e) => setTitle(e.target.value)}
                                                placeholder="e.g. Linear Algebra Chapter 3"
                                                className="flex-1 px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white transition-all"
                                                autoFocus
                                            />
                                            <button
                                                type="button"
                                                onClick={handleAnalyze}
                                                className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white transition-colors"
                                            >
                                                Analyze
                                            </button>
                                        </div>
                                    </div>

                                    {/* AI Difficulty Analysis */}
                                    {title.trim() && (
                                        <div className="mt-4">
                                            <DifficultyDisplay 
                                                topic={title} 
                                                autoAnalyze={false}
                                                onAnalyze={handleAnalyze}
                                            />
                                        </div>
                                    )}

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1"><Clock size={14} /> Start Time</label>
                                            <input
                                                type="time"
                                                value={time}
                                                onChange={(e) => setTime(e.target.value)}
                                                className="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white transition-all"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Duration (min)</label>
                                            <select
                                                value={duration}
                                                onChange={(e) => setDuration(e.target.value)}
                                                className="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white transition-all"
                                            >
                                                <option value="30">30 min</option>
                                                <option value="45">45 min</option>
                                                <option value="60">1 Hour</option>
                                                <option value="90">1.5 Hours</option>
                                                <option value="120">2 Hours</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1"><BookOpen size={14} /> Type</label>
                                            <select
                                                value={type}
                                                onChange={(e) => setType(e.target.value)}
                                                className="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white transition-all"
                                            >
                                                <option value="Self-Study">Self-Study</option>
                                                <option value="Lecture">Lecture</option>
                                                <option value="Lab">Lab</option>
                                                <option value="Exam">Exam / Quiz</option>
                                            </select>
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1"><BarChart size={14} /> Difficulty</label>
                                            <select
                                                value={difficulty}
                                                onChange={(e) => setDifficulty(e.target.value)}
                                                className="w-full px-4 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white transition-all"
                                            >
                                                <option value="High">High (AI Focus)</option>
                                                <option value="Medium">Medium</option>
                                                <option value="Low">Low</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div className="p-4 border-t border-gray-200 dark:border-gray-800 flex justify-end gap-3 bg-gray-50 dark:bg-gray-900 rounded-b-2xl shrink-0">
                                    <MotionButton variant="ghost" type="button" onClick={onClose}>
                                        Cancel
                                    </MotionButton>
                                    <MotionButton type="submit">
                                        Add Session
                                    </MotionButton>
                                </div>
                            </form>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
}
