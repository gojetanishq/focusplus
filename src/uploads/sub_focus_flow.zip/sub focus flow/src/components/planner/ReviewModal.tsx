import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, Send } from 'lucide-react';
import MotionButton from '@/components/ui/MotionButton';
import { apoxApiWithFallback } from '@/services/apoxApi';

interface ReviewModalProps {
    isOpen: boolean;
    onClose: () => void;
    sessionTitle: string;
    sessionTopic?: string;
    onReviewSubmitted?: () => void;
}

export default function ReviewModal({ isOpen, onClose, sessionTitle, sessionTopic, onReviewSubmitted }: ReviewModalProps) {
    const [rating, setRating] = useState<number>(5);
    const [comment, setComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!sessionTitle.trim()) return;

        setIsSubmitting(true);
        try {
            // Convert 1-10 rating to difficulty string
            const difficultyMap: Record<number, string> = {
                1: 'very_easy',
                2: 'very_easy',
                3: 'easy',
                4: 'easy',
                5: 'medium',
                6: 'medium',
                7: 'hard',
                8: 'hard',
                9: 'very_hard',
                10: 'very_hard',
            };

            const difficulty = difficultyMap[rating] || 'medium';

            await apoxApiWithFallback.submitReview({
                topic: sessionTopic || sessionTitle,
                user_id: 'current_user', // Replace with actual user ID from auth context
                difficulty: difficulty,
                review_text: comment.trim() || `Rated ${rating}/10 for difficulty`,
                rating: rating,
            });

            // Reset form
            setRating(5);
            setComment('');
            
            onReviewSubmitted?.();
            onClose();
        } catch (error) {
            console.error('Failed to submit review:', error);
            alert('Failed to submit review. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    const getRatingLabel = (value: number) => {
        if (value <= 2) return 'Very Easy';
        if (value <= 4) return 'Easy';
        if (value <= 6) return 'Medium';
        if (value <= 8) return 'Hard';
        return 'Very Hard';
    };

    const getRatingColor = (value: number) => {
        if (value <= 2) return 'text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400';
        if (value <= 4) return 'text-green-500 bg-green-50 dark:bg-green-900/20 dark:text-green-400';
        if (value <= 6) return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20 dark:text-yellow-400';
        if (value <= 8) return 'text-orange-600 bg-orange-50 dark:bg-orange-900/20 dark:text-orange-400';
        return 'text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400';
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    {/* Backdrop */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
                    />

                    {/* Modal */}
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
                    >
                        <div className="bg-white dark:bg-gray-900 w-full max-w-md rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 pointer-events-auto">
                            <form onSubmit={handleSubmit} className="p-6">
                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
                                        Rate Your Experience
                                    </h3>
                                    <button
                                        type="button"
                                        onClick={onClose}
                                        className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors"
                                    >
                                        <X size={20} />
                                    </button>
                                </div>

                                <div className="mb-4">
                                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Course/Session:</p>
                                    <p className="font-medium text-gray-900 dark:text-white">{sessionTitle}</p>
                                </div>

                                {/* Rating Scale */}
                                <div className="mb-6">
                                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 block">
                                        Difficulty Rating (1-10)
                                    </label>
                                    
                                    {/* Star Rating Display */}
                                    <div className="flex items-center gap-2 mb-4">
                                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((value) => (
                                            <button
                                                key={value}
                                                type="button"
                                                onClick={() => setRating(value)}
                                                className={`transition-all ${
                                                    value <= rating
                                                        ? 'text-yellow-400 scale-110'
                                                        : 'text-gray-300 dark:text-gray-600'
                                                }`}
                                            >
                                                <Star
                                                    size={24}
                                                    fill={value <= rating ? 'currentColor' : 'none'}
                                                    className="hover:scale-125 transition-transform"
                                                />
                                            </button>
                                        ))}
                                    </div>

                                    {/* Number Input */}
                                    <div className="flex items-center gap-4">
                                        <input
                                            type="range"
                                            min="1"
                                            max="10"
                                            value={rating}
                                            onChange={(e) => setRating(Number(e.target.value))}
                                            className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                                        />
                                        <div className="flex items-center gap-2 min-w-[120px]">
                                            <span className={`text-2xl font-bold px-3 py-1 rounded-lg ${getRatingColor(rating)}`}>
                                                {rating}
                                            </span>
                                            <span className="text-sm text-gray-500 dark:text-gray-400">/10</span>
                                        </div>
                                    </div>

                                    {/* Rating Label */}
                                    <div className="mt-2">
                                        <span className={`text-sm font-semibold px-3 py-1 rounded-full ${getRatingColor(rating)}`}>
                                            {getRatingLabel(rating)}
                                        </span>
                                    </div>
                                </div>

                                {/* Comment */}
                                <div className="mb-6">
                                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                                        Additional Comments (Optional)
                                    </label>
                                    <textarea
                                        value={comment}
                                        onChange={(e) => setComment(e.target.value)}
                                        placeholder="Share your thoughts about the difficulty, what helped you, or any tips for others..."
                                        className="w-full min-h-[100px] px-4 py-3 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white resize-none"
                                    />
                                </div>

                                {/* Actions */}
                                <div className="flex justify-end gap-3">
                                    <MotionButton
                                        type="button"
                                        variant="ghost"
                                        onClick={onClose}
                                        disabled={isSubmitting}
                                    >
                                        Skip
                                    </MotionButton>
                                    <MotionButton
                                        type="submit"
                                        disabled={isSubmitting}
                                    >
                                        {isSubmitting ? (
                                            <>
                                                <Send size={16} className="mr-2 animate-pulse" />
                                                Submitting...
                                            </>
                                        ) : (
                                            <>
                                                <Send size={16} className="mr-2" />
                                                Submit Review
                                            </>
                                        )}
                                    </MotionButton>
                                </div>
                            </form>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
}

