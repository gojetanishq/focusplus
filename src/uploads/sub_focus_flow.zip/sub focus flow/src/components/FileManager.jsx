import React, { useRef } from 'react';
import { useFiles } from '../context/FileContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FileText, Image, File, Trash2, Folder } from 'lucide-react';

export function FileManager() {
  const { files, addFile, deleteFile } = useFiles();
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      addFile(file);
    }
  };

  const getFileIcon = (type) => {
    if (type.includes('image')) return <Image className="w-8 h-8 text-purple-500" />;
    if (type.includes('pdf')) return <FileText className="w-8 h-8 text-red-500" />;
    return <File className="w-8 h-8 text-blue-500" />;
  };

  return (
    <div className="space-y-8">
      <div 
        onClick={() => fileInputRef.current?.click()}
        className="border-2 border-dashed border-gray-300 dark:border-dark-border rounded-2xl p-12 text-center hover:border-primary-500 hover:bg-primary-50 dark:hover:bg-primary-900/10 transition-all cursor-pointer group"
      >
        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          onChange={handleFileChange}
        />
        <div className="w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
          <Upload className="w-8 h-8 text-primary-600 dark:text-primary-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Click to upload files</h3>
        <p className="text-gray-500 dark:text-gray-400 mt-2">PDFs, Images, and Documents</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Folder className="w-5 h-5 text-yellow-500" />
          Recent Files
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {files.map((file) => (
              <motion.div
                key={file.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                layout
                className="bg-white dark:bg-dark-surface p-4 rounded-xl border border-gray-200 dark:border-dark-border shadow-sm hover:shadow-md transition-all group relative"
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-gray-50 dark:bg-dark-bg rounded-lg">
                    {getFileIcon(file.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium truncate text-gray-900 dark:text-gray-100">{file.name}</h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {file.size} • {new Date(file.date).toLocaleDateString()}
                    </p>
                    <span className="inline-block mt-2 px-2 py-1 bg-gray-100 dark:bg-dark-border rounded text-xs text-gray-600 dark:text-gray-300">
                      {file.subject}
                    </span>
                  </div>
                </div>
                
                <button
                  onClick={() => deleteFile(file.id)}
                  className="absolute top-2 right-2 p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        
        {files.length === 0 && (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            No files uploaded yet.
          </div>
        )}
      </div>
    </div>
  );
}
