
import { motion } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import { float } from '@/lib/motion';

export default function HeroCard() {
    return (
        <MotionCard className="relative overflow-hidden bg-gradient-to-br from-indigo-600 to-purple-700 text-white min-h-[300px] flex items-center justify-between">
            {/* Background Shapes */}
            <motion.div
                variants={float}
                animate="animate"
                className="absolute -top-20 -right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"
            />
            <motion.div
                variants={float}
                animate="animate"
                transition={{ delay: 1.5 }}
                className="absolute -bottom-20 -left-20 w-48 h-48 bg-indigo-400/20 rounded-full blur-2xl"
            />

            <div className="z-10 max-w-lg">
                <h1 className="text-4xl font-bold mb-2">Welcome back, Traveler!</h1>
                <p className="text-indigo-100 mb-6">You're on a <span className="font-bold text-white">5-day streak</span>. Keep the momentum flowing!</p>

                <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 inline-block border border-white/20">
                    <p className="text-xs uppercase tracking-wider text-indigo-200 mb-1">Next Session</p>
                    <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                        <span className="font-semibold text-lg">Linear Algebra</span>
                        <span className="text-indigo-200 text-sm ml-2">in 15 mins</span>
                    </div>
                </div>
            </div>

            {/* XP Ring Visualization */}
            <div className="relative z-10 hidden md:flex items-center justify-center mr-8">
                <div className="relative w-40 h-40">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="8" />
                        <motion.circle
                            cx="50"
                            cy="50"
                            r="45"
                            fill="none"
                            stroke="white"
                            strokeWidth="8"
                            strokeLinecap="round"
                            initial={{ pathLength: 0 }}
                            animate={{ pathLength: 0.75 }}
                            transition={{ duration: 1.5, ease: "easeOut" }}
                        />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-3xl font-bold">Lvl 12</span>
                        <span className="text-xs text-indigo-200">2,450 XP</span>
                    </div>
                </div>
            </div>
        </MotionCard>
    );
}
