
import MotionButton from '@/components/ui/MotionButton';
import { LucideIcon } from 'lucide-react';

interface QuickActionProps {
    icon: LucideIcon;
    label: string;
    color: string;
    onClick?: () => void;
}

export default function QuickAction({ icon: Icon, label, color, onClick }: QuickActionProps) {
    return (
        <MotionButton
            variant="ghost"
            className="flex-col gap-3 h-auto py-6 bg-white dark:bg-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700/50 hover:border-gray-300 dark:hover:border-gray-600 w-full shadow-sm dark:shadow-none"
            onClick={onClick}
        >
            <div className={`p-3 rounded-xl bg-opacity-20 ${color} text-white`}>
                <Icon size={24} />
            </div>
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
        </MotionButton>
    );
}
