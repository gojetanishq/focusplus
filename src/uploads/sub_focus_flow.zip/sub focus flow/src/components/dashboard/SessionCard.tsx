import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import MotionButton from '@/components/ui/MotionButton';
import ReviewModal from '@/components/planner/ReviewModal';
import { cn } from '@/lib/utils';
import { Clock, Book, CheckCircle, ChevronDown, ChevronUp, BrainCircuit, TrendingUp, BookOpen, ExternalLink } from 'lucide-react';

interface AIReasoning {
    score?: number;
    reasoning?: string | string[];
    confidence?: number;
    reasoning_summary?: string[];
    reasoning_signals?: string[];
    sources?: Array<{
        title: string;
        url?: string;
        type?: string;
        quote?: string;
    }>;
}

interface SessionCardProps {
    title: string;
    duration: string;
    difficulty: 'Easy' | 'Medium' | 'Hard';
    time: string;
    aiReasoning?: AIReasoning;
}

export default function SessionCard({ title, duration, difficulty, time, aiReasoning }: SessionCardProps) {
    const [isExpanded, setIsExpanded] = useState(false);
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [isCompleted, setIsCompleted] = useState(false);
    
    const difficultyColors = {
        Easy: "bg-green-500/20 text-green-700 dark:text-green-300 border-green-500/30",
        Medium: "bg-yellow-500/20 text-yellow-700 dark:text-yellow-300 border-yellow-500/30",
        Hard: "bg-red-500/20 text-red-700 dark:text-red-300 border-red-500/30",
    };

    const reasoningSummary = aiReasoning?.reasoning_summary || 
        (aiReasoning?.reasoning ? (Array.isArray(aiReasoning.reasoning) ? aiReasoning.reasoning : [aiReasoning.reasoning]) : null);

    return (
        <MotionCard
            className="group bg-white dark:bg-gray-900/40 hover:bg-gray-50 dark:hover:bg-gray-800/80 transition-colors border-b border-gray-100 dark:border-gray-800"
            glass={false}
            whileHover={{ scale: 1.01 }}
        >
            <div className="flex items-center justify-between p-4">
                <div className="flex items-center gap-4 flex-1">
                    <div className="h-12 w-12 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-colors duration-300">
                        <Book size={20} />
                    </div>
                    <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 dark:text-gray-100">{title}</h3>
                        <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mt-1">
                            <span className="flex items-center gap-1"><Clock size={12} /> {time} ({duration})</span>
                            {aiReasoning && reasoningSummary ? (
                                <button
                                    onClick={() => setIsExpanded(!isExpanded)}
                                    className={cn(
                                        "text-xs px-2 py-0.5 rounded-full border flex items-center gap-1 cursor-pointer hover:opacity-80 transition-opacity",
                                        difficultyColors[difficulty]
                                    )}
                                >
                                    {difficulty}
                                    {isExpanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                                </button>
                            ) : (
                                <span className={cn("text-xs px-2 py-0.5 rounded-full border", difficultyColors[difficulty])}>
                                    {difficulty}
                                </span>
                            )}
                        </div>
                    </div>
                </div>

                <MotionButton
                    variant="ghost"
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => {
                        if (!isCompleted) {
                            setIsCompleted(true);
                            setIsReviewModalOpen(true);
                        }
                    }}
                >
                    <CheckCircle size={18} />
                </MotionButton>
            </div>

            {/* AI Reasoning Details */}
            <AnimatePresence>
                {isExpanded && aiReasoning && reasoningSummary && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                    >
                        <div className="px-4 pb-4 pt-2 border-t border-gray-100 dark:border-gray-800 space-y-4">
                            {/* Difficulty Score */}
                            {aiReasoning.score !== undefined && (
                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Difficulty Score</span>
                                        <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">{aiReasoning.score}/100</span>
                                    </div>
                                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                                        <motion.div
                                            initial={{ width: 0 }}
                                            animate={{ width: `${aiReasoning.score}%` }}
                                            transition={{ duration: 0.5 }}
                                            className={`h-full ${
                                                aiReasoning.score >= 75 ? 'bg-red-500' :
                                                aiReasoning.score >= 50 ? 'bg-orange-500' :
                                                aiReasoning.score >= 25 ? 'bg-yellow-500' : 'bg-green-500'
                                            }`}
                                        />
                                    </div>
                                </div>
                            )}

                            {/* Reasoning Summary */}
                            {reasoningSummary.length > 0 && (
                                <div className="bg-indigo-50 dark:bg-indigo-500/10 rounded-lg p-3 border border-indigo-100 dark:border-indigo-500/20">
                                    <h4 className="text-xs font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-1">
                                        <BrainCircuit size={14} className="text-indigo-600 dark:text-indigo-400" />
                                        Why {difficulty}?
                                    </h4>
                                    <ul className="space-y-1.5">
                                        {reasoningSummary.map((reason, idx) => (
                                            <li key={idx} className="flex items-start gap-2 text-xs text-gray-700 dark:text-gray-300">
                                                <span className="text-indigo-500 mt-0.5">•</span>
                                                <span>{reason}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}

                            {/* Reasoning Signals */}
                            {aiReasoning.reasoning_signals && aiReasoning.reasoning_signals.length > 0 && (
                                <div>
                                    <h4 className="text-xs font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-1">
                                        <TrendingUp size={14} className="text-indigo-600 dark:text-indigo-400" />
                                        Reasoning Signals
                                    </h4>
                                    <div className="flex flex-wrap gap-1.5">
                                        {aiReasoning.reasoning_signals.map((signal, idx) => (
                                            <span
                                                key={idx}
                                                className="px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 rounded-full text-[10px] font-medium"
                                            >
                                                {signal.replace(/_/g, ' ')}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Sources */}
                            {aiReasoning.sources && aiReasoning.sources.length > 0 && (
                                <div>
                                    <h4 className="text-xs font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-1">
                                        <BookOpen size={14} className="text-indigo-600 dark:text-indigo-400" />
                                        Resources Used
                                    </h4>
                                    <div className="space-y-2">
                                        {aiReasoning.sources.map((source, idx) => (
                                            <div
                                                key={idx}
                                                className="p-2 bg-gray-50 dark:bg-[#0f1115] rounded-lg border border-gray-200 dark:border-gray-800"
                                            >
                                                <div className="flex items-start justify-between">
                                                    <div className="flex-1 min-w-0">
                                                        <h5 className="font-semibold text-xs text-gray-900 dark:text-white truncate">
                                                            {source.title}
                                                        </h5>
                                                        {source.quote && (
                                                            <p className="text-[10px] text-gray-600 dark:text-gray-400 italic mt-0.5 line-clamp-2">
                                                                "{source.quote}"
                                                            </p>
                                                        )}
                                                        {source.type && (
                                                            <span className="text-[10px] px-1.5 py-0.5 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded mt-1 inline-block">
                                                                {source.type}
                                                            </span>
                                                        )}
                                                    </div>
                                                    {source.url && (
                                                        <a
                                                            href={source.url}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            className="ml-2 p-1 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 rounded shrink-0"
                                                        >
                                                            <ExternalLink size={12} />
                                                        </a>
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Confidence */}
                            {aiReasoning.confidence !== undefined && (
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                    <span className="font-medium">Confidence:</span> {(aiReasoning.confidence * 100).toFixed(0)}%
                                </div>
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <ReviewModal
                isOpen={isReviewModalOpen}
                onClose={() => setIsReviewModalOpen(false)}
                sessionTitle={title}
                sessionTopic={title}
                onReviewSubmitted={() => {
                    setIsReviewModalOpen(false);
                }}
            />
        </MotionCard>
    );
}
