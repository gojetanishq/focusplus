
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Notebook, Plus, Trash2, ZoomIn, ZoomOut, Minimize2, ArrowLeft, Bot, Sparkles, BrainCircuit, Lightbulb } from 'lucide-react';
import { aiMock } from '@/services/aiMock';
import MotionButton from '@/components/ui/MotionButton';

interface FilePreviewModalProps {
    isOpen: boolean;
    onClose: () => void;
    file: { name: string; type: string; url?: string; size?: string } | null;
}

// Extracted Component to prevent re-renders losing focus
const FilePreviewContent = ({ file, onClose }: { file: NonNullable<FilePreviewModalProps['file']>, onClose: () => void }) => {
    const [activeTab, setActiveTab] = useState<'notes' | 'ai'>('notes');
    const [notes, setNotes] = useState<string[]>([]);
    const [currentNote, setCurrentNote] = useState('');
    const [zoom, setZoom] = useState(1);

    // AI State
    const [aiSummary, setAiSummary] = useState<string[] | null>(null);
    const [aiFlashcards, setAiFlashcards] = useState<{ q: string, a: string }[] | null>(null);
    const [isLoadingAI, setIsLoadingAI] = useState(false);

    const isImage = file.type === 'img' || file.name.match(/\.(jpg|jpeg|png|gif|webp)$/i);
    const isPDF = file.type === 'pdf' || file.name.endsWith('.pdf');

    const handleAddNote = (e?: React.FormEvent) => {
        e?.preventDefault();
        if (currentNote.trim()) {
            setNotes([...notes, currentNote]);
            setCurrentNote('');
        }
    };

    const deleteNote = (index: number) => {
        setNotes(notes.filter((_, i) => i !== index));
    };

    const generateSummary = async () => {
        setIsLoadingAI(true);
        const summary = await aiMock.generateFileSummary(file.name);
        setAiSummary(summary);
        setIsLoadingAI(false);
    };

    const generateFlashcards = async () => {
        setIsLoadingAI(true);
        const cards = await aiMock.generateFlashcards(file.name);
        setAiFlashcards(cards);
        setIsLoadingAI(false);
    };

    return (
        <motion.div
            key="modal"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", bounce: 0, duration: 0.3 }}
            className="fixed inset-0 z-[9999] bg-[#0a0b10] flex flex-col overflow-hidden text-white"
        >
            {/* Top Bar */}
            <header className="h-16 flex items-center justify-between px-6 border-b border-white/10 bg-[#0f1115]">
                <div className="flex items-center gap-4">
                    <button
                        onClick={onClose}
                        className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group"
                    >
                        <div className="p-2 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors">
                            <ArrowLeft size={18} />
                        </div>
                        <span className="font-medium text-sm hidden md:block">Back</span>
                    </button>
                    <div className="h-6 w-px bg-white/10 mx-2 hidden md:block" />
                    <div className="flex items-center gap-3">
                        <div className="p-1.5 rounded bg-indigo-500/20 text-indigo-400">
                            <FileText size={16} />
                        </div>
                        <div>
                            <h1 className="font-bold text-sm md:text-base leading-tight">{file.name}</h1>
                            <p className="text-[10px] md:text-xs text-gray-500 font-mono tracking-wide">AI STUDY MODE</p>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full border border-white/5">
                        <button onClick={() => setZoom(Math.max(0.5, zoom - 0.1))} className="p-1 text-gray-400 hover:text-white transition-colors"><ZoomOut size={14} /></button>
                        <span className="text-xs font-mono w-8 text-center">{Math.round(zoom * 100)}%</span>
                        <button onClick={() => setZoom(Math.min(3, zoom + 0.1))} className="p-1 text-gray-400 hover:text-white transition-colors"><ZoomIn size={14} /></button>
                    </div>
                    <button onClick={onClose} className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors">
                        <Minimize2 size={20} />
                    </button>
                </div>
            </header>

            <div className="flex-1 flex overflow-hidden">

                {/* LEFT: Document Canvas */}
                <div className="flex-1 bg-black/50 relative overflow-hidden flex flex-col">
                    <div className="flex-1 overflow-auto flex items-start justify-center p-8 lg:p-12">
                        <motion.div
                            layout
                            style={{ transform: `scale(${zoom})`, transformOrigin: 'top center' }}
                            className="bg-white shadow-2xl min-h-[800px] w-full max-w-[900px] transition-transform duration-200"
                        >
                            {isImage ? (
                                <img src={file.url} alt={file.name} className="w-full h-auto object-contain" />
                            ) : isPDF ? (
                                <iframe src={file.url} className="w-full h-[1200px] border-none" title="PDF Viewer" />
                            ) : (
                                <div className="h-[800px] flex flex-col items-center justify-center text-gray-400">
                                    <FileText size={64} className="mb-4 opacity-50" />
                                    <p>No preview available for this file type.</p>
                                </div>
                            )}
                        </motion.div>
                    </div>
                </div>

                {/* RIGHT: Sidebar (Notes / AI) */}
                <div className="w-[350px] lg:w-[450px] bg-[#0f1115] border-l border-white/10 flex flex-col shadow-2xl shrink-0 z-10 transition-all">

                    {/* Tabs */}
                    <div className="flex border-b border-white/10">
                        <button
                            onClick={() => setActiveTab('notes')}
                            className={`flex-1 py-4 text-sm font-bold border-b-2 transition-colors flex items-center justify-center gap-2 ${activeTab === 'notes' ? 'border-indigo-500 text-white' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                        >
                            <Notebook size={16} /> Notes
                        </button>
                        <button
                            onClick={() => setActiveTab('ai')}
                            className={`flex-1 py-4 text-sm font-bold border-b-2 transition-colors flex items-center justify-center gap-2 ${activeTab === 'ai' ? 'border-purple-500 text-white bg-purple-500/5' : 'border-transparent text-gray-500 hover:text-gray-300'}`}
                        >
                            <Bot size={16} /> AI Companion
                        </button>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 overflow-y-auto p-0 custom-scrollbar relative">

                        {/* NOTES TAB */}
                        {activeTab === 'notes' && (
                            <div className="p-4 space-y-3 h-full flex flex-col">
                                <div className="flex-1 space-y-3">
                                    {notes.length === 0 ? (
                                        <div className="h-full flex flex-col items-center justify-center text-center p-6 opacity-40">
                                            <Notebook size={48} className="text-gray-600 mb-4" strokeWidth={1} />
                                            <p className="text-sm font-medium text-gray-400">Your digital notebook</p>
                                        </div>
                                    ) : (
                                        notes.map((note, idx) => (
                                            <motion.div key={idx} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="group p-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 relative">
                                                <div className="flex gap-3">
                                                    <span className="text-indigo-500 font-serif leading-none mt-1">•</span>
                                                    <p className="text-sm text-gray-300 leading-relaxed font-light">{note}</p>
                                                </div>
                                                <button onClick={() => deleteNote(idx)} className="absolute top-2 right-2 p-1.5 text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"><Trash2 size={12} /></button>
                                            </motion.div>
                                        ))
                                    )}
                                </div>
                                <div className="pt-4 border-t border-white/10">
                                    <form onSubmit={handleAddNote} className="relative">
                                        <input
                                            type="text"
                                            value={currentNote}
                                            onChange={(e) => setCurrentNote(e.target.value)}
                                            placeholder="Type a note..."
                                            className="w-full pl-4 pr-12 py-3 bg-[#161920] border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500/50 text-sm text-gray-200"
                                            autoFocus
                                        />
                                        <button type="submit" disabled={!currentNote.trim()} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-indigo-500 rounded-lg text-white disabled:opacity-0"><Plus size={16} /></button>
                                    </form>
                                </div>
                            </div>
                        )}

                        {/* AI TAB */}
                        {activeTab === 'ai' && (
                            <div className="p-6 space-y-6">
                                {/* Actions */}
                                {!aiSummary && !aiFlashcards && !isLoadingAI && (
                                    <div className="grid grid-cols-1 gap-3">
                                        <MotionButton variant="outline" onClick={generateSummary} className="justify-start h-auto py-4 px-4 border-purple-500/30 hover:bg-purple-500/10 hover:border-purple-500/50 text-purple-300">
                                            <div className="p-2 bg-purple-500/20 rounded-lg mr-4">
                                                <FileText size={20} className="text-purple-400" />
                                            </div>
                                            <div className="text-left">
                                                <div className="font-bold text-white mb-0.5">Summarize Document</div>
                                                <div className="text-xs text-gray-400">Get key takeaways and bullet points</div>
                                            </div>
                                        </MotionButton>

                                        <MotionButton variant="outline" onClick={generateFlashcards} className="justify-start h-auto py-4 px-4 border-emerald-500/30 hover:bg-emerald-500/10 hover:border-emerald-500/50 text-emerald-300">
                                            <div className="p-2 bg-emerald-500/20 rounded-lg mr-4">
                                                <BrainCircuit size={20} className="text-emerald-400" />
                                            </div>
                                            <div className="text-left">
                                                <div className="font-bold text-white mb-0.5">Generate Flashcards</div>
                                                <div className="text-xs text-gray-400">Create study materials instantly</div>
                                            </div>
                                        </MotionButton>

                                        <MotionButton variant="outline" className="justify-start h-auto py-4 px-4 border-amber-500/30 hover:bg-amber-500/10 hover:border-amber-500/50 text-amber-300 opacity-50 cursor-not-allowed">
                                            <div className="p-2 bg-amber-500/20 rounded-lg mr-4">
                                                <Lightbulb size={20} className="text-amber-400" />
                                            </div>
                                            <div className="text-left">
                                                <div className="font-bold text-white mb-0.5">Extract Key Topics</div>
                                                <div className="text-xs text-gray-400">Coming soon</div>
                                            </div>
                                        </MotionButton>
                                    </div>
                                )}

                                {/* Loading State */}
                                {isLoadingAI && (
                                    <div className="flex flex-col items-center justify-center py-12">
                                        <div className="relative">
                                            <div className="w-12 h-12 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
                                            <div className="absolute inset-0 flex items-center justify-center">
                                                <Sparkles size={16} className="text-purple-400 animate-pulse" />
                                            </div>
                                        </div>
                                        <p className="mt-4 text-sm text-purple-300 font-medium animate-pulse">Analyzing document...</p>
                                    </div>
                                )}

                                {/* Results: Summary */}
                                {aiSummary && (
                                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <h3 className="font-bold text-white flex items-center gap-2">
                                                <Sparkles size={16} className="text-purple-400" /> AI Summary
                                            </h3>
                                            <button onClick={() => setAiSummary(null)} className="text-xs text-gray-500 hover:text-white">Clear</button>
                                        </div>
                                        <div className="bg-[#161920] rounded-xl p-4 border border-purple-500/20 space-y-3">
                                            {aiSummary.map((point, i) => (
                                                <div key={i} className="flex gap-3 text-sm text-gray-300">
                                                    <span className="text-purple-500 mt-1">•</span>
                                                    <span className="leading-relaxed">{point}</span>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="bg-purple-500/10 p-3 rounded-lg flex gap-3 items-center">
                                            <Bot size={18} className="text-purple-400 shrink-0" />
                                            <p className="text-xs text-purple-200">Tip: Click 'Generate Flashcards' to test your knowledge on these points!</p>
                                        </div>
                                    </motion.div>
                                )}

                                {/* Results: Flashcards */}
                                {aiFlashcards && (
                                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                                        <div className="flex items-center justify-between">
                                            <h3 className="font-bold text-white flex items-center gap-2">
                                                <BrainCircuit size={16} className="text-emerald-400" /> Flashcards
                                            </h3>
                                            <button onClick={() => setAiFlashcards(null)} className="text-xs text-gray-500 hover:text-white">Clear</button>
                                        </div>
                                        <div className="space-y-3">
                                            {aiFlashcards.map((card, i) => (
                                                <div key={i} className="group bg-[#161920] rounded-xl p-4 border border-emerald-500/20 hover:border-emerald-500/40 transition-colors">
                                                    <p className="text-xs text-emerald-500 font-bold mb-1 uppercase tracking-wider">Question {i + 1}</p>
                                                    <p className="text-white font-medium mb-3">{card.q}</p>
                                                    <div className="pt-3 border-t border-white/5 opacity-50 group-hover:opacity-100 transition-opacity">
                                                        <p className="text-sm text-gray-400">{card.a}</p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}
                            </div>
                        )}

                    </div>
                </div>

            </div>
        </motion.div>
    );
};

export default function FilePreviewModal({ isOpen, onClose, file }: FilePreviewModalProps) {
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
        return () => setMounted(false);
    }, []);

    if (!mounted) return null;

    return createPortal(
        <AnimatePresence>
            {isOpen && file && <FilePreviewContent file={file} onClose={onClose} />}
        </AnimatePresence>,
        document.body
    );
}
