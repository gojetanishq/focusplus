import React, { useState } from 'react';
import { useTasks } from '../context/TaskContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Check, Trophy } from 'lucide-react';
import { cn } from '../utils/cn';

export function TaskList() {
  const { tasks, addTask, toggleTask, deleteTask, userStats } = useTasks();
  const [newTask, setNewTask] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    addTask(newTask);
    setNewTask('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <form onSubmit={handleSubmit} className="flex gap-3">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Add a new task..."
            className="flex-1 px-4 py-3 rounded-xl border border-gray-200 dark:border-dark-border bg-white dark:bg-dark-surface focus:ring-2 focus:ring-primary-500 outline-none transition-all"
          />
          <button
            type="submit"
            className="px-6 py-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-colors flex items-center gap-2 font-medium"
          >
            <Plus className="w-5 h-5" />
            Add
          </button>
        </form>

        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {tasks.map((task) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                layout
                className={cn(
                  "group flex items-center gap-4 p-4 rounded-xl border transition-all duration-200",
                  task.completed
                    ? "bg-gray-50 dark:bg-dark-surface/50 border-gray-100 dark:border-dark-border opacity-75"
                    : "bg-white dark:bg-dark-surface border-gray-200 dark:border-dark-border shadow-sm hover:shadow-md"
                )}
              >
                <button
                  onClick={() => toggleTask(task.id)}
                  className={cn(
                    "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors",
                    task.completed
                      ? "bg-green-500 border-green-500 text-white"
                      : "border-gray-300 hover:border-primary-500"
                  )}
                >
                  {task.completed && <Check className="w-4 h-4" />}
                </button>
                
                <span className={cn(
                  "flex-1 font-medium transition-all",
                  task.completed ? "text-gray-500 line-through" : "text-gray-900 dark:text-gray-100"
                )}>
                  {task.text}
                </span>

                <button
                  onClick={() => deleteTask(task.id)}
                  className="opacity-0 group-hover:opacity-100 p-2 text-gray-400 hover:text-red-500 transition-all"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {tasks.length === 0 && (
            <div className="text-center py-12 text-gray-500 dark:text-gray-400">
              <p>No tasks yet. Start by adding one above!</p>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-gradient-to-br from-primary-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg shadow-primary-500/20">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
              <Trophy className="w-8 h-8 text-yellow-300" />
            </div>
            <div>
              <p className="text-primary-100 text-sm font-medium">Current Level</p>
              <h3 className="text-3xl font-bold">Level {userStats.level}</h3>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-primary-100">
              <span>XP Progress</span>
              <span>{userStats.xp % 100} / 100 XP</span>
            </div>
            <div className="h-2 bg-black/20 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${userStats.xp % 100}%` }}
                className="h-full bg-yellow-400 rounded-full"
              />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-dark-surface rounded-2xl p-6 border border-gray-200 dark:border-dark-border shadow-sm">
          <h3 className="font-semibold mb-4">Recent Achievements</h3>
          <div className="space-y-4">
            <div className="flex items-center gap-3 opacity-50">
              <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-dark-bg flex items-center justify-center">
                🔒
              </div>
              <div>
                <p className="font-medium">Task Master</p>
                <p className="text-xs text-gray-500">Complete 50 tasks</p>
              </div>
            </div>
            {/* Add more achievements here */}
          </div>
        </div>
      </div>
    </div>
  );
}
