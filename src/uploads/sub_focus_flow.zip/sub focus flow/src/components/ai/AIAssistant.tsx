import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Bot, Send, Target, Clock, TrendingUp, Lightbulb, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import { useTasks } from '@/context/TaskContext';
import { useStudy } from '@/context/StudyContext';
import { apoxApiWithFallback } from '@/services/apoxApi';
import { aiMock } from '@/services/aiMock';

const QUICK_ACTIONS = [
    { text: "Show my tasks", icon: Target },
    { text: "What's my schedule?", icon: Clock },
    { text: "How's my progress?", icon: TrendingUp },
    { text: "Give me study tips", icon: Lightbulb },
];

export default function AIAssistant() {
    // Get context data - will use defaults if contexts not available
    const taskContext = useTasks();
    const studyContext = useStudy();
    
    const tasks = taskContext?.tasks || [];
    const userStats = taskContext?.userStats || { xp: 0, level: 1, tasksCompleted: 0 };
    const sessions = studyContext?.sessions || [];
    const [isOpen, setIsOpen] = useState(false);
    
    // Load conversation history from localStorage
    const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>(() => {
        const saved = localStorage.getItem('aiChatHistory');
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch {
                return [{ role: 'ai', text: "Hi! I'm your Focus Assistant. How can I help you optimize your study efficiency today?" }];
            }
        }
        return [{ role: 'ai', text: "Hi! I'm your Focus Assistant. How can I help you optimize your study efficiency today?" }];
    });
    
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [apiConnected, setApiConnected] = useState<boolean | null>(null);
    const [lastResponseId, setLastResponseId] = useState<string | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    // Save conversation history
    useEffect(() => {
        localStorage.setItem('aiChatHistory', JSON.stringify(messages));
    }, [messages]);

    useEffect(() => {
        scrollToBottom();
    }, [messages, isOpen]);

    // Check API connection on mount and periodically
    useEffect(() => {
        const checkApi = async () => {
            try {
                const { apoxApi } = await import('@/services/apoxApi');
                const health = await apoxApi.healthCheck();
                setApiConnected(health?.status === 'healthy');
            } catch (error) {
                console.warn('API health check failed:', error);
                setApiConnected(false);
            }
        };
        
        checkApi();
        // Retry every 10 seconds
        const interval = setInterval(checkApi, 10000);
        return () => clearInterval(interval);
    }, []);

    const handleSend = async (e?: React.FormEvent, messageText?: string) => {
        e?.preventDefault();
        const userMsg = messageText || input.trim();
        if (!userMsg) return;

        setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
        if (!messageText) setInput('');
        setIsTyping(true);

        try {
            // Try Apox Engine API first
            const responseId = `resp_${Date.now()}`;
            setLastResponseId(responseId);

            // Build context chunks from user data
            const contextChunks: string[] = [];
            if (tasks && tasks.length > 0) {
                contextChunks.push(`User has ${tasks.filter(t => !t.completed).length} pending tasks`);
            }
            if (sessions && sessions.length > 0) {
                contextChunks.push(`User has ${sessions.filter(s => !s.completed).length} upcoming study sessions`);
            }

            const chatResponse = await apoxApiWithFallback.chat(userMsg, contextChunks);
            
            // Format response with sources if available
            let formattedResponse = chatResponse.answer;
            
            if (chatResponse.sources && chatResponse.sources.length > 0) {
                formattedResponse += '\n\n📚 Sources:\n';
                chatResponse.sources.forEach((source, idx) => {
                    formattedResponse += `${idx + 1}. ${source.title}\n`;
                });
            }

            if (chatResponse.provenance?.reasoning_signals && chatResponse.provenance.reasoning_signals.length > 0) {
                formattedResponse += `\n\n🔍 Reasoning: ${chatResponse.provenance.reasoning_signals.join(', ')}`;
            }

            setIsTyping(false);
            setMessages(prev => [...prev, { role: 'ai', text: formattedResponse }]);
        } catch (error) {
            // Fallback to mock if API fails
            console.error('API error, using fallback:', error);
            const context = {
                tasks: tasks || [],
                sessions: sessions || [],
                stats: userStats || { xp: 0, level: 1, tasksCompleted: 0 }
            };
            const response = await aiMock.chatWithAI(userMsg, context);
            setIsTyping(false);
            setMessages(prev => [...prev, { role: 'ai', text: response }]);
        }
    };

    const handleDisagree = async () => {
        if (!lastResponseId) return;
        
        try {
            await apoxApiWithFallback.submitFeedback({
                response_id: lastResponseId,
                rating: 1,
                disagreement: 'User disagreed with response',
                user_id: 'current_user' // Replace with actual user ID
            });
            alert('Thank you for your feedback! This helps improve the AI.');
        } catch (error) {
            console.error('Failed to submit feedback:', error);
        }
    };

    const handleQuickAction = (actionText: string) => {
        handleSend(undefined, actionText);
    };

    return (
        <>
            {/* Floating Toggle Button */}
            <motion.button
                onClick={() => setIsOpen(!isOpen)}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className={`fixed bottom-6 right-6 z-40 p-4 rounded-full shadow-2xl transition-all duration-300 ${isOpen ? 'bg-indigo-500 rotate-90' : 'bg-white dark:bg-[#1a1d24] border border-gray-200 dark:border-indigo-500/30'}`}
            >
                {isOpen ? (
                    <X size={24} className="text-white" />
                ) : (
                    <div className="relative">
                        <Sparkles size={24} className="text-indigo-500" />
                        <span className="absolute -top-1 -right-1 truncate max-w-[100px] w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                    </div>
                )}
            </motion.button>

            {/* Chat Window */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.95 }}
                        className="fixed bottom-24 right-6 w-[350px] md:w-[400px] h-[500px] bg-white dark:bg-[#0f1115] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 z-40 flex flex-col overflow-hidden"
                    >
                        {/* Header */}
                        <div className="p-4 bg-gradient-to-r from-indigo-600 to-purple-600 flex items-center gap-3">
                            <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                                <Bot size={20} className="text-white" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-bold text-white text-sm">Focus Assistant</h3>
                                <p className="text-indigo-100 text-xs flex items-center gap-1">
                                    {apiConnected === true ? (
                                        <>
                                            <CheckCircle2 size={12} className="text-green-300" /> Apox Engine Connected
                                        </>
                                    ) : apiConnected === false ? (
                                        <>
                                            <AlertCircle size={12} className="text-yellow-300" /> Fallback Mode
                                        </>
                                    ) : (
                                        <>
                                            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" /> Connecting...
                                        </>
                                    )}
                                </p>
                            </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 dark:bg-black/20 custom-scrollbar">
                            {messages.map((msg, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div
                                        className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${msg.role === 'user'
                                            ? 'bg-indigo-500 text-white rounded-tr-sm'
                                            : 'bg-white dark:bg-[#1a1d24] text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-800 rounded-tl-sm shadow-sm'
                                            }`}
                                    >
                                        {msg.text}
                                    </div>
                                </motion.div>
                            ))}
                            {isTyping && (
                                <div className="flex justify-start">
                                    <div className="bg-white dark:bg-[#1a1d24] p-3 rounded-2xl rounded-tl-sm border border-gray-200 dark:border-gray-800 shadow-sm flex gap-1">
                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                                    </div>
                                </div>
                            )}
                            
                            {/* Quick Actions - Show when no messages or after AI response */}
                            {messages.length <= 1 && !isTyping && (
                                <div className="space-y-2 pt-2">
                                    <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mb-2">Quick actions:</p>
                                    <div className="grid grid-cols-2 gap-2">
                                        {QUICK_ACTIONS.map((action, idx) => (
                                            <motion.button
                                                key={idx}
                                                onClick={() => handleQuickAction(action.text)}
                                                whileHover={{ scale: 1.02 }}
                                                whileTap={{ scale: 0.98 }}
                                                className="p-2 text-xs bg-white dark:bg-[#1a1d24] border border-gray-200 dark:border-gray-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-500/10 hover:border-indigo-300 dark:hover:border-indigo-500/30 transition-all text-left flex items-center gap-2 text-gray-700 dark:text-gray-300"
                                            >
                                                <action.icon size={14} className="text-indigo-500 shrink-0" />
                                                <span className="truncate">{action.text}</span>
                                            </motion.button>
                                        ))}
                                    </div>
                                </div>
                            )}
                            
                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input */}
                        <div className="p-4 bg-white dark:bg-[#0f1115] border-t border-gray-200 dark:border-gray-800">
                            <form onSubmit={handleSend} className="relative">
                                <input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSend(e);
                                        }
                                    }}
                                    placeholder="Ask for advice..."
                                    className="w-full pl-4 pr-12 py-3 rounded-xl bg-gray-100 dark:bg-[#161920] border-transparent focus:bg-white dark:focus:bg-[#1a1d24] focus:border-indigo-500 dark:focus:border-indigo-500 outline-none text-sm text-gray-900 dark:text-white transition-all placeholder:text-gray-500"
                                    disabled={isTyping}
                                />
                                <button
                                    type="submit"
                                    disabled={!input.trim() || isTyping}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 disabled:scale-90 rounded-lg text-white transition-all"
                                >
                                    <Send size={16} />
                                </button>
                            </form>
                            <div className="mt-2 flex items-center gap-2">
                                {messages.length > 1 && (
                                    <>
                                        <button
                                            onClick={() => {
                                                setMessages([{ role: 'ai', text: "Hi! I'm your Focus Assistant. How can I help you optimize your study efficiency today?" }]);
                                                localStorage.removeItem('aiChatHistory');
                                            }}
                                            className="text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                                        >
                                            Clear conversation
                                        </button>
                                        {lastResponseId && (
                                            <button
                                                onClick={handleDisagree}
                                                className="text-xs text-red-500 hover:text-red-700 dark:hover:text-red-400 transition-colors flex items-center gap-1"
                                            >
                                                <AlertCircle size={12} /> Disagree
                                            </button>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}
