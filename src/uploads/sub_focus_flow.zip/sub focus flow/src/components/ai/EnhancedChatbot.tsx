import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Sparkles, Bot, Lightbulb, Target, Clock, TrendingUp, ExternalLink, CheckCircle2, AlertCircle, BrainCircuit, BookOpen } from 'lucide-react';
import { apoxApiWithFallback } from '@/services/apoxApi';
import { useTasks } from '@/context/TaskContext';
import { useStudy } from '@/context/StudyContext';
import DifficultyDisplay from './DifficultyDisplay';

const QUICK_ACTIONS = [
    { text: "Show my tasks", icon: Target },
    { text: "What's my schedule?", icon: Clock },
    { text: "How's my progress?", icon: TrendingUp },
    { text: "Give me study tips", icon: Lightbulb },
    { text: "Analyze topic difficulty", icon: BrainCircuit },
];

interface Message {
    role: 'user' | 'ai';
    text: string;
    metadata?: {
        sources?: Array<{ title: string; url: string; type: string; quote: string }>;
        reasoning_signals?: string[];
        difficulty_analysis?: any;
    };
}

export default function EnhancedChatbot() {
    const taskContext = useTasks();
    const studyContext = useStudy();
    
    const tasks = taskContext?.tasks || [];
    const userStats = taskContext?.userStats || { xp: 0, level: 1, tasksCompleted: 0 };
    const sessions = studyContext?.sessions || [];
    const [isOpen, setIsOpen] = useState(false);
    
    // Enhanced message state with metadata
    const [messages, setMessages] = useState<Message[]>(() => {
        const saved = localStorage.getItem('aiChatHistory');
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch {
                return [{ role: 'ai', text: "Hi! I'm your Focus Assistant powered by explainable AI. I can help you with difficulty assessment, study planning, and learning strategies. How can I assist you today?" }];
            }
        }
        return [{ role: 'ai', text: "Hi! I'm your Focus Assistant powered by explainable AI. I can help you with difficulty assessment, study planning, and learning strategies. How can I assist you today?" }];
    });
    
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [apiConnected, setApiConnected] = useState<boolean | null>(null);
    const [lastResponseId, setLastResponseId] = useState<string | null>(null);
    const [showDifficultyAnalysis, setShowDifficultyAnalysis] = useState(false);
    const [currentTopic, setCurrentTopic] = useState<string>('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        localStorage.setItem('aiChatHistory', JSON.stringify(messages));
    }, [messages]);

    useEffect(() => {
        scrollToBottom();
    }, [messages, isOpen]);

    useEffect(() => {
        const checkApi = async () => {
            try {
                const { apoxApi } = await import('@/services/apoxApi');
                const health = await apoxApi.healthCheck();
                setApiConnected(health?.status === 'healthy');
            } catch {
                setApiConnected(false);
            }
        };
        checkApi();
    }, []);

    // Detect if user is asking about difficulty
    const detectDifficultyQuery = (text: string): string | null => {
        const lower = text.toLowerCase();
        const difficultyPatterns = [
            /(?:what|how|tell me).*(?:difficulty|hard|easy|challenging|complex).*(?:of|for|with)?\s+([^?\.]+)/i,
            /(?:difficulty|hard|easy|challenging|complex).*(?:of|for|with)?\s+([^?\.]+)/i,
            /analyze.*difficulty.*(?:of|for)?\s+([^?\.]+)/i,
        ];
        
        for (const pattern of difficultyPatterns) {
            const match = text.match(pattern);
            if (match && match[1]) {
                return match[1].trim();
            }
        }
        
        // Check for direct topic mentions
        if (lower.includes('difficulty') || lower.includes('how hard') || lower.includes('how easy')) {
            // Try to extract topic from context
            const words = text.split(/\s+/);
            const topicStart = words.findIndex(w => 
                ['difficulty', 'hard', 'easy', 'challenging', 'complex'].includes(w.toLowerCase())
            );
            if (topicStart >= 0 && topicStart < words.length - 1) {
                return words.slice(topicStart + 1).join(' ').replace(/[?\.]/g, '').trim();
            }
        }
        
        return null;
    };

    const handleSend = async (e?: React.FormEvent, messageText?: string) => {
        e?.preventDefault();
        const userMsg = messageText || input.trim();
        if (!userMsg) return;

        setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
        if (!messageText) setInput('');
        setIsTyping(true);

        try {
            const responseId = `resp_${Date.now()}`;
            setLastResponseId(responseId);

            // Check if this is a difficulty query
            const topic = detectDifficultyQuery(userMsg);
            if (topic) {
                setCurrentTopic(topic);
                setShowDifficultyAnalysis(true);
            }

            // Build rich context chunks
            const contextChunks: string[] = [];
            const pendingTasks = tasks.filter(t => !t.completed);
            const upcomingSessions = sessions.filter(s => !s.completed && new Date(s.date) >= new Date());
            
            if (pendingTasks.length > 0) {
                contextChunks.push(`User has ${pendingTasks.length} pending tasks: ${pendingTasks.slice(0, 3).map(t => t.text).join(', ')}`);
            }
            if (upcomingSessions.length > 0) {
                contextChunks.push(`User has ${upcomingSessions.length} upcoming study sessions`);
            }
            if (userStats.xp > 0) {
                contextChunks.push(`User is at level ${userStats.level} with ${userStats.xp} XP`);
            }

            const chatResponse = await apoxApiWithFallback.chat(userMsg, contextChunks);
            
            // Format response with rich metadata
            let formattedResponse = chatResponse.answer;
            
            // Add sources if available
            if (chatResponse.sources && chatResponse.sources.length > 0) {
                formattedResponse += '\n\n📚 **Sources & References:**\n';
                chatResponse.sources.forEach((source, idx) => {
                    formattedResponse += `${idx + 1}. **${source.title}**`;
                    if (source.quote) {
                        formattedResponse += `\n   "${source.quote}"`;
                    }
                    formattedResponse += '\n';
                });
            }

            // Add reasoning signals
            if (chatResponse.provenance.reasoning_signals && chatResponse.provenance.reasoning_signals.length > 0) {
                formattedResponse += `\n\n🔍 **Reasoning Analysis:** ${chatResponse.provenance.reasoning_signals.map(s => s.replace(/_/g, ' ')).join(', ')}`;
            }

            // Add confidence indicator
            if (chatResponse.confidence < 0.7) {
                formattedResponse += '\n\n⚠️ *Note: Confidence level is moderate. For more accurate assessment, please provide additional context.*';
            }

            setIsTyping(false);
            setMessages(prev => [...prev, { 
                role: 'ai', 
                text: formattedResponse,
                metadata: {
                    sources: chatResponse.sources,
                    reasoning_signals: chatResponse.provenance.reasoning_signals,
                }
            }]);
        } catch (error) {
            console.error('API error:', error);
            setIsTyping(false);
            setMessages(prev => [...prev, { 
                role: 'ai', 
                text: "I apologize, but I'm having trouble connecting right now. Please try again in a moment, or check your connection." 
            }]);
        }
    };

    const handleDisagree = async () => {
        if (!lastResponseId) return;
        
        try {
            await apoxApiWithFallback.submitFeedback({
                response_id: lastResponseId,
                rating: 1,
                disagreement: 'User disagreed with response',
                user_id: 'current_user'
            });
            alert('Thank you for your feedback! This helps improve the AI.');
        } catch (error) {
            console.error('Failed to submit feedback:', error);
        }
    };

    const handleQuickAction = (actionText: string) => {
        if (actionText === "Analyze topic difficulty") {
            setShowDifficultyAnalysis(true);
            setCurrentTopic('');
        } else {
            handleSend(undefined, actionText);
        }
    };

    return (
        <>
            {/* Floating Toggle Button */}
            <motion.button
                onClick={() => setIsOpen(!isOpen)}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className={`fixed bottom-6 right-6 z-40 p-4 rounded-full shadow-2xl transition-all duration-300 ${isOpen ? 'bg-indigo-500 rotate-90' : 'bg-white dark:bg-[#1a1d24] border border-gray-200 dark:border-indigo-500/30'}`}
            >
                {isOpen ? (
                    <X size={24} className="text-white" />
                ) : (
                    <div className="relative">
                        <Sparkles size={24} className="text-indigo-500" />
                        <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                    </div>
                )}
            </motion.button>

            {/* Chat Window */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.95 }}
                        className="fixed bottom-24 right-6 w-[380px] md:w-[450px] h-[600px] bg-white dark:bg-[#0f1115] rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 z-40 flex flex-col overflow-hidden"
                    >
                        {/* Header */}
                        <div className="p-4 bg-gradient-to-r from-indigo-600 to-purple-600 flex items-center gap-3">
                            <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                                <Bot size={20} className="text-white" />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-bold text-white text-sm">Focus Assistant</h3>
                                <p className="text-indigo-100 text-xs flex items-center gap-1">
                                    {apiConnected === true ? (
                                        <>
                                            <CheckCircle2 size={12} className="text-green-300" /> Apox Engine Connected
                                        </>
                                    ) : apiConnected === false ? (
                                        <>
                                            <AlertCircle size={12} className="text-yellow-300" /> Fallback Mode
                                        </>
                                    ) : (
                                        <>
                                            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" /> Connecting...
                                        </>
                                    )}
                                </p>
                            </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 dark:bg-black/20 custom-scrollbar">
                            {messages.map((msg, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div
                                        className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${msg.role === 'user'
                                            ? 'bg-indigo-500 text-white rounded-tr-sm'
                                            : 'bg-white dark:bg-[#1a1d24] text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-800 rounded-tl-sm shadow-sm'
                                            }`}
                                    >
                                        {msg.text}
                                        {msg.metadata?.sources && msg.metadata.sources.length > 0 && (
                                            <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                                                <div className="flex flex-wrap gap-1">
                                                    {msg.metadata.sources.slice(0, 2).map((source, sidx) => (
                                                        <a
                                                            key={sidx}
                                                            href={source.url}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                                                        >
                                                            <ExternalLink size={10} />
                                                            {source.title}
                                                        </a>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </motion.div>
                            ))}
                            
                            {isTyping && (
                                <div className="flex justify-start">
                                    <div className="bg-white dark:bg-[#1a1d24] p-3 rounded-2xl rounded-tl-sm border border-gray-200 dark:border-gray-800 shadow-sm flex gap-1">
                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                                    </div>
                                </div>
                            )}

                            {/* Difficulty Analysis Section */}
                            {showDifficultyAnalysis && (
                                <motion.div
                                    initial={{ opacity: 0, height: 0 }}
                                    animate={{ opacity: 1, height: 'auto' }}
                                    className="mt-4"
                                >
                                    <div className="bg-indigo-50 dark:bg-[#1a1d24] rounded-xl p-4 border border-indigo-200 dark:border-indigo-500/20">
                                        <div className="flex items-center justify-between mb-3">
                                            <h4 className="font-bold text-sm text-gray-900 dark:text-white flex items-center gap-2">
                                                <BrainCircuit size={16} className="text-indigo-600 dark:text-indigo-400" />
                                                Difficulty Analysis
                                            </h4>
                                            <button
                                                onClick={() => {
                                                    setShowDifficultyAnalysis(false);
                                                    setCurrentTopic('');
                                                }}
                                                className="text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                                            >
                                                Close
                                            </button>
                                        </div>
                                        <DifficultyDisplay 
                                            topic={currentTopic || 'Enter a topic to analyze'} 
                                            autoAnalyze={!!currentTopic}
                                        />
                                    </div>
                                </motion.div>
                            )}
                            
                            {/* Quick Actions */}
                            {messages.length <= 1 && !isTyping && (
                                <div className="space-y-2 pt-2">
                                    <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mb-2">Quick actions:</p>
                                    <div className="grid grid-cols-2 gap-2">
                                        {QUICK_ACTIONS.map((action, idx) => (
                                            <motion.button
                                                key={idx}
                                                onClick={() => handleQuickAction(action.text)}
                                                whileHover={{ scale: 1.02 }}
                                                whileTap={{ scale: 0.98 }}
                                                className="p-2 text-xs bg-white dark:bg-[#1a1d24] border border-gray-200 dark:border-gray-800 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-500/10 hover:border-indigo-300 dark:hover:border-indigo-500/30 transition-all text-left flex items-center gap-2 text-gray-700 dark:text-gray-300"
                                            >
                                                <action.icon size={14} className="text-indigo-500 shrink-0" />
                                                <span className="truncate">{action.text}</span>
                                            </motion.button>
                                        ))}
                                    </div>
                                </div>
                            )}
                            
                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input */}
                        <div className="p-4 bg-white dark:bg-[#0f1115] border-t border-gray-200 dark:border-gray-800">
                            <form onSubmit={handleSend} className="relative">
                                <input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSend(e);
                                        }
                                    }}
                                    placeholder="Ask anything or analyze difficulty..."
                                    className="w-full pl-4 pr-12 py-3 rounded-xl bg-gray-100 dark:bg-[#161920] border-transparent focus:bg-white dark:focus:bg-[#1a1d24] focus:border-indigo-500 dark:focus:border-indigo-500 outline-none text-sm text-gray-900 dark:text-white transition-all placeholder:text-gray-500"
                                    disabled={isTyping}
                                />
                                <button
                                    type="submit"
                                    disabled={!input.trim() || isTyping}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 disabled:scale-90 rounded-lg text-white transition-all"
                                >
                                    <Send size={16} />
                                </button>
                            </form>
                            <div className="mt-2 flex items-center gap-2">
                                {messages.length > 1 && (
                                    <>
                                        <button
                                            onClick={() => {
                                                setMessages([{ role: 'ai', text: "Hi! I'm your Focus Assistant powered by explainable AI. How can I assist you today?" }]);
                                                localStorage.removeItem('aiChatHistory');
                                                setShowDifficultyAnalysis(false);
                                            }}
                                            className="text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                                        >
                                            Clear conversation
                                        </button>
                                        {lastResponseId && (
                                            <button
                                                onClick={handleDisagree}
                                                className="text-xs text-red-500 hover:text-red-700 dark:hover:text-red-400 transition-colors flex items-center gap-1"
                                            >
                                                <AlertCircle size={12} /> Disagree
                                            </button>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}

