import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, TrendingUp, BookOpen, CheckCircle2, AlertTriangle, ExternalLink, Sparkles, Star } from 'lucide-react';
import { apoxApiWithFallback, DifficultyResponse, Review } from '@/services/apoxApi';

interface DifficultyDisplayProps {
    topic: string;
    onAnalyze?: (result: DifficultyResponse) => void;
    autoAnalyze?: boolean;
}

export default function DifficultyDisplay({ topic, onAnalyze, autoAnalyze = false }: DifficultyDisplayProps) {
    const [result, setResult] = useState<DifficultyResponse | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [reviews, setReviews] = useState<Review[]>([]);
    const [reviewText, setReviewText] = useState('');
    const [reviewDifficulty, setReviewDifficulty] = useState('medium');
    const [isSubmittingReview, setIsSubmittingReview] = useState(false);

    useEffect(() => {
        if (autoAnalyze && topic.trim()) {
            handleAnalyze();
        }
    }, [topic, autoAnalyze]);

    useEffect(() => {
        const loadReviews = async () => {
            if (!topic.trim()) {
                setReviews([]);
                return;
            }
            try {
                const data = await apoxApiWithFallback.getReviews(topic.trim());
                setReviews(data);
            } catch (err) {
                console.warn('Failed to load reviews', err);
            }
        };
        loadReviews();
    }, [topic]);

    const handleAnalyze = async () => {
        if (!topic.trim()) return;
        
        setIsAnalyzing(true);
        setError(null);
        
        try {
            const analysis = await apoxApiWithFallback.classifyDifficulty(topic.trim());
            setResult(analysis);
            onAnalyze?.(analysis);
        } catch (err) {
            setError('Failed to analyze difficulty. Please try again.');
            console.error('Difficulty analysis error:', err);
        } finally {
            setIsAnalyzing(false);
        }
    };

    const handleSubmitReview = async () => {
        if (!topic.trim() || !reviewText.trim()) return;
        setIsSubmittingReview(true);
        try {
            const newReview = await apoxApiWithFallback.submitReview({
                topic: topic.trim(),
                user_id: 'anonymous_user',
                difficulty: reviewDifficulty,
                review_text: reviewText.trim(),
                rating: undefined,
            });
            setReviews(prev => [newReview, ...prev]);
            setReviewText('');
        } catch (err) {
            console.error('Failed to submit review', err);
            setError('Could not submit review. Please try again.');
        } finally {
            setIsSubmittingReview(false);
        }
    };

    const getDifficultyColor = (difficulty: string) => {
        switch (difficulty.toLowerCase()) {
            case 'easy':
                return 'text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400';
            case 'medium':
                return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-900/20 dark:text-yellow-400';
            case 'hard':
                return 'text-orange-600 bg-orange-50 dark:bg-orange-900/20 dark:text-orange-400';
            case 'very_hard':
                return 'text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400';
            default:
                return 'text-gray-600 bg-gray-50 dark:bg-gray-900/20 dark:text-gray-400';
        }
    };

    const getDifficultyLabel = (difficulty: string) => {
        return difficulty.split('_').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
    };

    return (
        <div className="space-y-4">
            {!result && !isAnalyzing && !error && (
                <motion.button
                    onClick={handleAnalyze}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full p-4 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl text-white font-medium flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
                >
                    <BrainCircuit size={20} />
                    Analyze Difficulty
                </motion.button>
            )}

            {isAnalyzing && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-6 bg-indigo-50 dark:bg-[#1a1d24] rounded-xl border border-indigo-200 dark:border-indigo-500/20"
                >
                    <div className="flex items-center gap-3">
                        <Sparkles className="text-indigo-500 animate-spin" size={20} />
                        <div>
                            <p className="font-medium text-gray-900 dark:text-white">Analyzing difficulty...</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">Evaluating complexity and reasoning requirements</p>
                        </div>
                    </div>
                </motion.div>
            )}

            <AnimatePresence>
                {error && (
                    <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-500/20 rounded-xl flex items-center gap-2"
                    >
                        <AlertTriangle className="text-red-500" size={20} />
                        <p className="text-red-700 dark:text-red-400">{error}</p>
                    </motion.div>
                )}

                {result && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                    >
                        {/* Main Difficulty Card */}
                        <div className="bg-white dark:bg-[#1a1d24] rounded-xl p-6 border border-gray-200 dark:border-gray-800 shadow-lg">
                            <div className="flex items-start justify-between mb-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg">
                                        <BrainCircuit className="text-indigo-600 dark:text-indigo-400" size={24} />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-lg text-gray-900 dark:text-white">Difficulty Analysis</h3>
                                        <p className="text-sm text-gray-600 dark:text-gray-400">{topic}</p>
                                    </div>
                                </div>
                                <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getDifficultyColor(result.difficulty)}`}>
                                    {getDifficultyLabel(result.difficulty)}
                                </span>
                            </div>

                            {/* Score Bar */}
                            <div className="mb-4">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Difficulty Score</span>
                                    <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{result.difficulty_score}/100</span>
                                </div>
                                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                                    <motion.div
                                        initial={{ width: 0 }}
                                        animate={{ width: `${result.difficulty_score}%` }}
                                        transition={{ duration: 1, ease: "easeOut" }}
                                        className={`h-full ${
                                            result.difficulty_score >= 75 ? 'bg-red-500' :
                                            result.difficulty_score >= 50 ? 'bg-orange-500' :
                                            result.difficulty_score >= 25 ? 'bg-yellow-500' : 'bg-green-500'
                                        }`}
                                    />
                                </div>
                            </div>

                            {/* Confidence */}
                            <div className="flex items-center gap-2 mb-4">
                                <CheckCircle2 className="text-green-500" size={16} />
                                <span className="text-sm text-gray-600 dark:text-gray-400">
                                    Confidence: <span className="font-semibold">{(result.confidence * 100).toFixed(0)}%</span>
                                </span>
                            </div>
                        </div>

                        {/* Reasoning Summary */}
                        {result.reasoning_summary && result.reasoning_summary.length > 0 && (
                            <div className="bg-indigo-50 dark:bg-[#1a1d24] rounded-xl p-5 border border-indigo-100 dark:border-indigo-500/20">
                                <h4 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                                    <TrendingUp size={18} className="text-indigo-600 dark:text-indigo-400" />
                                    Reasoning Analysis
                                </h4>
                                <ul className="space-y-2">
                                    {result.reasoning_summary.map((reason, idx) => (
                                        <motion.li
                                            key={idx}
                                            initial={{ opacity: 0, x: -10 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300"
                                        >
                                            <span className="text-indigo-500 mt-1">•</span>
                                            <span>{reason}</span>
                                        </motion.li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Reasoning Signals */}
                        {result.provenance.reasoning_signals && result.provenance.reasoning_signals.length > 0 && (
                            <div className="bg-white dark:bg-[#1a1d24] rounded-xl p-5 border border-gray-200 dark:border-gray-800">
                                <h4 className="font-bold text-gray-900 dark:text-white mb-3">Reasoning Signals</h4>
                                <div className="flex flex-wrap gap-2">
                                    {result.provenance.reasoning_signals.map((signal, idx) => (
                                        <motion.span
                                            key={idx}
                                            initial={{ opacity: 0, scale: 0.8 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 rounded-full text-xs font-medium"
                                        >
                                            {signal.replace(/_/g, ' ')}
                                        </motion.span>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Sources */}
                        {result.sources && result.sources.length > 0 && (
                            <div className="bg-white dark:bg-[#1a1d24] rounded-xl p-5 border border-gray-200 dark:border-gray-800">
                                <h4 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                                    <BookOpen size={18} className="text-indigo-600 dark:text-indigo-400" />
                                    Sources & References
                                </h4>
                                <div className="space-y-3">
                                    {result.sources.map((source, idx) => (
                                        <motion.div
                                            key={idx}
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="p-3 bg-gray-50 dark:bg-[#0f1115] rounded-lg border border-gray-200 dark:border-gray-800"
                                        >
                                            <div className="flex items-start justify-between">
                                                <div className="flex-1">
                                                    <h5 className="font-semibold text-sm text-gray-900 dark:text-white mb-1">
                                                        {source.title}
                                                    </h5>
                                                    {source.quote && (
                                                        <p className="text-xs text-gray-600 dark:text-gray-400 italic mb-2">
                                                            "{source.quote}"
                                                        </p>
                                                    )}
                                                    <span className="text-xs px-2 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded">
                                                        {source.type}
                                                    </span>
                                                </div>
                                                {source.url && (
                                                    <a
                                                        href={source.url}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="ml-2 p-1 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 rounded"
                                                    >
                                                        <ExternalLink size={16} />
                                                    </a>
                                                )}
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Verification Checks */}
                        {result.verification_checks && result.verification_checks.length > 0 && (
                            <div className="bg-green-50 dark:bg-green-900/20 rounded-xl p-5 border border-green-200 dark:border-green-500/20">
                                <h4 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                                    <CheckCircle2 size={18} className="text-green-600 dark:text-green-400" />
                                    Verification Checks
                                </h4>
                                <ul className="space-y-2">
                                    {result.verification_checks.map((check, idx) => (
                                        <li key={idx} className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300">
                                            <CheckCircle2 className="text-green-500 mt-0.5 shrink-0" size={14} />
                                            <span>{check}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {/* Reviews Section */}
                        <div className="bg-white dark:bg-[#1a1d24] rounded-xl p-5 border border-gray-200 dark:border-gray-800 space-y-4">
                            <div className="flex items-center justify-between">
                                <h4 className="font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                    <Star size={18} className="text-amber-500" />
                                    Student Reviews (difficulty perception)
                                </h4>
                                <span className="text-xs text-gray-500 dark:text-gray-400">{reviews.length} reviews</span>
                            </div>

                            {/* Review Form */}
                            <div className="space-y-2">
                                <textarea
                                    value={reviewText}
                                    onChange={(e) => setReviewText(e.target.value)}
                                    placeholder="Share how difficult this topic feels and any tips..."
                                    className="w-full min-h-[80px] px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                                />
                                <div className="flex items-center gap-3">
                                    <select
                                        value={reviewDifficulty}
                                        onChange={(e) => setReviewDifficulty(e.target.value)}
                                        className="px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                                    >
                                        <option value="easy">Easy</option>
                                        <option value="medium">Medium</option>
                                        <option value="hard">Hard</option>
                                        <option value="very_hard">Very Hard</option>
                                    </select>
                                    <motion.button
                                        whileHover={{ scale: 1.02 }}
                                        whileTap={{ scale: 0.98 }}
                                        disabled={isSubmittingReview || !reviewText.trim()}
                                        onClick={handleSubmitReview}
                                        className="px-4 py-2 bg-indigo-500 text-white rounded-lg text-sm font-semibold shadow hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        {isSubmittingReview ? 'Submitting...' : 'Submit Review'}
                                    </motion.button>
                                </div>
                            </div>

                            {/* Reviews List */}
                            <div className="space-y-3 max-h-60 overflow-y-auto pr-1 custom-scrollbar">
                                {reviews.length === 0 && (
                                    <p className="text-sm text-gray-500 dark:text-gray-400">No reviews yet. Be the first to share your experience.</p>
                                )}
                                {reviews.map((rev, idx) => (
                                    <div key={idx} className="p-3 rounded-lg bg-gray-50 dark:bg-[#0f1115] border border-gray-200 dark:border-gray-800">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className={`text-xs font-semibold px-2 py-1 rounded-full ${getDifficultyColor(rev.difficulty)}`}>
                                                {getDifficultyLabel(rev.difficulty)}
                                            </span>
                                            <span className="text-[10px] text-gray-500 dark:text-gray-400">
                                                {rev.created_at ? new Date(rev.created_at).toLocaleString() : 'just now'}
                                            </span>
                                        </div>
                                        <p className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-line">{rev.review_text}</p>
                                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Shared by {rev.user_id || 'student'}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}

