
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import AIAssistant from './ai/AIAssistant';
import { motion } from 'framer-motion';
import { TaskProvider } from '@/context/TaskContext';
import { StudyProvider } from '@/context/StudyContext';
import { FileProvider } from '@/context/FileContext';

export function Layout() {
  return (
    <TaskProvider>
      <StudyProvider>
        <FileProvider>
          <div className="flex h-screen bg-gray-50 dark:bg-[#0a0b1e] text-gray-900 dark:text-white overflow-hidden font-sans transition-colors duration-300">
            <Sidebar />
            <main className="flex-1 relative overflow-y-auto overflow-x-hidden">
              {/* Ambient Background */}
              <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-900/10 rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-900/10 rounded-full blur-[100px]" />
              </div>

              <motion.div
                className="relative z-10 h-full"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <Outlet />
              </motion.div>

              <AIAssistant />
            </main>
          </div>
        </FileProvider>
      </StudyProvider>
    </TaskProvider>
  );
}
