import React, { useState } from 'react';
import { useStudy } from '../context/StudyContext';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, Circle, Clock } from 'lucide-react';
import { format, isToday, isTomorrow } from 'date-fns';
import { cn } from '../utils/cn';
import ReviewModal from './planner/ReviewModal';

export function StudyList() {
  const { sessions, toggleSessionComplete } = useStudy();
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewSession, setReviewSession] = useState(null);

  const handleSessionComplete = (sessionId) => {
    const session = sessions.find(s => s.id === sessionId);
    if (session && !session.completed) {
      toggleSessionComplete(sessionId);
      // Show review modal
      setReviewSession({ title: session.topic || session.subject, topic: session.topic || session.subject });
      setIsReviewModalOpen(true);
    } else {
      toggleSessionComplete(sessionId);
    }
  };

  // Group sessions by date
  const groupedSessions = sessions.reduce((acc, session) => {
    const date = session.date;
    if (!acc[date]) acc[date] = [];
    acc[date].push(session);
    return acc;
  }, {});

  const sortedDates = Object.keys(groupedSessions).sort();

  const getDateLabel = (dateStr) => {
    const date = new Date(dateStr);
    if (isToday(date)) return 'Today';
    if (isTomorrow(date)) return 'Tomorrow';
    return format(date, 'EEEE, MMM d');
  };

  return (
    <>
      <ReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => {
          setIsReviewModalOpen(false);
          setReviewSession(null);
        }}
        sessionTitle={reviewSession?.title || ''}
        sessionTopic={reviewSession?.topic}
        onReviewSubmitted={() => {
          // Could show a success message here
        }}
      />
      <div className="space-y-8">
      {sortedDates.length === 0 && (
        <div className="text-center py-12 text-gray-500 dark:text-gray-400">
          <p>No study sessions scheduled. Add an exam to get started!</p>
        </div>
      )}
      
      {sortedDates.map((date) => (
        <div key={date}>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4 sticky top-0 bg-gray-50 dark:bg-dark-bg py-2 z-10">
            {getDateLabel(date)}
          </h3>
          <div className="space-y-3">
            <AnimatePresence>
              {groupedSessions[date].map((session) => (
                <motion.div
                  key={session.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  layout
                  className={cn(
                    "group flex items-center gap-4 p-4 rounded-xl border transition-all duration-200",
                    session.completed
                      ? "bg-gray-50 dark:bg-dark-surface/50 border-gray-100 dark:border-dark-border opacity-75"
                      : "bg-white dark:bg-dark-surface border-gray-200 dark:border-dark-border shadow-sm hover:shadow-md hover:border-primary-200 dark:hover:border-primary-800"
                  )}
                >
                  <button
                    onClick={() => handleSessionComplete(session.id)}
                    className="flex-shrink-0 text-gray-400 hover:text-primary-500 transition-colors"
                  >
                    {session.completed ? (
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    ) : (
                      <Circle className="w-6 h-6" />
                    )}
                  </button>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className={cn(
                      "font-medium truncate transition-all",
                      session.completed ? "text-gray-500 line-through" : "text-gray-900 dark:text-gray-100"
                    )}>
                      {session.topic}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                      {session.subject} • {session.difficulty}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                    <Clock className="w-4 h-4" />
                    <span>{session.duration}m</span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      ))}
    </div>
    </>
  );
}
