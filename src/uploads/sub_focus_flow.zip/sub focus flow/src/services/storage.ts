/**
 * Storage Abstraction Layer
 * 
 * This allows easy migration from localStorage to a real database later.
 * Simply swap the implementation - all contexts will continue to work.
 */

export interface StorageAdapter {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T): Promise<void>;
  remove(key: string): Promise<void>;
  clear(): Promise<void>;
}

/**
 * LocalStorage Implementation (Current)
 * Use this for development/prototyping
 */
class LocalStorageAdapter implements StorageAdapter {
  async get<T>(key: string): Promise<T | null> {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error(`Error reading from localStorage key "${key}":`, error);
      return null;
    }
  }

  async set<T>(key: string, value: T): Promise<void> {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Error writing to localStorage key "${key}":`, error);
      throw error;
    }
  }

  async remove(key: string): Promise<void> {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error(`Error removing localStorage key "${key}":`, error);
    }
  }

  async clear(): Promise<void> {
    try {
      localStorage.clear();
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  }
}

/**
 * Database Implementation (Future)
 * Replace this with your actual database calls (Firebase, Supabase, MongoDB, etc.)
 */
class DatabaseAdapter implements StorageAdapter {
  private baseUrl: string;

  constructor(baseUrl?: string) {
    this.baseUrl = baseUrl || '/api'; // Adjust to your API endpoint
  }

  async get<T>(key: string): Promise<T | null> {
    try {
      const response = await fetch(`${this.baseUrl}/data/${key}`);
      if (!response.ok) return null;
      return await response.json();
    } catch (error) {
      console.error(`Error fetching from database key "${key}":`, error);
      return null;
    }
  }

  async set<T>(key: string, value: T): Promise<void> {
    try {
      await fetch(`${this.baseUrl}/data/${key}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(value),
      });
    } catch (error) {
      console.error(`Error saving to database key "${key}":`, error);
      throw error;
    }
  }

  async remove(key: string): Promise<void> {
    try {
      await fetch(`${this.baseUrl}/data/${key}`, {
        method: 'DELETE',
      });
    } catch (error) {
      console.error(`Error deleting from database key "${key}":`, error);
    }
  }

  async clear(): Promise<void> {
    // Implement based on your database structure
    console.warn('clear() not implemented for database adapter');
  }
}

/**
 * Storage Service
 * Switch between adapters by changing the instance below
 */
import { SupabaseStorageAdapter } from './supabaseStorage';

// Check if Supabase is configured
const useSupabase = import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY;

const storage: StorageAdapter = useSupabase 
  ? new SupabaseStorageAdapter() 
  : new LocalStorageAdapter();

export default storage;

/**
 * Helper functions for common operations
 */
export const storageHelpers = {
  // Get with default value
  async getWithDefault<T>(key: string, defaultValue: T): Promise<T> {
    const value = await storage.get<T>(key);
    return value ?? defaultValue;
  },

  // Batch operations
  async getMany<T>(keys: string[]): Promise<Record<string, T | null>> {
    const results: Record<string, T | null> = {};
    await Promise.all(
      keys.map(async (key) => {
        results[key] = await storage.get<T>(key);
      })
    );
    return results;
  },

  async setMany<T>(items: Record<string, T>): Promise<void> {
    await Promise.all(
      Object.entries(items).map(([key, value]) => storage.set(key, value))
    );
  },
};

