/**
 * Supabase Storage Adapter
 * Implements the StorageAdapter interface for Supabase
 */

import { supabase, getUserId } from '@/lib/supabase';
import { StorageAdapter } from './storage';

export class SupabaseStorageAdapter implements StorageAdapter {
  /**
   * Get data from Supabase
   * Note: This is a generic implementation. For better performance,
   * you might want to use specific table queries instead.
   */
  async get<T>(key: string): Promise<T | null> {
    try {
      const userId = await getUserId();
      if (!userId) {
        console.warn('User not authenticated. Cannot fetch data.');
        return null;
      }

      // Map localStorage keys to Supabase tables
      const tableMap: Record<string, string> = {
        'tasks': 'tasks',
        'userStats': 'user_stats',
        'exams': 'exams',
        'studySessions': 'study_sessions',
        'files': 'files',
      };

      const tableName = tableMap[key];
      if (!tableName) {
        console.warn(`No table mapping for key: ${key}`);
        return null;
      }

      const { data, error } = await supabase
        .from(tableName)
        .select('*')
        .eq('user_id', userId);

      if (error) {
        console.error(`Error fetching ${key} from Supabase:`, error);
        return null;
      }

      // Transform data based on key
      return this.transformData<T>(key, data);
    } catch (error) {
      console.error(`Error in get(${key}):`, error);
      return null;
    }
  }

  /**
   * Set data in Supabase
   */
  async set<T>(key: string, value: T): Promise<void> {
    try {
      const userId = await getUserId();
      if (!userId) {
        console.warn('User not authenticated. Cannot save data.');
        throw new Error('User not authenticated');
      }

      const tableMap: Record<string, string> = {
        'tasks': 'tasks',
        'userStats': 'user_stats',
        'exams': 'exams',
        'studySessions': 'study_sessions',
        'files': 'files',
      };

      const tableName = tableMap[key];
      if (!tableName) {
        console.warn(`No table mapping for key: ${key}`);
        return;
      }

      // Transform value to Supabase format
      const transformedData = this.transformToSupabase(key, value, userId);

      if (Array.isArray(transformedData)) {
        // For arrays, we need to upsert each item
        const { error } = await supabase
          .from(tableName)
          .upsert(transformedData, { onConflict: 'id' });

        if (error) throw error;
      } else {
        // For single objects (like userStats)
        const { error } = await supabase
          .from(tableName)
          .upsert(transformedData, { onConflict: 'user_id' });

        if (error) throw error;
      }
    } catch (error) {
      console.error(`Error in set(${key}):`, error);
      throw error;
    }
  }

  /**
   * Remove data from Supabase
   */
  async remove(key: string): Promise<void> {
    try {
      const userId = await getUserId();
      if (!userId) {
        console.warn('User not authenticated. Cannot delete data.');
        return;
      }

      const tableMap: Record<string, string> = {
        'tasks': 'tasks',
        'userStats': 'user_stats',
        'exams': 'exams',
        'studySessions': 'study_sessions',
        'files': 'files',
      };

      const tableName = tableMap[key];
      if (!tableName) {
        console.warn(`No table mapping for key: ${key}`);
        return;
      }

      const { error } = await supabase
        .from(tableName)
        .delete()
        .eq('user_id', userId);

      if (error) throw error;
    } catch (error) {
      console.error(`Error in remove(${key}):`, error);
    }
  }

  /**
   * Clear all user data (use with caution!)
   */
  async clear(): Promise<void> {
    console.warn('clear() called - this would delete all user data. Not implemented for safety.');
    // Implement if needed, but be very careful!
  }

  /**
   * Transform localStorage data format to Supabase format
   */
  private transformToSupabase(key: string, value: any, userId: string): any {
    switch (key) {
      case 'tasks':
        return Array.isArray(value)
          ? value.map((task: any) => ({
              id: task.id?.toString() || crypto.randomUUID(),
              user_id: userId,
              text: task.text,
              completed: task.completed || false,
              priority: task.priority || 'medium',
              due_date: task.dueDate || null,
            }))
          : [];

      case 'userStats':
        return {
          user_id: userId,
          xp: value.xp || 0,
          level: value.level || 1,
          tasks_completed: value.tasksCompleted || 0,
          study_sessions_completed: value.studySessionsCompleted || 0,
        };

      case 'exams':
        return Array.isArray(value)
          ? value.map((exam: any) => ({
              id: exam.id?.toString() || crypto.randomUUID(),
              user_id: userId,
              subject: exam.subject,
              date: exam.date,
              difficulty: exam.difficulty || 'medium',
              notes: exam.notes || null,
            }))
          : [];

      case 'studySessions':
        return Array.isArray(value)
          ? value.map((session: any) => ({
              id: session.id?.toString() || crypto.randomUUID(),
              user_id: userId,
              exam_id: session.examId || null,
              subject: session.subject,
              topic: session.topic,
              date: session.date,
              duration: session.duration || 60,
              completed: session.completed || false,
              difficulty: session.difficulty || 'medium',
              notes: session.notes || null,
            }))
          : [];

      case 'files':
        return Array.isArray(value)
          ? value.map((file: any) => ({
              id: file.id?.toString() || crypto.randomUUID(),
              user_id: userId,
              name: file.name,
              size: file.size,
              type: file.type,
              file_type: file.fileType || file.type,
              file_url: file.url || file.file_url,
              subject: file.subject || 'Uncategorized',
              folder_id: file.folderId || null,
              parent_id: file.parentId || null,
              is_folder: file.isFolder || false,
            }))
          : [];

      default:
        return value;
    }
  }

  /**
   * Transform Supabase data format to localStorage format
   */
  private transformData<T>(key: string, data: any): T | null {
    if (!data || (Array.isArray(data) && data.length === 0)) {
      return null;
    }

    switch (key) {
      case 'tasks':
        return (Array.isArray(data)
          ? data.map((task: any) => ({
              id: parseInt(task.id) || Date.now(),
              text: task.text,
              completed: task.completed,
              priority: task.priority,
              dueDate: task.due_date,
            }))
          : []) as T;

      case 'userStats':
        const stats = Array.isArray(data) ? data[0] : data;
        return {
          xp: stats?.xp || 0,
          level: stats?.level || 1,
          tasksCompleted: stats?.tasks_completed || 0,
          studySessionsCompleted: stats?.study_sessions_completed || 0,
        } as T;

      case 'exams':
        return (Array.isArray(data)
          ? data.map((exam: any) => ({
              id: exam.id,
              subject: exam.subject,
              date: exam.date,
              difficulty: exam.difficulty,
              notes: exam.notes,
            }))
          : []) as T;

      case 'studySessions':
        return (Array.isArray(data)
          ? data.map((session: any) => ({
              id: session.id,
              examId: session.exam_id,
              subject: session.subject,
              topic: session.topic,
              date: session.date,
              duration: session.duration,
              completed: session.completed,
              difficulty: session.difficulty,
              notes: session.notes,
            }))
          : []) as T;

      case 'files':
        return (Array.isArray(data)
          ? data.map((file: any) => ({
              id: file.id,
              name: file.name,
              size: file.size,
              type: file.type,
              fileType: file.file_type,
              url: file.file_url,
              subject: file.subject,
              folderId: file.folder_id,
              parentId: file.parent_id,
              isFolder: file.is_folder,
            }))
          : []) as T;

      default:
        return data as T;
    }
  }
}

