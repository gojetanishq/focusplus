/**
 * Apox Engine API Client
 * Connects to the Apox Engine backend for explainable AI features
 */

const API_BASE_URL = import.meta.env.VITE_APOX_API_URL || 'http://localhost:8000';

export interface DifficultyResponse {
    difficulty: string;
    difficulty_score: number;
    reasoning_summary: string[];
    sources: Array<{
        title: string;
        url: string;
        type: string;
        quote: string;
    }>;
    confidence: number;
    verification_checks: string[];
    provenance: {
        source_ids: string[];
        snippet_ids: string[];
        training_example_ids: string[];
        saliency_map?: Record<string, number>;
        reasoning_signals: string[];
        reasoning_summary: string[];
    };
}

export interface ChatResponse {
    answer: string;
    provenance: {
        source_ids: string[];
        snippet_ids: string[];
        training_example_ids: string[];
        reasoning_signals: string[];
    };
    sources: Array<{
        title: string;
        url: string;
        type: string;
        quote: string;
    }>;
    confidence: number;
}

export interface FeedbackRequest {
    response_id: string;
    rating: number;
    disagreement?: string;
    user_id: string;
}

export interface Review {
    topic: string;
    user_id: string;
    difficulty: string;
    review_text: string;
    rating?: number;
    created_at?: string;
}

class ApoxApiClient {
    private baseUrl: string;

    constructor(baseUrl: string = API_BASE_URL) {
        this.baseUrl = baseUrl;
    }

    private async request<T>(
        endpoint: string,
        options: RequestInit = {}
    ): Promise<T> {
        const url = `${this.baseUrl}${endpoint}`;
        
        try {
            const response = await fetch(url, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers,
                },
                mode: 'cors',
            });

            if (!response.ok) {
                throw new Error(`API request failed: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error(`API request failed for ${endpoint}:`, error);
            throw error;
        }
    }

    /**
     * Classify topic difficulty with explainability
     */
    async classifyDifficulty(
        topicText: string,
        userId?: string,
        uploadedFiles: string[] = []
    ): Promise<DifficultyResponse> {
        return this.request<DifficultyResponse>('/ai/difficulty', {
            method: 'POST',
            body: JSON.stringify({
                topicText,
                userId,
                uploadedFiles,
            }),
        });
    }

    /**
     * Chat with explainable responses
     */
    async chat(
        prompt: string,
        contextChunks: string[] = []
    ): Promise<ChatResponse> {
        return this.request<ChatResponse>('/ai/chat', {
            method: 'POST',
            body: JSON.stringify({
                prompt,
                contextChunks,
            }),
        });
    }

    /**
     * Submit feedback for continual learning
     */
    async submitFeedback(feedback: FeedbackRequest): Promise<{ status: string; message: string }> {
        return this.request<{ status: string; message: string }>('/api/feedback', {
            method: 'POST',
            body: JSON.stringify(feedback),
        });
    }

    /**
     * Submit a topic review with user difficulty perception
     */
    async submitReview(review: Review): Promise<Review> {
        return this.request<Review>('/api/reviews', {
            method: 'POST',
            body: JSON.stringify(review),
        });
    }

    /**
     * Get reviews for a topic (or all)
     */
    async getReviews(topic?: string): Promise<Review[]> {
        const query = topic ? `?topic=${encodeURIComponent(topic)}` : '';
        return this.request<Review[]>(`/api/reviews${query}`);
    }

    /**
     * Check API health
     */
    async healthCheck(): Promise<{ status: string; model_loaded: boolean }> {
        try {
            return await this.request<{ status: string; model_loaded: boolean }>('/health');
        } catch {
            return { status: 'unhealthy', model_loaded: false };
        }
    }
}

// Export health check function
export const checkApiHealth = async () => {
    return apoxApi.healthCheck();
}

// Export singleton instance
export const apoxApi = new ApoxApiClient();

// Fallback mock implementation for when API is unavailable
export const apoxApiWithFallback = {
    async classifyDifficulty(
        topicText: string,
        userId?: string,
        uploadedFiles: string[] = []
    ): Promise<DifficultyResponse> {
        try {
            return await apoxApi.classifyDifficulty(topicText, userId, uploadedFiles);
        } catch (error) {
            console.warn('Apox API unavailable, using fallback', error);
            return this.fallbackDifficulty(topicText);
        }
    },

    async chat(prompt: string, contextChunks: string[] = []): Promise<ChatResponse> {
        try {
            return await apoxApi.chat(prompt, contextChunks);
        } catch (error) {
            console.warn('Apox API unavailable, using fallback', error);
            return this.fallbackChat(prompt);
        }
    },

    async submitFeedback(feedback: FeedbackRequest): Promise<{ status: string; message: string }> {
        try {
            return await apoxApi.submitFeedback(feedback);
        } catch (error) {
            console.warn('Apox API unavailable, feedback not saved', error);
            return { status: 'error', message: 'Feedback not saved (API unavailable)' };
        }
    },

    async submitReview(review: Review): Promise<Review> {
        try {
            return await apoxApi.submitReview(review);
        } catch (error) {
            console.warn('Apox API unavailable, review not saved', error);
            return {
                ...review,
                created_at: new Date().toISOString(),
            };
        }
    },

    async getReviews(topic?: string): Promise<Review[]> {
        try {
            return await apoxApi.getReviews(topic);
        } catch (error) {
            console.warn('Apox API unavailable, returning empty reviews', error);
            return [];
        }
    },

    fallbackDifficulty(topicText: string): DifficultyResponse {
        const isMath = /calculus|algebra|integration|derivative|math/i.test(topicText);
        const isHard = /multi|advanced|physics|quantum/i.test(topicText);
        
        return {
            difficulty: isHard ? 'very_hard' : isMath ? 'hard' : 'medium',
            difficulty_score: isHard ? 85 : isMath ? 65 : 45,
            reasoning_summary: [
                isMath ? 'Requires multi-step symbolic logical reasoning.' : 'Primary reasoning type is conceptual understanding.',
                'Context depth is high; relies on prerequisite knowledge.',
                'Cross-domain connections required.',
                'Topic specification is clear but scope is broad.',
                'Precision correctness is critical for valid results.',
            ],
            sources: [
                {
                    title: 'MIT OpenCourseWare',
                    url: 'https://ocw.mit.edu',
                    type: 'ocw',
                    quote: 'Educational content from MIT.',
                },
            ],
            confidence: 0.75,
            verification_checks: ['Fallback mode - verification not available'],
            provenance: {
                source_ids: [],
                snippet_ids: [],
                training_example_ids: [],
                reasoning_signals: isMath ? ['multi_step', 'high_depth'] : ['conceptual'],
                reasoning_summary: [],
            },
        };
    },

    fallbackChat(prompt: string): ChatResponse {
        return {
            answer: `I understand you're asking about "${prompt}". In fallback mode, I can provide general guidance, but for detailed explainable responses, please ensure the Apox Engine API is running.`,
            provenance: {
                source_ids: [],
                snippet_ids: [],
                training_example_ids: [],
                reasoning_signals: ['conceptual'],
            },
            sources: [],
            confidence: 0.5,
        };
    },
};

