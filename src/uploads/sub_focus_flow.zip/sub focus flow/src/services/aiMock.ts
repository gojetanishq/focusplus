
// Simulated AI Service to power the UI capabilities

export const aiMock = {
    // 1. File Intelligence
    generateFileSummary: (_fileName: string) => {
        return new Promise<string[]>((resolve) => {
            setTimeout(() => {
                resolve([
                    "The document discusses the fundamental principles of Linear Algebra, specifically focusing on Vector Spaces.",
                    "Key concepts include Linear Independence, Basis, and Dimension.",
                    "It provides examples of how to determine if a set of vectors spans a subspace.",
                    "Chapter 3 concludes with the Rank-Nullity Theorem and its applications."
                ]);
            }, 1500);
        });
    },

    generateFlashcards: (_fileName: string) => {
        return new Promise<{ q: string, a: string }[]>((resolve) => {
            setTimeout(() => {
                resolve([
                    { q: "What is a Vector Space?", a: "A collection of vectors that can be added together and multiplied by scalars." },
                    { q: "Define Linear Independence.", a: "A set of vectors is linearly independent if no vector in the set can be written as a linear combination of the others." },
                    { q: "What is the Rank-Nullity Theorem?", a: "For a linear map T, dim(Domain) = rank(T) + nullity(T)." },
                    { q: "What is a Basis?", a: "A set of vectors that is both linearly independent and spans the vector space." }
                ]);
            }, 2000);
        });
    },

    // 2. Daily Blueprint
    getDailyBlueprint: () => {
        return new Promise<{ score: number, focus: string[], suggestion: string }>((resolve) => {
            setTimeout(() => {
                resolve({
                    score: 85,
                    focus: ["Linear Algebra", "Physics Lab Prep"],
                    suggestion: "Your energy peaks at 10 AM. Tackle the complex proofs then."
                });
            }, 1000);
        });
    },

    // 3. Chat Assistant - Enhanced with context awareness
    chatWithAI: async (message: string, context?: { tasks?: any[], sessions?: any[], stats?: any }) => {
        return new Promise<string>((resolve) => {
            setTimeout(() => {
                const lower = message.toLowerCase();
                const tasks = context?.tasks || [];
                const sessions = context?.sessions || [];
                const stats = context?.stats || { xp: 0, level: 1, tasksCompleted: 0 };
                const completedTasks = tasks.filter(t => t.completed).length;
                const pendingTasks = tasks.filter(t => !t.completed).length;
                const completedSessions = sessions.filter(s => s.completed).length;
                const upcomingSessions = sessions.filter(s => !s.completed && new Date(s.date) >= new Date()).slice(0, 3);

                // Enhanced response logic with context
                if (lower.includes('hello') || lower.includes('hi') || lower.includes('hey')) {
                    resolve(`Hello! 👋 I'm your Focus Assistant. I can help you with your tasks, study schedule, and productivity tips. You're currently at Level ${stats.level} with ${stats.xp} XP. How can I assist you today?`);
                } else if (lower.includes('task') || lower.includes('todo')) {
                    if (pendingTasks > 0) {
                        const taskList = tasks.filter(t => !t.completed).slice(0, 3).map(t => `• ${t.text}`).join('\n');
                        resolve(`You have ${pendingTasks} pending task${pendingTasks > 1 ? 's' : ''}:\n\n${taskList}\n\nWould you like help prioritizing these? I can suggest which ones to tackle first based on your schedule.`);
                    } else {
                        resolve("Great job! 🎉 You've completed all your tasks. Would you like to add new ones or focus on your study sessions?");
                    }
                } else if (lower.includes('plan') || lower.includes('schedule') || lower.includes('study')) {
                    if (upcomingSessions.length > 0) {
                        const sessionList = upcomingSessions.map(s => `• ${s.subject} - ${s.topic} on ${new Date(s.date).toLocaleDateString()}`).join('\n');
                        resolve(`Here's your upcoming study schedule:\n\n${sessionList}\n\nYou've completed ${completedSessions} session${completedSessions !== 1 ? 's' : ''} so far. Keep up the great work! 💪`);
                    } else {
                        resolve("You don't have any upcoming study sessions scheduled. Would you like me to help you create a study plan? I can suggest optimal study times based on your productivity patterns.");
                    }
                } else if (lower.includes('progress') || lower.includes('stats') || lower.includes('level')) {
                    resolve(`Here's your progress summary:\n\n📊 Level: ${stats.level}\n⭐ XP: ${stats.xp}\n✅ Tasks Completed: ${stats.tasksCompleted}\n📚 Study Sessions Completed: ${completedSessions}\n\nYou're doing great! Keep the momentum going! 🚀`);
                } else if (lower.includes('tired') || lower.includes('burnout') || lower.includes('exhausted')) {
                    resolve("I understand you're feeling tired. Remember, rest is productive! 💤\n\nHere's what I suggest:\n• Take a 20-minute power nap\n• Do a 5-minute breathing exercise\n• Step outside for fresh air\n• Try the Pomodoro technique (25 min work, 5 min break)\n\nYour brain processes information while you rest, so breaks actually improve learning!");
                } else if (lower.includes('motivat') || lower.includes('encourage')) {
                    resolve(`You've accomplished a lot! 🎯\n\n• Completed ${completedTasks} task${completedTasks !== 1 ? 's' : ''}\n• Finished ${completedSessions} study session${completedSessions !== 1 ? 's' : ''}\n• Reached Level ${stats.level}\n\nRemember: Consistency beats perfection. Every small step counts! You've got this! 💪`);
                } else if (lower.includes('help') || lower.includes('what can you do')) {
                    resolve(`I can help you with:\n\n📋 Tasks: Check your tasks, add new ones, prioritize\n📚 Study: Review your schedule, plan sessions\n📊 Progress: Track your stats and achievements\n💡 Tips: Get productivity and study advice\n🎯 Goals: Set and track your goals\n\nJust ask me anything! For example:\n• "Show my tasks"\n• "What's my schedule?"\n• "How can I stay focused?"`);
                } else if (lower.includes('focus') || lower.includes('concentrate') || lower.includes('distract')) {
                    resolve(`Here are proven focus techniques:\n\n1. **Pomodoro Technique**: 25 min focused work, 5 min break\n2. **Time Blocking**: Schedule specific times for tasks\n3. **Eliminate Distractions**: Put phone away, close unnecessary tabs\n4. **Deep Work**: Block 2-3 hours for complex tasks\n5. **Environment**: Clean workspace, good lighting\n\nWant me to help you schedule focused work blocks?`);
                } else if (lower.includes('break') || lower.includes('rest')) {
                    resolve(`Taking breaks is essential! Here are effective break activities:\n\n• 🚶 5-min walk\n• 💧 Hydrate\n• 🧘 5-min meditation\n• 👀 Look at something 20 feet away (eye rest)\n• 🎵 Listen to music\n• 📖 Read something non-academic\n\nAfter your break, you'll return refreshed and more productive!`);
                } else if (lower.includes('revision') || lower.includes('review') || lower.includes('remember')) {
                    const subjects = [...new Set(sessions.map(s => s.subject))];
                    if (subjects.length > 0) {
                        resolve(`Based on your study sessions, here's what you should review:\n\n${subjects.slice(0, 3).map(s => `• ${s}`).join('\n')}\n\nSpaced repetition is key! Review material after 1 day, 3 days, and 1 week for optimal retention. Want me to create a review schedule?`);
                    } else {
                        resolve("Spaced repetition is crucial for learning! Review material:\n• After 1 day\n• After 3 days\n• After 1 week\n• After 1 month\n\nThis helps move information from short-term to long-term memory. Want me to help you set up a review schedule?");
                    }
                } else if (lower.includes('exam') || lower.includes('test')) {
                    const upcomingExams = sessions.filter(s => s.examId && !s.completed);
                    if (upcomingExams.length > 0) {
                        resolve(`You have upcoming exam preparation sessions scheduled. Here's how to maximize your exam prep:\n\n1. **Active Recall**: Test yourself instead of just re-reading\n2. **Practice Problems**: Do past papers and exercises\n3. **Teach Others**: Explain concepts to solidify understanding\n4. **Sleep Well**: 7-9 hours before the exam\n5. **Review Notes**: Quick review the morning of\n\nYou've got ${upcomingExams.length} preparation sessions planned. Stay consistent! 📚`);
                    } else {
                        resolve("For effective exam preparation:\n\n1. Start early (2-3 weeks before)\n2. Create a study schedule\n3. Use active recall techniques\n4. Practice with past papers\n5. Get enough sleep\n6. Stay hydrated\n\nWant me to help you create an exam prep schedule?");
                    }
                } else if (lower.includes('time') || lower.includes('when')) {
                    const now = new Date();
                    const hour = now.getHours();
                    let suggestion = "";
                    if (hour >= 6 && hour < 10) {
                        suggestion = "Morning is perfect for complex, analytical work! Your brain is fresh and alert.";
                    } else if (hour >= 10 && hour < 14) {
                        suggestion = "Midday is great for collaborative work and meetings. Save deep work for later.";
                    } else if (hour >= 14 && hour < 18) {
                        suggestion = "Afternoon is ideal for creative tasks and problem-solving. Your brain is warmed up!";
                    } else {
                        suggestion = "Evening is good for review and lighter tasks. Avoid heavy cognitive work late at night.";
                    }
                    resolve(`Current time: ${now.toLocaleTimeString()}\n\n${suggestion}\n\nBest study times:\n• 6-10 AM: Complex learning\n• 2-5 PM: Problem-solving\n• 7-9 PM: Review and light reading\n\nWant me to help schedule tasks at optimal times?`);
                } else if (lower.includes('goal') || lower.includes('achieve')) {
                    resolve(`Setting goals is powerful! Here's how:\n\n1. **SMART Goals**: Specific, Measurable, Achievable, Relevant, Time-bound\n2. **Break Down**: Divide big goals into smaller steps\n3. **Track Progress**: Monitor daily/weekly\n4. **Celebrate Wins**: Acknowledge achievements\n5. **Adjust**: Be flexible and adapt\n\nYou're currently Level ${stats.level}. What would you like to achieve next?`);
                } else {
                    // Contextual fallback responses
                    const responses = [
                        `That's a great question! Based on your current progress (Level ${stats.level}, ${completedTasks} tasks done), I'd suggest focusing on consistency. What specific area would you like help with?`,
                        `Interesting! You've completed ${completedTasks} tasks and ${completedSessions} study sessions. How can I help you improve further?`,
                        `I understand. With ${pendingTasks} pending tasks and ${upcomingSessions.length} upcoming sessions, let's prioritize. What's most important to you right now?`,
                        `Great point! You're making excellent progress. Would you like help with:\n• Task management\n• Study planning\n• Productivity tips\n• Goal setting\n\nWhat interests you most?`
                    ];
                    resolve(responses[Math.floor(Math.random() * responses.length)]);
                }
            }, 800 + Math.random() * 800); // Variable delay for more natural feel
        });
    },
    // 4. Explainable AI (XAI) for Difficulty
    evaluateTopicDifficulty: (topic: string) => {
        return new Promise<any>((resolve) => {
            setTimeout(() => {
                // Simulate reasoning based on topic keywords
                const isMath = topic.toLowerCase().match(/calculus|algebra|integration|derivative|math/);
                const isHard = topic.toLowerCase().match(/multi|advanced|physics|quantum/);

                resolve({
                    topic: topic,
                    difficulty_score: isHard ? 85 : (isMath ? 65 : 45),
                    difficulty_label: isHard ? "Very Hard" : (isMath ? "Hard" : "Medium"),
                    reasoning_summary: [
                        isMath ? "Requires multi-step symbolic logical reasoning." : "Primary reasoning type is conceptual understanding.",
                        "Context depth is high; relies on prerequisite knowledge.",
                        "Cross-domain connections required (Physics/Geometry).",
                        "Topic specification is clear but scope is broad.",
                        "Precision correctness is critical for valid results."
                    ],
                    sources: [
                        {
                            title: "MIT OpenCourseWare: Multivariable Calculus",
                            url: "https://ocw.mit.edu",
                            type: "ocw",
                            quote: "Integration in high dimensions requires visualizing vector fields."
                        },
                        {
                            title: "Standard Mathematical Tables",
                            url: "https://example.com/ref",
                            type: "documentation",
                            quote: "Standard integral forms for reference."
                        }
                    ],
                    confidence: 0.92,
                    assumptions: [
                        "Assuming standard Euclidean space context.",
                        "Assuming student has completed Calculus I & II."
                    ],
                    verification_checks: [
                        "Symbolic verification using WolframAlpha",
                        "Cross-reference with Thomas' Calculus textbook examples"
                    ],
                    suggested_next_steps: [
                        "Review Partial Derivatives",
                        "Practice Double Integrals on rectangular regions",
                        "Visualize vector fields using Geogebra"
                    ],
                    student_review_prompt: "On a scale of 1-5, how challenging was the last problem set on this topic?"
                });
            }, 2000);
        });
    }
};
