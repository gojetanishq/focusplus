import React from 'react';
import { TaskProvider } from '../context/TaskContext';
import { TaskList } from '../components/TaskList';

export default function TaskManager() {
  return (
    <TaskProvider>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-purple-600 bg-clip-text text-transparent">
            Task Manager
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Level up your productivity.
          </p>
        </div>

        <TaskList />
      </div>
    </TaskProvider>
  );
}
