import React from 'react';
import { motion } from 'framer-motion';
import { useMotion } from '../utils/motion';
import { Play, CheckCircle, Plus, Upload, Search, FileText, Clock, TrendingUp } from 'lucide-react';
import { AreaChart, Area, ResponsiveContainer, Tooltip } from 'recharts';
import { Link } from 'react-router-dom';

const mockChartData = [
  { name: 'Mon', minutes: 45 },
  { name: 'Tue', minutes: 90 },
  { name: 'Wed', minutes: 60 },
  { name: 'Thu', minutes: 120 },
  { name: 'Fri', minutes: 75 },
  { name: 'Sat', minutes: 30 },
  { name: 'Sun', minutes: 60 },
];

export default function Dashboard() {
  const { variants, tokens } = useMotion();

  return (
    <motion.div
      variants={variants.container}
      initial="initial"
      animate="animate"
      className="space-y-8"
    >
      {/* Hero Section */}
      <motion.div variants={variants.item} className="relative overflow-hidden bg-gradient-to-br from-primary-900 to-slate-900 rounded-3xl p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">Good afternoon, Scholar!</h1>
            <p className="text-primary-200">You're on a 5-day streak. Keep it up!</p>
            
            <div className="mt-6 flex items-center gap-4">
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10">
                <TrendingUp className="w-5 h-5 text-green-400" />
                <span className="font-medium">Level 5</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10">
                <Clock className="w-5 h-5 text-blue-400" />
                <span className="font-medium">Next: Physics Review</span>
              </div>
            </div>
          </div>

          <div className="w-full md:w-64 h-32">
             <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockChartData}>
                <defs>
                  <linearGradient id="colorMinutes" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                  itemStyle={{ color: '#38bdf8' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="minutes" 
                  stroke="#38bdf8" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorMinutes)" 
                  animationDuration={2000}
                  animationEasing="ease-out"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Parallax Blob */}
        <motion.div
          variants={variants.blob}
          animate="animate"
          className="absolute top-[-50%] right-[-10%] w-96 h-96 bg-primary-500/30 rounded-full blur-3xl"
        />
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Column A: Today's Agenda */}
        <motion.div variants={variants.item} className="lg:col-span-1 space-y-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary-500" />
            Today's Agenda
          </h2>
          <div className="space-y-3">
            {[
              { time: '10:00 AM', title: 'Math Review', status: 'Done' },
              { time: '02:00 PM', title: 'Physics Chapter 5', status: 'Next' },
              { time: '04:00 PM', title: 'History Essay', status: 'Later' },
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={variants.item}
                whileHover={variants.softHover}
                className="bg-white dark:bg-dark-surface p-4 rounded-2xl border border-gray-200 dark:border-dark-border shadow-sm flex items-center gap-4 group cursor-pointer"
              >
                <div className="text-sm font-medium text-gray-500 dark:text-gray-400 w-16">{item.time}</div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100">{item.title}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      item.status === 'Done' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                      item.status === 'Next' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                      'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                </div>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="p-2 hover:bg-gray-100 dark:hover:bg-dark-border rounded-lg">
                    <CheckCircle className="w-5 h-5 text-gray-400 hover:text-green-500" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Column B: Quick Actions */}
        <motion.div variants={variants.item} className="lg:col-span-1 space-y-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
            <Plus className="w-5 h-5 text-purple-500" />
            Quick Actions
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <motion.button
              whileHover={variants.softHover}
              whileTap={variants.tap}
              className="bg-gradient-to-br from-red-500 to-orange-500 p-6 rounded-2xl text-white shadow-lg shadow-red-500/20 flex flex-col items-center justify-center gap-3"
            >
              <Play className="w-8 h-8 fill-current" />
              <span className="font-medium">Start Pomodoro</span>
            </motion.button>
            <motion.button
              whileHover={variants.softHover}
              whileTap={variants.tap}
              className="bg-white dark:bg-dark-surface p-6 rounded-2xl border border-gray-200 dark:border-dark-border shadow-sm flex flex-col items-center justify-center gap-3 text-gray-600 dark:text-gray-300 hover:border-primary-500 transition-colors"
            >
              <CheckCircle className="w-8 h-8 text-green-500" />
              <span className="font-medium">Mark Day Done</span>
            </motion.button>
            <motion.button
              whileHover={variants.softHover}
              whileTap={variants.tap}
              className="bg-white dark:bg-dark-surface p-6 rounded-2xl border border-gray-200 dark:border-dark-border shadow-sm flex flex-col items-center justify-center gap-3 text-gray-600 dark:text-gray-300 hover:border-primary-500 transition-colors"
            >
              <Plus className="w-8 h-8 text-blue-500" />
              <span className="font-medium">Add Task</span>
            </motion.button>
            <motion.button
              whileHover={variants.softHover}
              whileTap={variants.tap}
              className="bg-white dark:bg-dark-surface p-6 rounded-2xl border border-gray-200 dark:border-dark-border shadow-sm flex flex-col items-center justify-center gap-3 text-gray-600 dark:text-gray-300 hover:border-primary-500 transition-colors"
            >
              <Upload className="w-8 h-8 text-purple-500" />
              <span className="font-medium">Upload File</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Column C: Resources */}
        <motion.div variants={variants.item} className="lg:col-span-1 space-y-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
            <FileText className="w-5 h-5 text-yellow-500" />
            Recent Files
          </h2>
          
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search files..." 
              className="w-full pl-10 pr-4 py-2 bg-white dark:bg-dark-surface border border-gray-200 dark:border-dark-border rounded-xl focus:ring-2 focus:ring-primary-500 outline-none transition-all"
            />
          </div>

          <div className="space-y-3">
            {[1, 2, 3].map((_, i) => (
              <motion.div
                key={i}
                variants={variants.item}
                whileHover={variants.softHover}
                className="flex items-center gap-3 p-3 bg-white dark:bg-dark-surface rounded-xl border border-gray-200 dark:border-dark-border shadow-sm"
              >
                <div className="w-10 h-10 bg-gray-100 dark:bg-dark-bg rounded-lg flex items-center justify-center text-gray-500">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="h-4 w-3/4 bg-gray-200 dark:bg-dark-border rounded animate-pulse mb-2" />
                  <div className="h-3 w-1/2 bg-gray-100 dark:bg-dark-border/50 rounded animate-pulse" />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
