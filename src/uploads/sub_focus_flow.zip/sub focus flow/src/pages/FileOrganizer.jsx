import React from 'react';
import { FileProvider } from '../context/FileContext';
import { FileManager } from '../components/FileManager';

export default function FileOrganizer() {
  return (
    <FileProvider>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-purple-600 bg-clip-text text-transparent">
            File Organizer
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Smart storage for your study materials.
          </p>
        </div>

        <FileManager />
      </div>
    </FileProvider>
  );
}
