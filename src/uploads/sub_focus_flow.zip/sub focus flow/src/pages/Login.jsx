import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useMotion } from '../utils/motion';
import { Mail, Lock, ArrowRight, Github, Loader2 } from 'lucide-react';
import { cn } from '../utils/cn';

export default function Login() {
  const navigate = useNavigate();
  const { variants, tokens } = useMotion();
  const [loading, setLoading] = useState(false);
  const [focusedField, setFocusedField] = useState(null);

  const handleLogin = (e) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      navigate('/');
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full flex bg-gray-50 dark:bg-dark-bg overflow-hidden relative">
      {/* Parallax Background Blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          variants={variants.blob}
          animate="animate"
          className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] bg-primary-200/30 dark:bg-primary-900/10 rounded-full blur-3xl"
        />
        <motion.div
          variants={variants.blob}
          animate="animate"
          transition={{ delay: 2, duration: 12 }}
          className="absolute bottom-[-10%] right-[-10%] w-[40vw] h-[40vw] bg-purple-200/30 dark:bg-purple-900/10 rounded-full blur-3xl"
        />
      </div>

      {/* Left Side - Hero (Desktop) */}
      <div className="hidden lg:flex w-1/2 flex-col justify-center p-16 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: tokens.duration.lazy, ease: tokens.easing.soft }}
        >
          <h1 className="text-6xl font-bold bg-gradient-to-r from-primary-600 to-purple-600 bg-clip-text text-transparent mb-6">
            FocusFlow
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-md leading-relaxed">
            Your lazy, intelligent productivity ecosystem. Plan less, achieve more.
          </p>
        </motion.div>
      </div>

      {/* Right Side - Login Card */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 relative z-10">
        <motion.div
          variants={variants.item}
          initial="initial"
          animate="animate"
          className="w-full max-w-md bg-white/80 dark:bg-dark-surface/80 backdrop-blur-xl p-8 rounded-3xl shadow-xl border border-white/20 dark:border-white/5"
        >
          <div className="mb-8 text-center lg:text-left">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Welcome back</h2>
            <p className="text-gray-500 dark:text-gray-400 mt-2">Enter your details to access your workspace.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            {/* Email Field */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Mail className={cn("w-5 h-5 transition-colors", focusedField === 'email' ? "text-primary-500" : "text-gray-400")} />
              </div>
              <input
                type="email"
                placeholder="Email address"
                className="w-full pl-11 pr-4 py-3 bg-gray-50 dark:bg-dark-bg rounded-xl border-none ring-1 ring-gray-200 dark:ring-dark-border focus:ring-2 focus:ring-primary-500/50 outline-none transition-all"
                onFocus={() => setFocusedField('email')}
                onBlur={() => setFocusedField(null)}
              />
              <motion.div 
                initial={{ scaleX: 0 }}
                animate={{ scaleX: focusedField === 'email' ? 1 : 0 }}
                className="absolute bottom-0 left-2 right-2 h-[2px] bg-primary-500 origin-left"
              />
            </div>

            {/* Password Field */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Lock className={cn("w-5 h-5 transition-colors", focusedField === 'password' ? "text-primary-500" : "text-gray-400")} />
              </div>
              <input
                type="password"
                placeholder="Password"
                className="w-full pl-11 pr-4 py-3 bg-gray-50 dark:bg-dark-bg rounded-xl border-none ring-1 ring-gray-200 dark:ring-dark-border focus:ring-2 focus:ring-primary-500/50 outline-none transition-all"
                onFocus={() => setFocusedField('password')}
                onBlur={() => setFocusedField(null)}
              />
              <motion.div 
                initial={{ scaleX: 0 }}
                animate={{ scaleX: focusedField === 'password' ? 1 : 0 }}
                className="absolute bottom-0 left-2 right-2 h-[2px] bg-primary-500 origin-left"
              />
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 text-gray-600 dark:text-gray-400 cursor-pointer">
                <input type="checkbox" className="rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                Remember me
              </label>
              <a href="#" className="text-primary-600 hover:text-primary-700 font-medium">Forgot password?</a>
            </div>

            <motion.button
              whileHover={variants.softHover}
              whileTap={variants.tap}
              disabled={loading}
              className="w-full py-3 bg-primary-600 text-white rounded-xl font-medium shadow-lg shadow-primary-500/30 hover:bg-primary-700 transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  Sign In <ArrowRight className="w-4 h-4" />
                </>
              )}
            </motion.button>
          </form>

          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200 dark:border-dark-border" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-dark-surface text-gray-500">Or continue with</span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-4">
              <motion.button
                whileHover={variants.softHover}
                whileTap={variants.tap}
                className="flex items-center justify-center gap-2 px-4 py-2 border border-gray-200 dark:border-dark-border rounded-xl hover:bg-gray-50 dark:hover:bg-dark-border/50 transition-colors"
              >
                <Github className="w-5 h-5" />
                <span className="text-sm font-medium">GitHub</span>
              </motion.button>
              <motion.button
                whileHover={variants.softHover}
                whileTap={variants.tap}
                className="flex items-center justify-center gap-2 px-4 py-2 border border-gray-200 dark:border-dark-border rounded-xl hover:bg-gray-50 dark:hover:bg-dark-border/50 transition-colors"
              >
                <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-blue-500 to-green-500" />
                <span className="text-sm font-medium">Google</span>
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
