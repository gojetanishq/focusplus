
import { motion } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import { pageTransition, containerStagger, listItem } from '@/lib/motion';
import { Trophy, Medal, Crown, Flame, Zap } from 'lucide-react';

export default function Achievements() {
    const badges = [
        { name: "Early Bird", desc: "Complete 5 morning sessions", icon: Zap, color: "text-yellow-400 bg-yellow-400/10", unlocked: true },
        { name: "Focus Master", desc: "100 hours of total focus", icon: Crown, color: "text-purple-400 bg-purple-400/10", unlocked: true },
        { name: "On Fire", desc: "Maintain a 7-day streak", icon: Flame, color: "text-orange-400 bg-orange-400/10", unlocked: true },
        { name: "Task Slayer", desc: "Complete 50 tasks", icon: Medal, color: "text-blue-400 bg-blue-400/10", unlocked: false },
        { name: "Scholar", desc: "Ace 3 exams in a row", icon: Trophy, color: "text-green-400 bg-green-400/10", unlocked: false },
    ];

    return (
        <motion.div
            variants={pageTransition}
            initial="initial"
            animate="animate"
            exit="exit"
            className="p-6 md:p-8 max-w-7xl mx-auto space-y-8"
        >
            <div className="text-center py-8">
                <h1 className="text-4xl font-bold text-white mb-2">Your Hall of Fame</h1>
                <p className="text-gray-400">Collect badges by reaching your productivity milestones.</p>
            </div>

            <motion.div
                variants={containerStagger}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6"
            >
                {badges.map((badge, i) => (
                    <motion.div key={i} variants={listItem}>
                        <MotionCard
                            className={`flex flex-col items-center text-center gap-4 h-full relative overflow-hidden ${!badge.unlocked && 'opacity-50 grayscale'}`}
                            whileHover={{ y: -5 }}
                        >
                            <div className={`w-20 h-20 rounded-full flex items-center justify-center ${badge.color} mb-2`}>
                                <badge.icon size={40} />
                            </div>
                            <div>
                                <h3 className="font-bold text-gray-200">{badge.name}</h3>
                                <p className="text-xs text-gray-500 mt-1">{badge.desc}</p>
                            </div>

                            {!badge.unlocked && (
                                <div className="absolute inset-0 flex items-center justify-center bg-gray-900/60 backdrop-blur-[1px]">
                                    <span className="text-xs font-bold uppercase tracking-widest text-gray-400 border border-gray-600 px-2 py-1 rounded">Locked</span>
                                </div>
                            )}
                        </MotionCard>
                    </motion.div>
                ))}
            </motion.div>
        </motion.div>
    );
}
