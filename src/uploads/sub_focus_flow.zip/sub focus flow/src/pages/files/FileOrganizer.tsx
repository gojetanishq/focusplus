
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import MotionButton from '@/components/ui/MotionButton';
import FilePreviewModal from '@/components/files/FilePreviewModal';
import AddFolderModal from '@/components/files/AddFolderModal';
import { pageTransition, containerStagger, listItem } from '@/lib/motion';
import { Folder, FileText, UploadCloud, ChevronRight, Home, Trash2, LayoutGrid, List as ListIcon, FolderPlus } from 'lucide-react';
import { cn } from '@/lib/utils';

// Define the shape of our file system items
interface FileSystemItem {
    id: string;
    parentId: string | null; // null means root directory
    type: 'folder' | 'file';
    name: string;
    fileType?: string; // only for files (pdf, img, etc)
    size?: string; // only for files
    url?: string; // only for files
    itemCount?: number; // only for folders
}

export default function FileOrganizer() {
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
    const [previewFile, setPreviewFile] = useState<FileSystemItem | null>(null);
    const [isAddFolderOpen, setIsAddFolderOpen] = useState(false);
    const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

    // Initial State: Mocking a file system
    const [items, setItems] = useState<FileSystemItem[]>([
        // Folders (Root)
        { id: 'f1', parentId: null, type: 'folder', name: 'University', itemCount: 2 },
        { id: 'f2', parentId: null, type: 'folder', name: 'Projects', itemCount: 1 },
        { id: 'f3', parentId: null, type: 'folder', name: 'Personal', itemCount: 0 },
        // Files (Root)
        { id: 'file1', parentId: null, type: 'file', name: 'Thesis_Draft_v2.pdf', fileType: 'pdf', size: '2.4 MB' },

        // Nested Items (Inside University)
        { id: 'sub1', parentId: 'f1', type: 'folder', name: 'Sem 1', itemCount: 0 },
        { id: 'file2', parentId: 'f1', type: 'file', name: 'Physics_Notes.pdf', fileType: 'pdf', size: '1.2 MB' },

        // Nested Items (Inside Projects)
        { id: 'file3', parentId: 'f2', type: 'file', name: 'Design.png', fileType: 'img', size: '4 MB' },
    ]);

    // Derived: Current View Items
    const currentItems = items.filter(item => item.parentId === currentFolderId);
    const folders = currentItems.filter(i => i.type === 'folder');
    const files = currentItems.filter(i => i.type === 'file');

    // Derived: Breadcrumbs Path
    const getBreadcrumbs = () => {
        const path = [];
        let curr = currentFolderId;
        while (curr) {
            const folder = items.find(i => i.id === curr);
            if (folder) {
                path.unshift(folder);
                curr = folder.parentId;
            } else {
                break;
            }
        }
        return path;
    };

    const breadcrumbs = getBreadcrumbs();

    // ACTIONS
    const handleCreateFolder = (name: string) => {
        const newFolder: FileSystemItem = {
            id: Date.now().toString(),
            parentId: currentFolderId,
            type: 'folder',
            name,
            itemCount: 0
        };
        setItems([...items, newFolder]);
    };

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            handleFileUpload(file);
        }
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        const file = e.dataTransfer.files?.[0];
        if (file) {
            handleFileUpload(file);
        }
    };

    const handleFileUpload = (file: File) => {
        const newFile: FileSystemItem = {
            id: Date.now().toString(),
            parentId: currentFolderId,
            type: 'file',
            name: file.name,
            fileType: file.type.startsWith('image/') ? 'img' : file.name.split('.').pop() || 'unknown',
            size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
            url: URL.createObjectURL(file),
        };

        // Also update parent folder count if strictly tracking it (optional, redundant if dynamic)
        setItems(prev => [...prev, newFile]);
    };

    const handleDelete = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        // If folder, delete recursive? For simplicity, yes, delete specific item. 
        // Real app would check for children.
        // Simple recursive delete:
        const deleteRecursive = (itemId: string, currentList: FileSystemItem[]): FileSystemItem[] => {
            const children = currentList.filter(i => i.parentId === itemId);
            let newList = currentList.filter(i => i.id !== itemId);
            children.forEach(child => {
                newList = deleteRecursive(child.id, newList);
            });
            return newList;
        };

        setItems(prev => deleteRecursive(id, prev));
    };

    return (
        <motion.div
            variants={pageTransition}
            initial="initial"
            animate="animate"
            exit="exit"
            className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 min-h-screen"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
        >
            <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileChange}
            />

            <AddFolderModal
                isOpen={isAddFolderOpen}
                onClose={() => setIsAddFolderOpen(false)}
                onCreate={handleCreateFolder}
            />

            <FilePreviewModal
                isOpen={!!previewFile}
                onClose={() => setPreviewFile(null)}
                file={previewFile ? { ...previewFile, type: previewFile.fileType || 'unknown' } : null}
            />

            {/* Header & Breadcrumbs */}
            <div className="flex flex-col gap-4">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Smart Storage</h1>
                        <p className="text-gray-500 dark:text-gray-400 mt-1">Manage and organize your documents</p>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="bg-white dark:bg-gray-800 p-1 rounded-lg border border-gray-200 dark:border-gray-700 flex items-center">
                            <button
                                onClick={() => setViewMode('grid')}
                                className={cn(
                                    "p-2 rounded-md transition-colors",
                                    viewMode === 'grid' ? "bg-indigo-50 dark:bg-indigo-500/20 text-indigo-500 dark:text-indigo-400" : "text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                                )}
                            >
                                <LayoutGrid size={18} />
                            </button>
                            <button
                                onClick={() => setViewMode('list')}
                                className={cn(
                                    "p-2 rounded-md transition-colors",
                                    viewMode === 'list' ? "bg-indigo-50 dark:bg-indigo-500/20 text-indigo-500 dark:text-indigo-400" : "text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                                )}
                            >
                                <ListIcon size={18} />
                            </button>
                        </div>
                        <MotionButton variant="outline" onClick={() => setIsAddFolderOpen(true)}>
                            <FolderPlus size={18} className="mr-2" /> New Folder
                        </MotionButton>
                        <MotionButton onClick={handleUploadClick}>
                            <UploadCloud size={18} className="mr-2" /> Upload
                        </MotionButton>
                    </div>
                </div>

                {/* Breadcrumbs Bar */}
                <div className="flex items-center gap-2 overflow-x-auto pb-2 text-sm">
                    <button
                        onClick={() => setCurrentFolderId(null)}
                        className={cn(
                            "flex items-center gap-1 hover:text-indigo-500 transition-colors px-2 py-1 rounded-md",
                            currentFolderId === null ? "text-gray-900 dark:text-white font-semibold bg-gray-100 dark:bg-gray-800" : "text-gray-500 dark:text-gray-400"
                        )}
                    >
                        <Home size={14} /> Home
                    </button>
                    {breadcrumbs.map((folder, idx) => (
                        <div key={folder.id} className="flex items-center gap-2">
                            <ChevronRight size={14} className="text-gray-300 dark:text-gray-600" />
                            <button
                                onClick={() => setCurrentFolderId(folder.id)}
                                className={cn(
                                    "hover:text-indigo-500 transition-colors px-2 py-1 rounded-md whitespace-nowrap",
                                    idx === breadcrumbs.length - 1 ? "text-gray-900 dark:text-white font-semibold bg-gray-100 dark:bg-gray-800" : "text-gray-500 dark:text-gray-400"
                                )}
                            >
                                {folder.name}
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            {/* Folders Section */}
            {folders.length > 0 && (
                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-300 px-1">Folders</h2>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {folders.map((folder) => (
                            <MotionCard
                                key={folder.id}
                                className="flex items-center gap-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors group relative"
                                onClick={() => setCurrentFolderId(folder.id)}
                                whileHover={{ y: -4 }}
                            >
                                <div className="w-10 h-10 rounded-lg bg-indigo-500/10 dark:bg-indigo-500/20 flex items-center justify-center text-indigo-500 dark:text-indigo-400 flex-shrink-0">
                                    <Folder size={20} fill="currentColor" fillOpacity={0.2} />
                                </div>
                                <div className="min-w-0 flex-1">
                                    <p className="font-semibold text-gray-900 dark:text-gray-200 truncate">{folder.name}</p>
                                    <p className="text-xs text-gray-500">{items.filter(i => i.parentId === folder.id).length} items</p>
                                </div>
                                <button
                                    onClick={(e) => handleDelete(e, folder.id)}
                                    className="absolute top-2 right-2 p-1.5 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-all opacity-0 group-hover:opacity-100"
                                >
                                    <Trash2 size={14} />
                                </button>
                            </MotionCard>
                        ))}
                    </div>
                </div>
            )}

            {/* Files Section */}
            <div className="space-y-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-300 px-1">Files</h2>
                <AnimatePresence mode="popLayout">
                    {files.length === 0 ? (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="flex flex-col items-center justify-center h-64 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-2xl"
                        >
                            <UploadCloud size={48} className="text-gray-300 dark:text-gray-600 mb-4" />
                            <p className="text-gray-500 dark:text-gray-400 font-medium">No files in this folder</p>
                            <p className="text-sm text-gray-400 dark:text-gray-500">Upload or drag and drop files here</p>
                        </motion.div>
                    ) : (
                        <motion.div
                            variants={containerStagger}
                            initial="hidden"
                            animate="visible"
                            className={cn(
                                "grid gap-4",
                                viewMode === 'grid' ? "grid-cols-2 md:grid-cols-4 lg:grid-cols-5" : "grid-cols-1"
                            )}
                        >
                            {files.map((file) => (
                                <motion.div
                                    key={file.id}
                                    variants={listItem}
                                    layout
                                    onClick={() => setPreviewFile(file)}
                                >
                                    <div className={cn(
                                        "group relative overflow-hidden rounded-xl border border-gray-200 dark:border-gray-700/50 bg-white dark:bg-gray-900/50 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all cursor-pointer h-full",
                                        viewMode === 'grid' ? "p-4 flex flex-col" : "p-3 flex items-center gap-4"
                                    )}>
                                        <button
                                            onClick={(e) => handleDelete(e, file.id)}
                                            className="absolute top-2 right-2 p-1.5 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-all opacity-0 group-hover:opacity-100 z-10"
                                        >
                                            <Trash2 size={14} />
                                        </button>

                                        <div className={cn(
                                            "rounded-xl bg-gray-100 dark:bg-gray-800 group-hover:bg-gray-200 dark:group-hover:bg-gray-700 flex items-center justify-center text-gray-400 dark:text-gray-500 group-hover:text-indigo-500 dark:group-hover:text-indigo-400 transition-colors",
                                            viewMode === 'grid' ? "w-full aspect-square mb-4" : "w-12 h-12 flex-shrink-0"
                                        )}>
                                            {file.fileType === 'img' ? (
                                                file.url ? <img src={file.url} alt={file.name} className="w-full h-full object-cover rounded-xl" /> : <FileText size={viewMode === 'grid' ? 32 : 24} />
                                            ) : (
                                                <FileText size={viewMode === 'grid' ? 32 : 24} />
                                            )}
                                        </div>
                                        <div className={cn("min-w-0", viewMode === 'grid' && "text-center")}>
                                            <p className="font-medium text-gray-900 dark:text-gray-200 truncate text-sm">{file.name}</p>
                                            <p className="text-xs text-gray-500">{file.size}</p>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </motion.div>
    );
}
