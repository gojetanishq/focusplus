
import { useState } from 'react';
import { motion } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import MotionButton from '@/components/ui/MotionButton';
import AddSessionModal from '@/components/planner/AddSessionModal';
import ReviewModal from '@/components/planner/ReviewModal';
import { pageTransition, containerStagger, listItem } from '@/lib/motion';
import { Calendar as CalendarIcon, Clock, ChevronLeft, ChevronRight, Sparkles, BrainCircuit, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function StudyPlanner() {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [isAIAnalyzing, setIsAIAnalyzing] = useState(false);
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [reviewSession, setReviewSession] = useState<{ title: string; topic?: string } | null>(null);

    // Mock initial sessions with Date objects for proper comparison
    const [sessions, setSessions] = useState([
        { id: '1', title: "Linear Algebra", date: new Date(new Date().setHours(10, 0, 0, 0)), duration: "90m", type: "Lecture", difficulty: "High", completed: false },
        { id: '2', title: "Physics Lab", date: new Date(new Date().setHours(14, 0, 0, 0)), duration: "120m", type: "Lab", difficulty: "Medium", completed: false },
        { id: '3', title: "Kanji Practice", date: new Date(new Date().setHours(17, 0, 0, 0)), duration: "45m", type: "Self-Study", difficulty: "Low", completed: false }
    ]);

    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    // Calendar Logic
    const getDaysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    const getFirstDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay();

    const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

    const handleDateClick = (day: number) => {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
        setSelectedDate(date);
        setIsAddModalOpen(true);
    };

    const handleAddSession = (newSession: any) => {
        setSessions(prev => [...prev, newSession].sort((a, b) => a.date.getTime() - b.date.getTime()));
    };

    const handleSessionComplete = (sessionId: string) => {
        const session = sessions.find(s => s.id === sessionId);
        if (session && !session.completed) {
            // Mark as completed
            setSessions(prev => prev.map(s => 
                s.id === sessionId ? { ...s, completed: true } : s
            ));
            // Show review modal
            setReviewSession({ title: session.title, topic: session.title });
            setIsReviewModalOpen(true);
        }
    };

    const handleAIOptimize = () => {
        setIsAIAnalyzing(true);
        setTimeout(() => setIsAIAnalyzing(false), 2000); // Simulate API call
    };

    const renderCalendarGrid = () => {
        const totalDays = getDaysInMonth(currentDate);
        const startDay = getFirstDayOfMonth(currentDate);
        const blanks = Array(startDay).fill(null);
        const dayNumbers = Array.from({ length: totalDays }, (_, i) => i + 1);

        return [...blanks, ...dayNumbers].map((day, index) => {
            if (!day) return <div key={`blank-${index}`} className="h-24 md:h-32 rounded-xl border border-transparent" />;

            const dateObj = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
            const isToday = new Date().toDateString() === dateObj.toDateString();
            const daySessions = sessions.filter(s => s.date.toDateString() === dateObj.toDateString());

            return (
                <div
                    key={day}
                    onClick={() => handleDateClick(day)}
                    className={cn(
                        "h-24 md:h-32 rounded-xl border p-2 text-left relative group transition-all cursor-pointer flex flex-col gap-1 overflow-hidden",
                        isToday
                            ? "bg-indigo-500/10 border-indigo-500 dark:border-indigo-400"
                            : "bg-white dark:bg-gray-800/50 border-gray-200 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-indigo-300 dark:hover:border-indigo-700"
                    )}
                >
                    <span className={cn(
                        "text-sm font-medium w-6 h-6 flex items-center justify-center rounded-full",
                        isToday ? "bg-indigo-500 text-white" : "text-gray-700 dark:text-gray-400"
                    )}>
                        {day}
                    </span>

                    <div className="flex-1 flex flex-col gap-1 overflow-hidden">
                        {daySessions.slice(0, 3).map((session, i) => (
                            <div key={i} className={cn(
                                "text-[10px] px-1.5 py-0.5 rounded truncate font-medium",
                                session.type === 'Exam' ? "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300" :
                                    session.type === 'Lecture' ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300" :
                                        "bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300"
                            )}>
                                {session.title}
                            </div>
                        ))}
                        {daySessions.length > 3 && (
                            <div className="text-[10px] text-gray-400 pl-1">
                                +{daySessions.length - 3} more
                            </div>
                        )}
                    </div>

                    {/* Add Button on Hover */}
                    <div className="absolute inset-0 bg-black/5 dark:bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <PlusIcon />
                    </div>
                </div>
            );
        });
    };

    // Filter sessions for the list view (only future)
    const upcomingSessions = sessions.filter(s => s.date >= new Date()).slice(0, 5);

    return (
        <motion.div
            variants={pageTransition}
            initial="initial"
            animate="animate"
            exit="exit"
            className="p-6 md:p-8 max-w-7xl mx-auto space-y-6"
        >
            <AddSessionModal
                isOpen={isAddModalOpen}
                onClose={() => setIsAddModalOpen(false)}
                onAdd={handleAddSession}
                selectedDate={selectedDate}
            />
            <ReviewModal
                isOpen={isReviewModalOpen}
                onClose={() => {
                    setIsReviewModalOpen(false);
                    setReviewSession(null);
                }}
                sessionTitle={reviewSession?.title || ''}
                sessionTopic={reviewSession?.topic}
                onReviewSubmitted={() => {
                    // Could show a success message here
                }}
            />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center gap-2">
                        Study Planner <span className="bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 text-xs px-2 py-1 rounded-full font-bold tracking-wide uppercase">AI Enabled</span>
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400">Manage your academic schedule with AI optimization.</p>
                </div>
                <div className="flex gap-3">
                    <MotionButton variant="outline" onClick={handleAIOptimize} disabled={isAIAnalyzing}>
                        {isAIAnalyzing ? <RefreshCw className="animate-spin mr-2" size={18} /> : <BrainCircuit size={18} className="mr-2 text-purple-500" />}
                        {isAIAnalyzing ? 'Optimizing...' : 'AI Optimize Schedule'}
                    </MotionButton>
                    <MotionButton onClick={() => { setSelectedDate(new Date()); setIsAddModalOpen(true); }}>
                        <CalendarIcon size={18} className="mr-2" /> Quick Add
                    </MotionButton>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

                {/* LEFT: Calendar (3 cols) */}
                <div className="lg:col-span-3 space-y-6">
                    <MotionCard className="min-h-[600px] p-0 overflow-hidden">
                        {/* Calendar Header */}
                        <div className="p-6 flex items-center justify-between border-b border-gray-200 dark:border-gray-800">
                            <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                                {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
                            </h2>
                            <div className="flex gap-2">
                                <button onClick={prevMonth} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-400 transition-colors"><ChevronLeft size={20} /></button>
                                <button onClick={new Date().toDateString() === currentDate.toDateString() ? undefined : () => setCurrentDate(new Date())} className="px-3 py-1 text-sm font-medium hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-400 transition-colors">Today</button>
                                <button onClick={nextMonth} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-400 transition-colors"><ChevronRight size={20} /></button>
                            </div>
                        </div>

                        {/* Calendar Grid */}
                        <div className="p-6">
                            <div className="grid grid-cols-7 gap-2 text-center mb-4">
                                {days.map(d => <div key={d} className="text-gray-400 dark:text-gray-500 text-xs font-bold uppercase tracking-wider">{d}</div>)}
                            </div>
                            <div className="grid grid-cols-7 gap-2">
                                {renderCalendarGrid()}
                            </div>
                        </div>
                    </MotionCard>
                </div>

                {/* RIGHT: AI Sidebar & Upcoming (1 col) */}
                <div className="space-y-6">
                    {/* AI Insights Panel */}
                    <MotionCard className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 border-indigo-100 dark:border-indigo-500/20">
                        <div className="flex items-center gap-2 mb-4">
                            <div className="p-1.5 bg-indigo-500 rounded-lg text-white">
                                <Sparkles size={16} />
                            </div>
                            <h3 className="font-bold text-gray-900 dark:text-white text-sm">AI Insights</h3>
                        </div>
                        <div className="space-y-3">
                            <div className="p-3 bg-white/60 dark:bg-black/20 rounded-xl border border-indigo-100 dark:border-indigo-500/10 text-sm">
                                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                                    <span className="font-bold text-indigo-600 dark:text-indigo-400">Suggestion:</span> You have a heavy load on Tuesday. Consider moving "Physics Lab" prep to Monday?
                                </p>
                            </div>
                            <div className="p-3 bg-white/60 dark:bg-black/20 rounded-xl border border-indigo-100 dark:border-indigo-500/10 text-sm">
                                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                                    <span className="font-bold text-green-600 dark:text-green-400">Stats:</span> You are most productive between 10 AM - 2 PM based on your streak history.
                                </p>
                            </div>
                        </div>
                        <MotionButton size="sm" variant="ghost" className="w-full mt-4 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-500/10">
                            View Full Analysis
                        </MotionButton>
                    </MotionCard>

                    {/* Upcoming List */}
                    <MotionCard className="h-fit">
                        <h2 className="text-lg font-bold text-gray-900 dark:text-gray-white mb-4">Upcoming</h2>
                        <motion.div variants={containerStagger} initial="hidden" animate="visible" className="space-y-3">
                            {upcomingSessions.length === 0 ? (
                                <p className="text-gray-500 text-sm">No upcoming sessions.</p>
                            ) : (
                                upcomingSessions.map((session, i) => (
                                    <motion.div key={i} variants={listItem}>
                                        <div className="p-3 rounded-xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 hover:border-indigo-500/30 transition-all group">
                                            <div className="flex items-center justify-between mb-1">
                                                <span className={cn(
                                                    "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
                                                    session.difficulty === 'High' ? "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400" : "bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400"
                                                )}>
                                                    {session.type}
                                                </span>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-xs text-gray-400">{session.date.toLocaleDateString([], { weekday: 'short' })}</span>
                                                    {!session.completed && (
                                                        <button
                                                            onClick={() => handleSessionComplete(session.id)}
                                                            className="opacity-0 group-hover:opacity-100 transition-opacity text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300"
                                                        >
                                                            Mark Complete
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                            <h3 className="font-semibold text-gray-900 dark:text-gray-200 text-sm truncate">{session.title}</h3>
                                            <div className="flex items-center gap-2 text-xs text-gray-500 mt-1.5">
                                                <Clock size={12} /> {session.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {session.duration}
                                            </div>
                                        </div>
                                    </motion.div>
                                ))
                            )}
                        </motion.div>
                    </MotionCard>
                </div>
            </div>
        </motion.div>
    );
}

function PlusIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-500">
            <path d="M5 12h14"></path>
            <path d="M12 5v14"></path>
        </svg>
    )
}
