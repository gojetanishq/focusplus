
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import MotionButton from '@/components/ui/MotionButton';
import AddTaskModal from '@/components/tasks/AddTaskModal';
import { pageTransition, containerStagger, listItem } from '@/lib/motion';
import { CheckCircle2, Circle, Trophy, Star, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function TaskManager() {
    const [xp, setXp] = useState(140);
    const [isaddModalOpen, setIsAddModalOpen] = useState(false);

    // Initial tasks state
    const [tasks, setTasks] = useState([
        { id: 1, title: "Complete Physics Chapter 4", xp: 50, completed: false, tag: "Study" },
        { id: 2, title: "Upload Project Proposal", xp: 20, completed: true, tag: "Work" },
        { id: 3, title: "Review Kanji Flashcards", xp: 30, completed: false, tag: "Language" },
        { id: 4, title: "Draft Essay Intro", xp: 40, completed: false, tag: "Writing" },
    ]);

    const toggleTask = (id: number) => {
        setTasks(tasks.map(t => {
            if (t.id === id) {
                // Update XP based on new status
                const newStatus = !t.completed;
                setXp(prev => newStatus ? prev + t.xp : prev - t.xp);
                return { ...t, completed: newStatus };
            }
            return t;
        }));
    };

    const handleAddTask = (newTask: { title: string; xp: number; tag: string }) => {
        const task = {
            id: Date.now(),
            ...newTask,
            completed: false
        };
        setTasks([task, ...tasks]);
    };

    const handleReset = () => {
        // Reset all tasks to incomplete and XP to 0 (or initial?)
        // Per request: "make the xp zero after completion"
        setTasks(tasks.map(t => ({ ...t, completed: false })));
        setXp(0);
    };

    const allCompleted = tasks.length > 0 && tasks.every(t => t.completed);

    return (
        <motion.div
            variants={pageTransition}
            initial="initial"
            animate="animate"
            exit="exit"
            className="p-6 md:p-8 max-w-5xl mx-auto space-y-8"
        >
            <AddTaskModal
                isOpen={isaddModalOpen}
                onClose={() => setIsAddModalOpen(false)}
                onAdd={handleAddTask}
            />

            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Quests & Tasks</h1>
                    <p className="text-gray-500 dark:text-gray-400 mt-1">Manage your daily goals and earn XP.</p>
                </div>

                <div className="flex items-center gap-4">
                    {allCompleted && (
                        <MotionButton
                            onClick={handleReset}
                            className="bg-green-500 hover:bg-green-600 text-white"
                        >
                            <RefreshCw size={18} className="mr-2" /> Prestige Reset
                        </MotionButton>
                    )}

                    <div className="flex items-center gap-2 bg-yellow-500/10 px-4 py-2 rounded-full border border-yellow-500/20 shadow-sm">
                        <Trophy size={18} className="text-yellow-500" />
                        <span className="font-bold text-yellow-600 dark:text-yellow-300">Total XP: {xp}</span>
                    </div>
                </div>
            </div>

            <MotionCard>
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-300">Active Quests</h2>
                    <MotionButton size="sm" onClick={() => setIsAddModalOpen(true)}>Add Quest</MotionButton>
                </div>

                <motion.div
                    variants={containerStagger}
                    initial="hidden"
                    animate="visible"
                    className="space-y-4"
                >
                    <AnimatePresence mode="popLayout">
                        {tasks.map((task) => (
                            <motion.div
                                key={task.id}
                                variants={listItem}
                                layoutId={`task-${task.id}`}
                                layout
                            >
                                <div
                                    onClick={() => toggleTask(task.id)}
                                    className={cn(
                                        "flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all duration-300 group shadow-sm dark:shadow-none",
                                        task.completed
                                            ? "bg-gray-100 dark:bg-gray-900/30 border-gray-200 dark:border-gray-800 opacity-60"
                                            : "bg-white dark:bg-gray-800/50 border-gray-200 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-indigo-500/30"
                                    )}
                                >
                                    <div className="flex items-center gap-4">
                                        <div className={cn(
                                            "w-6 h-6 rounded-full flex items-center justify-center transition-colors",
                                            task.completed ? "text-green-500" : "text-gray-400 dark:text-gray-600 group-hover:text-indigo-500 dark:group-hover:text-indigo-400"
                                        )}>
                                            {task.completed ? <CheckCircle2 /> : <Circle />}
                                        </div>
                                        <div>
                                            <p className={cn(
                                                "font-medium transition-all",
                                                task.completed ? "text-gray-500 line-through" : "text-gray-900 dark:text-gray-200"
                                            )}>
                                                {task.title}
                                            </p>
                                            <span className="text-xs text-gray-500">{task.tag}</span>
                                        </div>
                                    </div>

                                    <div className="flex items-center gap-1 text-xs font-bold text-yellow-600 dark:text-yellow-500 bg-yellow-500/10 px-2 py-1 rounded-full">
                                        {task.xp} XP <Star size={10} fill="currentColor" />
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </motion.div>
            </MotionCard>
        </motion.div>
    );
}
