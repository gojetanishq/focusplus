
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import HeroCard from '@/components/dashboard/HeroCard';
import SessionCard from '@/components/dashboard/SessionCard';
import QuickAction from '@/components/dashboard/QuickAction';
import MotionCard from '@/components/ui/MotionCard';
import { containerStagger, listItem, pageTransition } from '@/lib/motion';
import { Timer, PlusCircle, FolderUp, Trophy, BarChart3, Sparkles, BrainCircuit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { aiMock } from '@/services/aiMock';

export default function Landing() {
    const navigate = useNavigate();
    const [blueprint, setBlueprint] = useState<{ score: number, focus: string[], suggestion: string } | null>(null);

    useEffect(() => {
        // Load AI Blueprint on mount
        aiMock.getDailyBlueprint().then(setBlueprint);
    }, []);

    return (
        <motion.div
            variants={pageTransition}
            initial="initial"
            animate="animate"
            exit="exit"
            className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto mb-20 md:mb-0"
        >
            {/* 1. Hero Section */}
            <motion.div variants={listItem}>
                <HeroCard />
            </motion.div>

            {/* 2. AI Daily Blueprint (NEW) */}
            {blueprint && (
                <motion.div variants={listItem}>
                    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 p-1">
                        <div className="bg-white dark:bg-[#0f1115] rounded-xl p-6 relative z-10 h-full">
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 bg-indigo-500/10 rounded-lg">
                                        <Sparkles size={24} className="text-indigo-500" />
                                    </div>
                                    <div>
                                        <h2 className="text-lg font-bold text-gray-900 dark:text-white">Daily AI Blueprint</h2>
                                        <p className="text-sm text-gray-500 dark:text-gray-400">Your intelligent briefing for today</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4">
                                    <div className="text-right">
                                        <p className="text-xs text-gray-500 uppercase font-bold tracking-wider">Productivity Score</p>
                                        <p className="text-2xl font-bold text-green-500">{blueprint.score}/100</p>
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                    <p className="text-xs font-bold text-indigo-500 uppercase tracking-widest">Recommended Focus</p>
                                    <div className="flex flex-wrap gap-2">
                                        {blueprint.focus.map((topic, i) => (
                                            <span key={i} className="px-3 py-1 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 rounded-lg text-sm font-medium">
                                                {topic}
                                            </span>
                                        ))}
                                    </div>
                                </div>
                                <div className="bg-indigo-50 dark:bg-indigo-500/5 p-4 rounded-xl border border-indigo-100 dark:border-indigo-500/10 flex gap-3">
                                    <BrainCircuit size={20} className="text-indigo-500 shrink-0 mt-0.5" />
                                    <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed font-medium">
                                        "{blueprint.suggestion}"
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </motion.div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                {/* 3. Main Feed (Agenda) */}
                <div className="lg:col-span-2 space-y-6">
                    <motion.div variants={listItem} className="flex items-center justify-between">
                        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Today's Agenda</h2>
                        <button
                            onClick={() => navigate('/study')}
                            className="text-sm text-indigo-400 hover:text-indigo-300"
                        >
                            View Calendar
                        </button>
                    </motion.div>

                    <motion.div
                        variants={containerStagger}
                        initial="hidden"
                        animate="visible"
                        className="space-y-4"
                    >
                        {[
                            { 
                                title: "Advanced Calculus II", 
                                duration: "1h 30m", 
                                difficulty: "Hard" as const, 
                                time: "10:00 AM",
                                aiReasoning: {
                                    score: 85,
                                    reasoning_summary: [
                                        "Requires multi-step symbolic logical reasoning with abstract mathematical concepts",
                                        "High context depth - relies heavily on prerequisite knowledge from Calculus I",
                                        "Cross-domain connections required (algebra, geometry, and analysis)",
                                        "Precision correctness is critical - small errors compound significantly",
                                        "Involves complex problem-solving with multiple solution paths"
                                    ],
                                    reasoning_signals: ["multi_step", "high_depth", "abstract_reasoning", "symbolic_manipulation"],
                                    sources: [
                                        {
                                            title: "MIT OpenCourseWare: Multivariable Calculus",
                                            url: "https://ocw.mit.edu",
                                            type: "ocw",
                                            quote: "Integration in high dimensions requires visualizing vector fields and understanding geometric interpretations."
                                        },
                                        {
                                            title: "Thomas' Calculus: Early Transcendentals",
                                            url: "https://example.com/thomas-calculus",
                                            type: "textbook",
                                            quote: "Advanced techniques require mastery of fundamental principles and their applications."
                                        }
                                    ],
                                    confidence: 0.92
                                }
                            },
                            { 
                                title: "React Physics Engine", 
                                duration: "45m", 
                                difficulty: "Medium" as const, 
                                time: "2:00 PM",
                                aiReasoning: {
                                    score: 55,
                                    reasoning_summary: [
                                        "Combines programming concepts with physics principles",
                                        "Moderate complexity - requires understanding of both domains",
                                        "Practical application focus with clear implementation patterns",
                                        "Well-documented frameworks reduce learning curve",
                                        "Iterative problem-solving approach is effective"
                                    ],
                                    reasoning_signals: ["practical_application", "cross_domain", "iterative"],
                                    sources: [
                                        {
                                            title: "React Documentation: Advanced Patterns",
                                            url: "https://react.dev",
                                            type: "documentation",
                                            quote: "React's component model enables efficient state management for complex simulations."
                                        },
                                        {
                                            title: "Physics Engine Design Patterns",
                                            url: "https://example.com/physics-engines",
                                            type: "technical_guide",
                                            quote: "Modern physics engines leverage efficient algorithms for collision detection and dynamics."
                                        }
                                    ],
                                    confidence: 0.78
                                }
                            },
                            { 
                                title: "Japanese Kanji Review", 
                                duration: "30m", 
                                difficulty: "Easy" as const, 
                                time: "4:30 PM",
                                aiReasoning: {
                                    score: 25,
                                    reasoning_summary: [
                                        "Primarily memorization-based with established learning patterns",
                                        "Low cognitive load - familiar characters and structures",
                                        "Repetitive practice is highly effective for retention",
                                        "Clear visual patterns aid recognition and recall",
                                        "Review sessions reinforce existing knowledge rather than introducing new concepts"
                                    ],
                                    reasoning_signals: ["memorization", "pattern_recognition", "repetition"],
                                    sources: [
                                        {
                                            title: "Spaced Repetition Systems for Kanji Learning",
                                            url: "https://example.com/kanji-learning",
                                            type: "learning_method",
                                            quote: "Regular review sessions significantly improve long-term retention of kanji characters."
                                        }
                                    ],
                                    confidence: 0.88
                                }
                            },
                        ].map((session, i) => (
                            <motion.div key={i} variants={listItem}>
                                <SessionCard {...session} />
                            </motion.div>
                        ))}
                    </motion.div>

                    {/* Recent Files */}
                    <motion.div variants={listItem} className="pt-4">
                        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Recent Files</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                            {[1, 2, 3].map((i) => (
                                <MotionCard
                                    key={i}
                                    onClick={() => navigate('/files')}
                                    className="h-32 flex flex-col justify-end p-4 bg-white dark:bg-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer border border-gray-200 dark:border-none shadow-sm dark:shadow-none"
                                >
                                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 mb-auto" />
                                    <p className="font-medium text-sm text-gray-900 dark:text-gray-200">Project_Notes_{i}.pdf</p>
                                    <p className="text-xs text-gray-500">Edited 2h ago</p>
                                </MotionCard>
                            ))}
                        </div>
                    </motion.div>
                </div>

                {/* 4. Sidebar (Quick Actions & Charts) */}
                <div className="space-y-6">
                    <motion.div variants={listItem}>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Quick Actions</h2>
                        <div className="grid grid-cols-2 gap-3">
                            <QuickAction icon={Timer} label="Focus" color="bg-red-500" onClick={() => navigate('/study')} />
                            <QuickAction icon={PlusCircle} label="Add Task" color="bg-blue-500" onClick={() => navigate('/tasks')} />
                            <QuickAction icon={FolderUp} label="Upload" color="bg-yellow-500" onClick={() => navigate('/files')} />
                            <QuickAction icon={Trophy} label="Goals" color="bg-green-500" onClick={() => navigate('/achievements')} />
                        </div>
                    </motion.div>

                    <motion.div variants={listItem}>
                        <MotionCard className="min-h-[250px] relative overflow-hidden bg-white dark:bg-gray-800/50 border border-gray-200 dark:border-none shadow-sm dark:shadow-none">
                            <h3 className="font-bold text-gray-900 dark:text-gray-200 mb-4 flex items-center gap-2">
                                <BarChart3 size={18} /> Activity Log
                            </h3>
                            {/* Placeholder Chart */}
                            <div className="flex items-end gap-2 h-40 w-full px-2">
                                {[40, 70, 45, 90, 60, 80, 50].map((h, i) => (
                                    <motion.div
                                        key={i}
                                        initial={{ height: 0 }}
                                        animate={{ height: `${h}%` }}
                                        transition={{ duration: 1, delay: i * 0.1, ease: "backOut" }}
                                        className="flex-1 bg-indigo-500/30 rounded-t-sm hover:bg-indigo-500/50 transition-colors"
                                    />
                                ))}
                            </div>
                        </MotionCard>
                    </motion.div>
                </div>

            </div>
        </motion.div>
    );
}
