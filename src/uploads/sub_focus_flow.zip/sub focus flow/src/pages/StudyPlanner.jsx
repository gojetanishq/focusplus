import React from 'react';
import { StudyProvider } from '../context/StudyContext';
import { StudyForm } from '../components/StudyForm';
import { StudyList } from '../components/StudyList';

export default function StudyPlanner() {
  return (
    <StudyProvider>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-purple-600 bg-clip-text text-transparent">
            Study Planner
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Smart scheduling for your academic success.
          </p>
        </div>

        <StudyForm />
        <StudyList />
      </div>
    </StudyProvider>
  );
}
