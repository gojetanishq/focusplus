import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import AuthCard from '@/components/ui/AuthCard';
import InputField from '@/components/ui/InputField';
import MotionButton from '@/components/ui/MotionButton';
import { containerStagger, listItem } from '@/lib/motion';
import { useAuth } from '@/context/AuthContext';

export default function Register() {
    const navigate = useNavigate();
    const { signUp, user, loading: authLoading } = useAuth();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState(false);
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    // Redirect if already logged in
    useEffect(() => {
        if (!authLoading && user) {
            navigate('/landing');
        }
    }, [user, authLoading, navigate]);

    const handleRegister = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccess(false);

        // Validation
        if (!username || !email || !password || !confirmPassword) {
            setError('Please fill in all fields');
            return;
        }

        if (password !== confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        if (password.length < 6) {
            setError('Password must be at least 6 characters');
            return;
        }

        setLoading(true);

        const { error: signUpError } = await signUp(email, password, username);

        if (signUpError) {
            setError(signUpError.message || 'Failed to create account. Please try again.');
            setLoading(false);
        } else {
            setSuccess(true);
            setLoading(false);
            // Show success message and redirect after a delay
            setTimeout(() => {
                navigate('/login');
            }, 2000);
        }
    };

    return (
        <AuthCard
            title="Create an Account"
            subtitle="Join the FocusPlus ecosystem today!"
        >
            <motion.form
                variants={containerStagger}
                initial="hidden"
                animate="visible"
                onSubmit={handleRegister}
                className="space-y-4"
            >
                {error && (
                    <motion.div
                        variants={listItem}
                        className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm"
                    >
                        {error}
                    </motion.div>
                )}

                {success && (
                    <motion.div
                        variants={listItem}
                        className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm"
                    >
                        Account created successfully! Redirecting to login...
                    </motion.div>
                )}

                <motion.div variants={listItem}>
                    <InputField
                        label="Username"
                        type="text"
                        placeholder="CoolUser123"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        disabled={loading}
                    />
                </motion.div>

                <motion.div variants={listItem}>
                    <InputField
                        label="Email"
                        type="email"
                        placeholder="johndoe@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        disabled={loading}
                    />
                </motion.div>

                <motion.div variants={listItem}>
                    <InputField
                        label="Password"
                        type="password"
                        placeholder="Safe & Secure (min. 6 characters)"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        disabled={loading}
                    />
                </motion.div>

                <motion.div variants={listItem}>
                    <InputField
                        label="Confirm Password"
                        type="password"
                        placeholder="One more time"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        disabled={loading}
                    />
                </motion.div>

                <motion.div variants={listItem} className="pt-2">
                    <MotionButton
                        type="submit"
                        className="w-full"
                        disabled={loading}
                    >
                        {loading ? "Creating Account..." : "Continue"}
                    </MotionButton>
                </motion.div>

                <motion.div variants={listItem} className="text-sm text-gray-400 mt-4">
                    Already have an account?{' '}
                    <Link to="/login" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                        Log In
                    </Link>
                </motion.div>
            </motion.form>
        </AuthCard>
    );
}
