import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import AuthCard from '@/components/ui/AuthCard';
import InputField from '@/components/ui/InputField';
import MotionButton from '@/components/ui/MotionButton';
import { containerStagger, listItem } from '@/lib/motion';
import { useAuth } from '@/context/AuthContext';

export default function Login() {
    const navigate = useNavigate();
    const { signIn, user, loading: authLoading } = useAuth();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    // Redirect if already logged in
    useEffect(() => {
        if (!authLoading && user) {
            navigate('/landing');
        }
    }, [user, authLoading, navigate]);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setLoading(true);

        if (!email || !password) {
            setError('Please fill in all fields');
            setLoading(false);
            return;
        }

        const { error: signInError } = await signIn(email, password);

        if (signInError) {
            setError(signInError.message || 'Failed to sign in. Please check your credentials.');
            setLoading(false);
        } else {
            navigate('/landing');
        }
    };

    return (
        <AuthCard
            title="Welcome Back!"
            subtitle="We're so excited to see you again!"
        >
            <motion.form
                variants={containerStagger}
                initial="hidden"
                animate="visible"
                onSubmit={handleLogin}
                className="space-y-4"
            >
                {error && (
                    <motion.div
                        variants={listItem}
                        className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm"
                    >
                        {error}
                    </motion.div>
                )}

                <motion.div variants={listItem}>
                    <InputField
                        label="Email"
                        type="email"
                        placeholder="johndoe@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        disabled={loading}
                    />
                </motion.div>

                <motion.div variants={listItem}>
                    <InputField
                        label="Password"
                        type="password"
                        placeholder="Your secret password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        disabled={loading}
                    />
                    <Link
                        to="/forgot-password"
                        className="text-xs text-indigo-400 hover:text-indigo-300 mt-1 inline-block transition-colors"
                    >
                        Forgot your password?
                    </Link>
                </motion.div>

                <motion.div variants={listItem} className="pt-2">
                    <MotionButton
                        type="submit"
                        className="w-full"
                        disabled={loading}
                    >
                        {loading ? (
                            <span className="flex items-center gap-2">
                                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                Logging in...
                            </span>
                        ) : "Log In"}
                    </MotionButton>
                </motion.div>

                <motion.div variants={listItem} className="text-sm text-gray-400 mt-4">
                    Need an account?{' '}
                    <Link to="/register" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                        Register
                    </Link>
                </motion.div>
            </motion.form>
        </AuthCard>
    );
}
