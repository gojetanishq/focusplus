
import { motion } from 'framer-motion';
import MotionCard from '@/components/ui/MotionCard';
import { pageTransition } from '@/lib/motion';

export default function Settings() {
    return (
        <motion.div
            variants={pageTransition}
            initial="initial"
            animate="animate"
            exit="exit"
            className="p-6 md:p-8 max-w-3xl mx-auto"
        >
            <h1 className="text-3xl font-bold text-white mb-8">Settings</h1>

            <div className="space-y-6">
                <MotionCard>
                    <h2 className="text-lg font-semibold text-gray-200 mb-4">Account</h2>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-gray-700/50">
                            <span className="text-gray-400">Email</span>
                            <span className="text-gray-200">johndoe@example.com</span>
                        </div>
                        <div className="flex justify-between items-center py-2">
                            <span className="text-gray-400">Password</span>
                            <button className="text-indigo-400 text-sm hover:underline">Change Password</button>
                        </div>
                    </div>
                </MotionCard>

                <MotionCard>
                    <h2 className="text-lg font-semibold text-gray-200 mb-4">Preferences</h2>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Theme</span>
                            <select className="bg-gray-900 border border-gray-700 text-gray-200 text-sm rounded-lg px-3 py-2">
                                <option>Dark (Default)</option>
                                <option>Light</option>
                                <option>System</option>
                            </select>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-gray-400">Reduced Motion</span>
                            <div className="w-10 h-6 bg-gray-700 rounded-full relative cursor-pointer">
                                <div className="w-4 h-4 bg-white rounded-full absolute top-1 left-1" />
                            </div>
                        </div>
                    </div>
                </MotionCard>
            </div>
        </motion.div>
    );
}
