
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './components/theme/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { Layout } from './components/Layout';
import ProtectedRoute from './components/auth/ProtectedRoute';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Landing from './pages/dashboard/Landing';
import StudyPlanner from './pages/planner/StudyPlanner';
import TaskManager from './pages/tasks/TaskManager';
import FileOrganizer from './pages/files/FileOrganizer';
import Achievements from './pages/achievements/Achievements';
import Settings from './pages/settings/Settings';

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Navigate to="/landing" replace />} />
              <Route path="landing" element={<Landing />} />
              <Route path="study" element={<StudyPlanner />} />
              <Route path="tasks" element={<TaskManager />} />
              <Route path="files" element={<FileOrganizer />} />
              <Route path="achievements" element={<Achievements />} />
              <Route path="settings" element={<Settings />} />
            </Route>
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
