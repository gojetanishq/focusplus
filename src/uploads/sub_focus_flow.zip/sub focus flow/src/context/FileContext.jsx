import React, { createContext, useContext, useState, useEffect } from 'react';
import storage from '@/services/storage';

const FileContext = createContext();

export function useFiles() {
  return useContext(FileContext);
}

export function FileProvider({ children }) {
  const [files, setFiles] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load data on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        
        const savedFiles = await storage.get('files');
        
        if (savedFiles) {
          setFiles(savedFiles);
        } else {
          const localFiles = localStorage.getItem('files');
          if (localFiles) {
            const parsed = JSON.parse(localFiles);
            setFiles(parsed);
            await storage.set('files', parsed);
          }
        }
      } catch (error) {
        console.error('Error loading files:', error);
        const localFiles = localStorage.getItem('files');
        if (localFiles) setFiles(JSON.parse(localFiles));
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // Save files when they change
  useEffect(() => {
    if (!isLoading && files.length >= 0) {
      storage.set('files', files).catch(err => {
        console.error('Error saving files:', err);
        localStorage.setItem('files', JSON.stringify(files));
      });
    }
  }, [files, isLoading]);

  const addFile = (file) => {
    // Mock upload logic
    const newFile = {
      id: Date.now(),
      name: file.name,
      size: (file.size / 1024 / 1024).toFixed(2) + ' MB',
      type: file.type,
      subject: 'Uncategorized', // Placeholder for "Smart" categorization
      date: new Date().toISOString(),
    };
    setFiles(prev => [...prev, newFile]);
  };

  const deleteFile = (id) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  return (
    <FileContext.Provider value={{ files, addFile, deleteFile }}>
      {children}
    </FileContext.Provider>
  );
}
