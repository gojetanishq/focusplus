import React, { createContext, useContext, useState, useEffect } from 'react';
import { addDays, differenceInDays, format } from 'date-fns';
import storage from '@/services/storage';

const StudyContext = createContext();

export function useStudy() {
  return useContext(StudyContext);
}

export function StudyProvider({ children }) {
  const [exams, setExams] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load data on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        
        const savedExams = await storage.get('exams');
        const savedSessions = await storage.get('studySessions');
        
        if (savedExams) {
          setExams(savedExams);
        } else {
          const localExams = localStorage.getItem('exams');
          if (localExams) {
            const parsed = JSON.parse(localExams);
            setExams(parsed);
            await storage.set('exams', parsed);
          }
        }
        
        if (savedSessions) {
          setSessions(savedSessions);
        } else {
          const localSessions = localStorage.getItem('studySessions');
          if (localSessions) {
            const parsed = JSON.parse(localSessions);
            setSessions(parsed);
            await storage.set('studySessions', parsed);
          }
        }
      } catch (error) {
        console.error('Error loading study data:', error);
        const localExams = localStorage.getItem('exams');
        const localSessions = localStorage.getItem('studySessions');
        if (localExams) setExams(JSON.parse(localExams));
        if (localSessions) setSessions(JSON.parse(localSessions));
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // Save exams when they change
  useEffect(() => {
    if (!isLoading && exams.length >= 0) {
      storage.set('exams', exams).catch(err => {
        console.error('Error saving exams:', err);
        localStorage.setItem('exams', JSON.stringify(exams));
      });
    }
  }, [exams, isLoading]);

  // Save sessions when they change
  useEffect(() => {
    if (!isLoading && sessions.length >= 0) {
      storage.set('studySessions', sessions).catch(err => {
        console.error('Error saving study sessions:', err);
        localStorage.setItem('studySessions', JSON.stringify(sessions));
      });
    }
  }, [sessions, isLoading]);

  const addExam = (exam) => {
    setExams([...exams, { ...exam, id: Date.now().toString() }]);
    generateSchedule({ ...exam, id: Date.now().toString() });
  };

  const generateSchedule = (exam) => {
    // Simple deterministic scheduling algorithm
    const daysUntilExam = differenceInDays(new Date(exam.date), new Date());
    if (daysUntilExam <= 0) return;

    const newSessions = [];
    let currentDate = new Date();

    // Distribute study sessions
    for (let i = 0; i < daysUntilExam; i++) {
      currentDate = addDays(currentDate, 1);
      // Skip weekends for heavy study if desired, but for now we schedule every day
      newSessions.push({
        id: Date.now().toString() + i,
        examId: exam.id,
        subject: exam.subject,
        topic: `Review for ${exam.subject} - Part ${i + 1}`,
        date: format(currentDate, 'yyyy-MM-dd'),
        duration: 60, // 60 minutes default
        completed: false,
        difficulty: exam.difficulty,
      });
    }

    setSessions(prev => [...prev, ...newSessions]);
  };

  const toggleSessionComplete = (sessionId) => {
    setSessions(prev => prev.map(session => 
      session.id === sessionId ? { ...session, completed: !session.completed } : session
    ));
  };

  return (
    <StudyContext.Provider value={{ exams, sessions, addExam, toggleSessionComplete }}>
      {children}
    </StudyContext.Provider>
  );
}
