import React, { createContext, useContext, useState, useEffect } from 'react';
import storage from '@/services/storage';

const TaskContext = createContext();

export function useTasks() {
  return useContext(TaskContext);
}

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useState([]);
  const [userStats, setUserStats] = useState({ xp: 0, level: 1, tasksCompleted: 0 });
  const [isLoading, setIsLoading] = useState(true);

  // Load data on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        
        // Try to load from storage (Supabase or localStorage)
        const savedTasks = await storage.get('tasks');
        const savedStats = await storage.get('userStats');
        
        // Fallback to localStorage if storage returns null
        if (savedTasks) {
          setTasks(savedTasks);
        } else {
          const localTasks = localStorage.getItem('tasks');
          if (localTasks) {
            const parsed = JSON.parse(localTasks);
            setTasks(parsed);
            // Migrate to storage
            await storage.set('tasks', parsed);
          }
        }
        
        if (savedStats) {
          setUserStats(savedStats);
        } else {
          const localStats = localStorage.getItem('userStats');
          if (localStats) {
            const parsed = JSON.parse(localStats);
            setUserStats(parsed);
            // Migrate to storage
            await storage.set('userStats', parsed);
          } else {
            // Initialize stats if they don't exist
            const defaultStats = { xp: 0, level: 1, tasksCompleted: 0 };
            setUserStats(defaultStats);
            await storage.set('userStats', defaultStats);
          }
        }
      } catch (error) {
        console.error('Error loading tasks:', error);
        // Fallback to localStorage
        const localTasks = localStorage.getItem('tasks');
        const localStats = localStorage.getItem('userStats');
        if (localTasks) setTasks(JSON.parse(localTasks));
        if (localStats) setUserStats(JSON.parse(localStats));
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, []);

  // Save tasks when they change
  useEffect(() => {
    if (!isLoading && tasks.length >= 0) {
      storage.set('tasks', tasks).catch(err => {
        console.error('Error saving tasks:', err);
        // Fallback to localStorage
        localStorage.setItem('tasks', JSON.stringify(tasks));
      });
    }
  }, [tasks, isLoading]);

  // Save stats when they change
  useEffect(() => {
    if (!isLoading) {
      storage.set('userStats', userStats).catch(err => {
        console.error('Error saving user stats:', err);
        // Fallback to localStorage
        localStorage.setItem('userStats', JSON.stringify(userStats));
      });
    }
  }, [userStats, isLoading]);

  const addTask = (text) => {
    setTasks([...tasks, { id: Date.now(), text, completed: false }]);
  };

  const toggleTask = (id) => {
    setTasks(prev => prev.map(task => {
      if (task.id === id) {
        const newCompleted = !task.completed;
        if (newCompleted) {
          // Award XP
          setUserStats(prevStats => {
            const newXP = prevStats.xp + 10;
            const newLevel = Math.floor(newXP / 100) + 1;
            return {
              ...prevStats,
              xp: newXP,
              level: newLevel,
              tasksCompleted: prevStats.tasksCompleted + 1
            };
          });
        }
        return { ...task, completed: newCompleted };
      }
      return task;
    }));
  };

  const deleteTask = (id) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  return (
    <TaskContext.Provider value={{ tasks, addTask, toggleTask, deleteTask, userStats }}>
      {children}
    </TaskContext.Provider>
  );
}
