import { Variants } from 'framer-motion';

// -----------------------------------------------------------------------------
// Animation Tokens (Discord-like "Soft & Floaty")
// -----------------------------------------------------------------------------

export const Easing = {
    soft: [0.22, 0.9, 0.36, 1], // The "Discord" ease
    bounce: [0.34, 1.56, 0.64, 1],
} as const;

export const Duration = {
    fast: 0.12,
    normal: 0.24,
    medium: 0.36,
    relaxed: 0.48,
    slow: 0.9,
} as const;

// -----------------------------------------------------------------------------
// Reusable Motion Variants
// -----------------------------------------------------------------------------

export const pageTransition: Variants = {
    initial: { opacity: 0, y: 16 },
    animate: {
        opacity: 1,
        y: 0,
        transition: {
            duration: Duration.medium,
            ease: Easing.soft,
            staggerChildren: 0.05,
        }
    },
    exit: {
        opacity: 0,
        y: -16,
        transition: { duration: Duration.normal, ease: 'easeIn' }
    }
};

export const cardEnter: Variants = {
    hidden: { opacity: 0, y: 12, scale: 0.98 },
    visible: {
        opacity: 1,
        y: 0,
        scale: 1,
        transition: {
            duration: Duration.relaxed,
            ease: Easing.soft
        }
    },
};

export const containerStagger: Variants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.05,
            delayChildren: 0.1,
        }
    }
};

export const listItem: Variants = {
    hidden: { opacity: 0, x: -8 },
    visible: {
        opacity: 1,
        x: 0,
        transition: { duration: Duration.normal }
    }
};

export const buttonHover: Variants = {
    rest: { scale: 1, y: 0 },
    hover: {
        scale: 1.02,
        y: -1,
        transition: { duration: Duration.fast, ease: 'linear' }
    },
    tap: { scale: 0.98 }
};

export const float: Variants = {
    animate: {
        y: [0, -6, 0],
        transition: {
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
        }
    }
};
