import { useReducedMotion } from 'framer-motion';

// Motion Tokens
export const motionTokens = {
  easing: {
    soft: [0.22, 0.9, 0.36, 1], // Discord-like lazy easing
    spring: { type: "spring", damping: 18, stiffness: 120 },
  },
  duration: {
    micro: 0.12,
    fast: 0.15,
    medium: 0.3,
    slow: 0.5,
    lazy: 0.9,
  },
  stagger: {
    fast: 0.04,
    default: 0.06,
    slow: 0.1,
  },
};

// Reusable Variants
export const variants = {
  // Page Transitions
  page: {
    initial: { opacity: 0, y: 16 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { duration: motionTokens.duration.medium, ease: motionTokens.easing.soft }
    },
    exit: { 
      opacity: 0, 
      y: -16,
      transition: { duration: motionTokens.duration.fast, ease: motionTokens.easing.soft }
    },
  },

  // Lazy Loading Cards (Staggered)
  container: {
    animate: {
      transition: {
        staggerChildren: motionTokens.stagger.default,
      },
    },
  },
  item: {
    initial: { opacity: 0, y: 20, scale: 0.98 },
    animate: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { duration: motionTokens.duration.medium, ease: motionTokens.easing.soft }
    },
    exit: { 
      opacity: 0, 
      scale: 0.95, 
      transition: { duration: motionTokens.duration.fast } 
    },
  },

  // Micro-interactions
  softHover: {
    scale: 1.02,
    y: -2,
    transition: { duration: motionTokens.duration.medium, ease: motionTokens.easing.soft },
  },
  tap: {
    scale: 0.98,
    transition: { duration: motionTokens.duration.micro },
  },
  
  // Confetti / Level Up
  pop: {
    initial: { scale: 0.5, opacity: 0 },
    animate: { 
      scale: [1.2, 1], 
      opacity: 1,
      transition: motionTokens.easing.spring
    },
  },
  
  // Parallax Blobs
  blob: {
    animate: {
      y: [0, -20, 0],
      rotate: [0, 5, -5, 0],
      transition: {
        duration: 10,
        repeat: Infinity,
        ease: "easeInOut",
      },
    },
  },
};

// Helper for reduced motion
export const useMotion = () => {
  const shouldReduceMotion = useReducedMotion();
  
  return {
    variants: shouldReduceMotion ? {
      // Simplified variants for reduced motion
      page: { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } },
      container: { animate: {} },
      item: { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } },
      softHover: {},
      tap: {},
      pop: { initial: { opacity: 0 }, animate: { opacity: 1 } },
      blob: {},
    } : variants,
    tokens: motionTokens,
  };
};
