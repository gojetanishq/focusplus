#!/usr/bin/env python3
"""
LoRA Fine-Tuning Script for Apox Engine
Supports curriculum learning, explainability logging, and provenance tracking.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass

import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
)
from peft import LoraConfig, get_peft_model, TaskType
from datasets import load_dataset
import hydra
from omegaconf import DictConfig, OmegaConf

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ProvenanceTracker:
    """Track provenance for explainability"""
    source_ids: List[str]
    snippet_ids: List[str]
    training_example_ids: List[str]
    
    def to_dict(self):
        return {
            "source_ids": self.source_ids,
            "snippet_ids": self.snippet_ids,
            "training_example_ids": self.training_example_ids
        }


class ExplainableTrainer(Trainer):
    """Extended Trainer with explainability logging"""
    
    def __init__(self, *args, explainability_config=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.explainability_config = explainability_config or {}
        self.provenance_logs = []
        
    def log(self, logs: Dict[str, float]) -> None:
        """Override log to add provenance tracking"""
        super().log(logs)
        
        if self.explainability_config.get("log_provenance", False):
            # Log provenance metadata
            if hasattr(self, "current_provenance"):
                self.provenance_logs.append(self.current_provenance)


def load_and_preprocess_data(
    train_path: str,
    val_path: str,
    tokenizer,
    max_length: int = 512,
    curriculum_stage: Optional[str] = None
) -> tuple:
    """Load and preprocess training data"""
    
    def filter_by_curriculum(example, stage):
        """Filter examples based on curriculum stage"""
        if not stage:
            return True
        
        reasoning_signals = example.get("reasoning_signals", [])
        
        if stage == "simple":
            return "multi_step" not in reasoning_signals
        elif stage == "factual":
            return "high_depth" not in reasoning_signals
        elif stage == "complex":
            return True
        return True
    
    def tokenize_function(examples):
        """Tokenize examples"""
        prompts = examples["prompt"]
        responses = examples["response"]
        
        # Format as instruction-following
        texts = [
            f"### Instruction:\n{p}\n\n### Response:\n{r}\n\n### End"
            for p, r in zip(prompts, responses)
        ]
        
        tokenized = tokenizer(
            texts,
            truncation=True,
            max_length=max_length,
            padding="max_length",
            return_tensors="pt"
        )
        
        tokenized["labels"] = tokenized["input_ids"].clone()
        return tokenized
    
    # Load datasets
    train_dataset = load_dataset("json", data_files=train_path, split="train")
    val_dataset = load_dataset("json", data_files=val_path, split="train")
    
    # Apply curriculum filtering
    if curriculum_stage:
        train_dataset = train_dataset.filter(
            lambda x: filter_by_curriculum(x, curriculum_stage)
        )
    
    # Tokenize
    train_dataset = train_dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=train_dataset.column_names
    )
    
    val_dataset = val_dataset.map(
        tokenize_function,
        batched=True,
        remove_columns=val_dataset.column_names
    )
    
    return train_dataset, val_dataset


def compute_combined_metric(eval_pred):
    """Compute combined metric for model selection"""
    predictions, labels = eval_pred
    
    # Simple perplexity-based metric
    # In production, combine with classification accuracy, calibration, etc.
    loss = torch.nn.functional.cross_entropy(
        torch.tensor(predictions).reshape(-1, predictions.shape[-1]),
        torch.tensor(labels).reshape(-1),
        ignore_index=-100
    )
    
    perplexity = torch.exp(loss).item()
    
    return {
        "perplexity": perplexity,
        "combined_metric": 1.0 / (1.0 + perplexity)  # Higher is better
    }


@hydra.main(version_base=None, config_path="../configs", config_name="lora_config")
def main(cfg: DictConfig):
    """Main training function"""
    
    logger.info(f"Starting LoRA training with config:\n{OmegaConf.to_yaml(cfg)}")
    
    # Setup device
    device = "cuda" if torch.cuda.is_available() else "cpu"
    logger.info(f"Using device: {device}")
    
    # Load tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(cfg.model.name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    model = AutoModelForCausalLM.from_pretrained(
        cfg.model.name,
        torch_dtype=torch.float16 if cfg.training.fp16 else torch.float32,
        device_map="auto" if device == "cuda" else None,
    )
    
    # Setup LoRA
    lora_config = LoraConfig(
        r=cfg.model.lora.rank,
        lora_alpha=cfg.model.lora.alpha,
        target_modules=cfg.model.lora.target_modules,
        lora_dropout=cfg.model.lora.dropout,
        bias=cfg.model.lora.bias,
        task_type=TaskType.CAUSAL_LM,
    )
    
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # Load data
    curriculum_stage = None
    if cfg.training.curriculum.enabled:
        # For now, use first stage
        curriculum_stage = cfg.training.curriculum.stages[0].data_filter
    
    train_dataset, val_dataset = load_and_preprocess_data(
        cfg.data.train_path,
        cfg.data.val_path,
        tokenizer,
        cfg.data.max_seq_length,
        curriculum_stage
    )
    
    # Training arguments
    training_args = TrainingArguments(
        output_dir=cfg.training.output_dir,
        num_train_epochs=cfg.training.num_train_epochs,
        per_device_train_batch_size=cfg.training.per_device_train_batch_size,
        per_device_eval_batch_size=cfg.training.per_device_eval_batch_size,
        gradient_accumulation_steps=cfg.training.gradient_accumulation_steps,
        learning_rate=cfg.training.learning_rate,
        lr_scheduler_type=cfg.training.lr_scheduler_type,
        warmup_steps=cfg.training.warmup_steps,
        weight_decay=cfg.training.weight_decay,
        fp16=cfg.training.fp16,
        bf16=cfg.training.bf16,
        logging_steps=cfg.training.logging_steps,
        eval_steps=cfg.training.eval_steps,
        save_steps=cfg.training.save_steps,
        save_total_limit=cfg.training.save_total_limit,
        load_best_model_at_end=cfg.training.load_best_model_at_end,
        metric_for_best_model=cfg.training.metric_for_best_model,
        greater_is_better=cfg.training.greater_is_better,
        evaluation_strategy=cfg.checkpointing.evaluation_strategy,
        save_strategy=cfg.checkpointing.save_strategy,
        report_to="none",  # Disable default logging, use custom
    )
    
    # Data collator
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
    )
    
    # Create trainer
    trainer = ExplainableTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        data_collator=data_collator,
        compute_metrics=compute_combined_metric,
        explainability_config=cfg.explainability,
    )
    
    # Train
    logger.info("Starting training...")
    trainer.train(resume_from_checkpoint=cfg.checkpointing.resume_from_checkpoint)
    
    # Save final model
    logger.info(f"Saving model to {cfg.training.output_dir}")
    trainer.save_model()
    tokenizer.save_pretrained(cfg.training.output_dir)
    
    # Save provenance logs if enabled
    if cfg.explainability.log_provenance:
        provenance_path = Path(cfg.training.output_dir) / "provenance_logs.json"
        with open(provenance_path, "w") as f:
            json.dump(trainer.provenance_logs, f, indent=2)
        logger.info(f"Saved provenance logs to {provenance_path}")
    
    logger.info("Training complete!")


if __name__ == "__main__":
    main()

