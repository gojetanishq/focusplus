# Contributing to Apox Engine

Thank you for your interest in contributing to Apox Engine!

## Development Setup

1. Fork the repository
2. Clone your fork
3. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Install development dependencies:
   ```bash
   pip install -r requirements-dev.txt
   ```

## Code Style

- Follow PEP 8 for Python code
- Use type hints where possible
- Write docstrings for all functions and classes
- Run linters before committing:
  ```bash
  black .
  flake8 .
  mypy .
  ```

## Testing

- Write tests for all new features
- Run tests before committing:
  ```bash
  pytest tests/
  ```
- Aim for >80% code coverage

## Pull Request Process

1. Create a feature branch from `main`
2. Make your changes
3. Add tests
4. Update documentation
5. Run tests and linters
6. Submit a pull request with a clear description

## Commit Messages

Use clear, descriptive commit messages:
- `feat: Add difficulty classification endpoint`
- `fix: Resolve PII redaction issue`
- `docs: Update API documentation`

## Questions?

Open an issue or contact the maintainers.

