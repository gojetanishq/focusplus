#!/bin/bash
# Apox Engine Setup Script

set -e

echo "🚀 Setting up Apox Engine..."

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p data/{raw,labeled,models,vector_db,feedback}
mkdir -p logs

# Check Python version
echo "🐍 Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

# Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt

# Generate synthetic data
echo "📊 Generating synthetic training data..."
python ingest/sources/synthetic_generator.py

# Process and label data
echo "🏷️  Processing and labeling data..."
python ingest/processors/labeling_pipeline.py \
  --input data/raw \
  --output data/labeled

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Train a model: python train/scripts/train_lora.py --config train/configs/lora_config.yaml"
echo "2. Start API server: cd serve && python api/server.py"
echo "3. Or use Docker: docker-compose up -d"
echo ""
echo "See QUICKSTART.md for more details."

