# Apox Engine API Documentation

OpenAPI 3.0 Specification for Apox Engine endpoints.

## Base URL

```
http://localhost:8000
```

## Endpoints

### POST /ai/difficulty

Classify topic difficulty with explainability.

**Request Body:**
```json
{
  "topicText": "Multivariable calculus integration",
  "userId": "user_123",
  "uploadedFiles": []
}
```

**Response:**
```json
{
  "difficulty": "hard",
  "difficulty_score": 85,
  "reasoning_summary": [
    "Requires multi-step symbolic logical reasoning",
    "High context depth; relies on prerequisite knowledge"
  ],
  "sources": [
    {
      "title": "MIT OpenCourseWare: Multivariable Calculus",
      "url": "https://ocw.mit.edu",
      "type": "ocw",
      "quote": "Integration in high dimensions..."
    }
  ],
  "confidence": 0.92,
  "verification_checks": [
    "Symbolic verification using SymPy",
    "Cross-reference with textbook"
  ],
  "provenance": {
    "source_ids": ["ocw_18.02_ch3"],
    "snippet_ids": ["snippet_123"],
    "training_example_ids": ["example_456"],
    "reasoning_signals": ["multi_step", "high_depth"],
    "reasoning_summary": []
  }
}
```

### POST /ai/chat

Chat with explainable responses.

**Request Body:**
```json
{
  "prompt": "Explain multivariable integration",
  "contextChunks": []
}
```

**Response:**
```json
{
  "answer": "Multivariable integration extends...",
  "provenance": {
    "source_ids": ["ocw_18.02"],
    "snippet_ids": ["snippet_123"],
    "training_example_ids": ["example_456"],
    "reasoning_signals": ["multi_step"]
  },
  "sources": [
    {
      "title": "MIT OCW",
      "url": "https://ocw.mit.edu",
      "type": "ocw",
      "quote": "..."
    }
  ],
  "confidence": 0.88
}
```

### POST /ai/verify

Run verification jobs asynchronously.

**Request Body:**
```json
{
  "jobSpec": {
    "type": "symbolic_check",
    "content": "∫∫ x^2 + y^2 dx dy"
  }
}
```

**Response:**
```json
{
  "job_id": "job_123",
  "status": "pending"
}
```

### POST /api/feedback

Submit student feedback.

**Request Body:**
```json
{
  "response_id": "resp_123",
  "rating": 3,
  "disagreement": "Difficulty was too high",
  "user_id": "user_456"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Feedback recorded"
}
```

### GET /health

Health check endpoint.

**Response:**
```json
{
  "status": "healthy",
  "model_loaded": true,
  "redis_available": true
}
```

