# Apox Engine Deployment Guide

## Quick Start

### Local Development

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate synthetic data
python ingest/sources/synthetic_generator.py

# 3. Process and label data
python ingest/processors/labeling_pipeline.py --input data/raw --output data/labeled

# 4. Start API server
cd serve && python api/server.py
```

### Docker Deployment

```bash
# Build image
docker build -t apox-engine:latest .

# Run with docker-compose
docker-compose up -d

# Check logs
docker-compose logs -f api
```

## Production Deployment

### Prerequisites

- Python 3.9+
- Docker & Docker Compose
- GPU (optional, for training)
- PostgreSQL (for production database)
- Redis (for caching)

### Environment Variables

Create `.env` file:

```env
MODEL_PATH=/app/data/models
REDIS_HOST=redis
POSTGRES_HOST=postgres
POSTGRES_DB=apox_engine
POSTGRES_USER=apox
POSTGRES_PASSWORD=your_password
APOX_API_URL=http://localhost:8000
```

### Kubernetes Deployment

See `k8s/` directory for Helm charts and Kubernetes manifests.

### Cloud Deployment

#### AWS

1. Deploy to ECS/EKS
2. Use S3 for model storage
3. Use ElastiCache for Redis
4. Use RDS for PostgreSQL

#### GCP

1. Deploy to Cloud Run or GKE
2. Use Cloud Storage for models
3. Use Memorystore for Redis
4. Use Cloud SQL for PostgreSQL

## Monitoring

### Health Checks

```bash
curl http://localhost:8000/health
```

### Metrics

Prometheus metrics available at `/metrics` endpoint.

### Logging

Logs are written to `logs/` directory. In production, use centralized logging (e.g., CloudWatch, Stackdriver).

## Scaling

- **Horizontal Scaling**: Run multiple API instances behind a load balancer
- **Model Caching**: Use Redis to cache model responses
- **Async Processing**: Use job queue (Celery, RQ) for verification jobs

## Security

- Enable HTTPS in production
- Use environment variables for secrets
- Implement rate limiting
- Enable CORS only for trusted domains
- Regular security audits

