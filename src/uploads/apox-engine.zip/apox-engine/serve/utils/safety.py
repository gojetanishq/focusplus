"""
Safety and Privacy Utilities for Apox Engine
Handles PII redaction, content filtering, and privacy compliance.
"""

import logging
from typing import List, Dict, Any, Optional
import re

try:
    from presidio_analyzer import AnalyzerEngine
    from presidio_anonymizer import AnonymizerEngine
    PRESIDIO_AVAILABLE = True
except ImportError:
    PRESIDIO_AVAILABLE = False
    logging.warning("Presidio not available, using basic PII detection")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SafetyEngine:
    """Engine for safety and privacy features"""
    
    def __init__(self):
        self.analyzer = None
        self.anonymizer = None
        
        if PRESIDIO_AVAILABLE:
            try:
                self.analyzer = AnalyzerEngine()
                self.anonymizer = AnonymizerEngine()
            except Exception as e:
                logger.warning(f"Failed to initialize Presidio: {e}")
        
        # Disallowed content patterns
        self.disallowed_patterns = [
            r'\b(violence|harm|illegal)\b',
            r'\b(drug|substance abuse)\b',
            # Add more patterns as needed
        ]
    
    def redact_pii(self, text: str) -> tuple[str, Dict[str, Any]]:
        """
        Redact PII from text.
        
        Returns:
            (redacted_text, pii_metadata)
        """
        if not self.analyzer or not self.anonymizer:
            # Basic PII detection using regex
            return self._basic_pii_redaction(text)
        
        try:
            # Analyze for PII
            results = self.analyzer.analyze(text=text, language='en')
            
            if not results:
                return text, {}
            
            # Anonymize
            anonymized_result = self.anonymizer.anonymize(
                text=text,
                analyzer_results=results
            )
            
            # Extract metadata
            pii_metadata = {
                "entities_found": [r.entity_type for r in results],
                "redaction_count": len(results)
            }
            
            return anonymized_result.text, pii_metadata
        
        except Exception as e:
            logger.error(f"Error in PII redaction: {e}")
            return text, {}
    
    def _basic_pii_redaction(self, text: str) -> tuple[str, Dict[str, Any]]:
        """Basic PII redaction using regex"""
        redacted = text
        pii_found = []
        
        # Email
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        if emails:
            pii_found.append("EMAIL")
            redacted = re.sub(email_pattern, '[EMAIL_REDACTED]', redacted)
        
        # Phone numbers
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        phones = re.findall(phone_pattern, text)
        if phones:
            pii_found.append("PHONE")
            redacted = re.sub(phone_pattern, '[PHONE_REDACTED]', redacted)
        
        # SSN
        ssn_pattern = r'\b\d{3}-\d{2}-\d{4}\b'
        ssns = re.findall(ssn_pattern, text)
        if ssns:
            pii_found.append("SSN")
            redacted = re.sub(ssn_pattern, '[SSN_REDACTED]', redacted)
        
        return redacted, {
            "entities_found": pii_found,
            "redaction_count": len(pii_found)
        }
    
    def check_content_filter(self, text: str) -> Dict[str, Any]:
        """
        Check if content violates safety policies.
        
        Returns:
            {
                "allowed": bool,
                "violations": List[str],
                "moderation_decision": str
            }
        """
        violations = []
        
        # Check disallowed patterns
        text_lower = text.lower()
        for pattern in self.disallowed_patterns:
            if re.search(pattern, text_lower):
                violations.append(f"Matched pattern: {pattern}")
        
        # In production, integrate with moderation API (e.g., OpenAI Moderation)
        
        allowed = len(violations) == 0
        decision = "approved" if allowed else "rejected"
        
        return {
            "allowed": allowed,
            "violations": violations,
            "moderation_decision": decision
        }
    
    def mark_private_resource(self, resource_id: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Mark a resource as private in provenance"""
        return {
            **metadata,
            "private_resource": True,
            "privacy_flags": ["student_uploaded", "requires_consent"]
        }
    
    def generate_consent_policy(self) -> str:
        """Generate data retention and consent policy"""
        return """
# Data Retention and Consent Policy

## Data Collection
- Training data may include anonymized student interactions
- Personal information is redacted before training
- User consent is required for data collection

## Data Retention
- Training data: Retained for model improvement
- User feedback: Retained for 2 years
- Private resources: Deleted upon user request

## User Rights
- Right to access your data
- Right to deletion
- Right to opt-out of data collection

## Contact
For privacy concerns, contact: privacy@apox-engine.com
"""


class PrivacyCompliance:
    """Privacy compliance utilities"""
    
    @staticmethod
    def generate_privacy_docs() -> Dict[str, str]:
        """Generate privacy documentation"""
        return {
            "privacy_policy": """
# Privacy Policy

## Information We Collect
- Study session data
- Task completion data
- AI interaction logs (anonymized)

## How We Use Information
- Improve AI model performance
- Personalize learning experience
- Research and development

## Data Security
- Encrypted storage
- Access controls
- Regular security audits
            """,
            "data_retention_policy": """
# Data Retention Policy

- User data: 2 years
- Training data: Indefinite (anonymized)
- Feedback data: 2 years
- Logs: 90 days
            """,
            "consent_form": """
# Consent Form

I consent to:
- [ ] Data collection for model improvement
- [ ] Anonymized data sharing for research
- [ ] Feedback collection

Signature: _______________
Date: _______________
            """
        }

