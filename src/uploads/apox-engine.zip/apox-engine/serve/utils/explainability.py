"""
Explainability Engine for Apox Engine
Provides provenance tracking, saliency maps, and reasoning signal extraction.
"""

import logging
from typing import Dict, List, Any, Optional
import torch
import numpy as np

try:
    from captum.attr import IntegratedGradients, Saliency
    CAPTUM_AVAILABLE = True
except ImportError:
    CAPTUM_AVAILABLE = False
    logging.warning("Captum not available, saliency maps disabled")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ExplainabilityEngine:
    """Engine for explainability and provenance tracking"""
    
    def __init__(self):
        self.provenance_db = {}  # In production, use proper database
        self.training_examples_db = {}  # Load from training data
    
    async def get_provenance(
        self,
        prompt: str,
        response: str,
        model: Any,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        Get provenance information for a response.
        
        Returns:
            - source_ids: List of source IDs that influenced the response
            - snippet_ids: List of snippet IDs
            - training_example_ids: Top-K similar training examples
            - saliency_map: Token-level importance scores
            - reasoning_signals: Extracted reasoning signals
        """
        # Extract reasoning signals
        reasoning_signals = self._extract_reasoning_signals(prompt, response)
        
        # Find similar training examples (simplified - use embeddings in production)
        similar_examples = self._find_similar_examples(prompt, top_k)
        
        # Generate saliency map if model available
        saliency_map = None
        if model and CAPTUM_AVAILABLE:
            try:
                saliency_map = await self._generate_saliency_map(prompt, model)
            except Exception as e:
                logger.warning(f"Failed to generate saliency map: {e}")
        
        return {
            "source_ids": similar_examples.get("source_ids", []),
            "snippet_ids": similar_examples.get("snippet_ids", []),
            "training_example_ids": similar_examples.get("example_ids", []),
            "saliency_map": saliency_map,
            "reasoning_signals": reasoning_signals,
            "reasoning_summary": self._format_reasoning_summary(reasoning_signals)
        }
    
    def _extract_reasoning_signals(self, prompt: str, response: str) -> List[str]:
        """Extract reasoning signals from prompt and response"""
        signals = []
        text = (prompt + " " + response).lower()
        
        # Map to 5 core signals
        if any(word in text for word in ["step", "steps", "multi", "procedure", "algorithm"]):
            signals.append("multi_step")
        
        if any(word in text for word in ["deep", "depth", "prerequisite", "foundation", "advanced"]):
            signals.append("high_depth")
        
        if any(word in text for word in ["domain", "cross", "interdisciplinary", "combine", "multiple"]):
            signals.append("cross_domain")
        
        if any(word in text for word in ["ambiguous", "unclear", "vague", "interpret", "depends"]):
            signals.append("ambiguous")
        
        if any(word in text for word in ["precise", "exact", "correct", "accurate", "critical", "proof"]):
            signals.append("correctness_critical")
        
        return signals if signals else ["conceptual"]
    
    def _find_similar_examples(self, prompt: str, top_k: int) -> Dict[str, List[str]]:
        """Find similar training examples (simplified - use embeddings in production)"""
        # In production, use vector similarity search
        # For now, return empty lists
        return {
            "source_ids": [],
            "snippet_ids": [],
            "example_ids": []
        }
    
    async def _generate_saliency_map(self, prompt: str, model: Any) -> Optional[Dict[str, float]]:
        """Generate token-level saliency map"""
        if not CAPTUM_AVAILABLE:
            return None
        
        try:
            # Tokenize
            tokenizer = model.tokenizer if hasattr(model, "tokenizer") else None
            if not tokenizer:
                return None
            
            inputs = tokenizer(prompt, return_tensors="pt")
            input_ids = inputs["input_ids"]
            
            # Use Integrated Gradients
            ig = IntegratedGradients(model)
            
            # Get attributions
            attributions = ig.attribute(
                input_ids,
                target=0,  # First token prediction
                return_convergence_delta=False
            )
            
            # Convert to token-level scores
            token_scores = attributions[0].detach().cpu().numpy()
            tokens = tokenizer.convert_ids_to_tokens(input_ids[0])
            
            saliency_map = {
                token: float(score) for token, score in zip(tokens, token_scores)
            }
            
            return saliency_map
        
        except Exception as e:
            logger.error(f"Error generating saliency map: {e}")
            return None
    
    def _format_reasoning_summary(self, signals: List[str]) -> List[str]:
        """Format reasoning signals into human-readable summary"""
        mapping = {
            "multi_step": "Requires multi-step logical reasoning",
            "high_depth": "High context depth; relies on prerequisite knowledge",
            "cross_domain": "Cross-domain connections required",
            "ambiguous": "Topic specification may be ambiguous",
            "correctness_critical": "Precision correctness is critical"
        }
        
        return [mapping.get(signal, f"Reasoning type: {signal}") for signal in signals]

