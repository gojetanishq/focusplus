"""
RAG Engine for Apox Engine
Handles retrieval-augmented generation with vector stores.
"""

import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

try:
    from sentence_transformers import SentenceTransformer
    from chromadb import Client, Settings
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    logging.warning("Sentence transformers or ChromaDB not available, RAG disabled")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RAGEngine:
    """RAG engine for retrieval-augmented generation"""
    
    def __init__(self, vector_db_path: Optional[str] = None):
        self.vector_db_path = vector_db_path or "data/vector_db"
        self.embedding_model = None
        self.vector_db = None
        
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
                # Initialize ChromaDB
                self.vector_db = Client(Settings(
                    chroma_db_impl="duckdb+parquet",
                    persist_directory=self.vector_db_path
                ))
                logger.info("RAG engine initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize RAG engine: {e}")
    
    async def retrieve(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve relevant chunks for a query"""
        if not self.vector_db or not self.embedding_model:
            # Fallback: return empty results
            logger.warning("RAG not available, returning empty results")
            return []
        
        try:
            # Get collection
            collection = self.vector_db.get_or_create_collection("documents")
            
            # Generate query embedding
            query_embedding = self.embedding_model.encode(query).tolist()
            
            # Query vector DB
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k
            )
            
            # Format results
            retrieved_chunks = []
            if results["ids"] and len(results["ids"][0]) > 0:
                for i, doc_id in enumerate(results["ids"][0]):
                    metadata = results["metadatas"][0][i] if results["metadatas"] else {}
                    retrieved_chunks.append({
                        "id": doc_id,
                        "text": results["documents"][0][i] if results["documents"] else "",
                        "title": metadata.get("title", "Unknown"),
                        "url": metadata.get("url", ""),
                        "type": metadata.get("type", "document"),
                        "score": 1.0 - (i * 0.1)  # Simplified score
                    })
            
            return retrieved_chunks
        
        except Exception as e:
            logger.error(f"Error in RAG retrieval: {e}")
            return []
    
    async def retrieve_file_chunks(self, file_id: str) -> List[str]:
        """Retrieve chunks for a specific file"""
        if not self.vector_db:
            return []
        
        try:
            collection = self.vector_db.get_or_create_collection("documents")
            
            # Query by file_id metadata
            results = collection.get(
                where={"file_id": file_id}
            )
            
            return [doc for doc in results.get("documents", [])]
        
        except Exception as e:
            logger.error(f"Error retrieving file chunks: {e}")
            return []
    
    async def ingest_document(self, text: str, metadata: Dict[str, Any]):
        """Ingest a document into the vector store"""
        if not self.vector_db or not self.embedding_model:
            logger.warning("RAG not available, skipping ingestion")
            return
        
        try:
            collection = self.vector_db.get_or_create_collection("documents")
            
            # Generate embedding
            embedding = self.embedding_model.encode(text).tolist()
            
            # Add to collection
            doc_id = metadata.get("id", f"doc_{len(collection.get()['ids'])}")
            collection.add(
                ids=[doc_id],
                embeddings=[embedding],
                documents=[text],
                metadatas=[metadata]
            )
            
            logger.info(f"Ingested document: {doc_id}")
        
        except Exception as e:
            logger.error(f"Error ingesting document: {e}")

