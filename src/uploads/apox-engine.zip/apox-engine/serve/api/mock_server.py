#!/usr/bin/env python3
"""
Mock API Server for Apox Engine
Lightweight server for preview/testing without ML dependencies
"""

import json
import os
from datetime import datetime
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uvicorn

app = FastAPI(title="Apox Engine Mock API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request models
class DifficultyRequest(BaseModel):
    topicText: str
    userId: Optional[str] = None
    uploadedFiles: Optional[List[str]] = []

class ChatRequest(BaseModel):
    prompt: str
    contextChunks: Optional[List[str]] = []

class FeedbackRequest(BaseModel):
    response_id: str
    rating: int
    disagreement: Optional[str] = None
    user_id: str

# Review models
class Review(BaseModel):
    topic: str
    user_id: str
    difficulty: str
    review_text: str
    rating: Optional[int] = None
    created_at: Optional[str] = None

class ReviewResponse(BaseModel):
    topic: str
    user_id: str
    difficulty: str
    review_text: str
    rating: Optional[int] = None
    created_at: str

# Simple file-based storage for reviews (mock persistence)
REVIEWS_FILE = os.path.join(os.path.dirname(__file__), "reviews.jsonl")

def _load_reviews() -> List[Dict[str, Any]]:
    reviews: List[Dict[str, Any]] = []
    if os.path.exists(REVIEWS_FILE):
        with open(REVIEWS_FILE, "r") as f:
            for line in f:
                try:
                    reviews.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return reviews

def _save_reviews(reviews: List[Dict[str, Any]]):
    with open(REVIEWS_FILE, "w") as f:
        for r in reviews:
            f.write(json.dumps(r) + "\n")

@app.get("/")
async def root():
    return {"status": "healthy", "service": "Apox Engine Mock API", "version": "1.0.0"}

@app.get("/health")
async def health():
    return {"status": "healthy", "model_loaded": True, "redis_available": False}

@app.post("/ai/difficulty")
async def classify_difficulty(request: DifficultyRequest):
    """Mock difficulty classification"""
    topic_lower = request.topicText.lower()
    is_math = any(word in topic_lower for word in ["calculus", "algebra", "integration", "derivative", "math"])
    is_hard = any(word in topic_lower for word in ["multi", "advanced", "physics", "quantum"])
    
    difficulty = "very_hard" if is_hard else ("hard" if is_math else "medium")
    score = 85 if is_hard else (65 if is_math else 45)
    
    return {
        "difficulty": difficulty,
        "difficulty_score": score,
        "reasoning_summary": [
            "Requires multi-step symbolic logical reasoning" if is_math else "Primary reasoning type is conceptual understanding",
            "Context depth is high; relies on prerequisite knowledge",
            "Cross-domain connections required",
            "Topic specification is clear but scope is broad",
            "Precision correctness is critical for valid results"
        ],
        "sources": [
            {
                "title": "MIT OpenCourseWare: Multivariable Calculus",
                "url": "https://ocw.mit.edu",
                "type": "ocw",
                "quote": "Integration in high dimensions requires visualizing vector fields."
            }
        ],
        "confidence": 0.85 + (0.1 if is_math else 0),
        "verification_checks": [
            "Symbolic verification using SymPy",
            "Cross-reference with standard textbook"
        ],
        "provenance": {
            "source_ids": ["ocw_18.02_ch3"],
            "snippet_ids": ["snippet_123"],
            "training_example_ids": ["example_456"],
            "reasoning_signals": ["multi_step", "high_depth"] if is_math else ["conceptual"],
            "reasoning_summary": []
        }
    }

@app.post("/ai/chat")
async def chat(request: ChatRequest):
    """Premium-quality chat endpoint with intelligent reasoning"""
    import re
    prompt_lower = request.prompt.lower()
    prompt = request.prompt
    
    # Extract context from chunks
    context_info = ""
    if request.contextChunks:
        context_info = " ".join(request.contextChunks)
    
    # Premium LLM-style response generation
    answer = ""
    reasoning_signals = []
    sources = []
    confidence = 0.85
    
    # Detect intent and generate sophisticated responses
    if any(word in prompt_lower for word in ["difficulty", "hard", "easy", "challenging", "complex"]):
        # Difficulty assessment request
        topic_match = re.search(r'(?:difficulty|hard|easy|challenging|complex).*?(?:of|for|with)?\s+([^?\.]+)', prompt_lower)
        topic = topic_match.group(1).strip() if topic_match else prompt
        
        # Analyze topic
        is_math = any(word in topic for word in ["calculus", "algebra", "integration", "derivative", "math", "theorem"])
        is_science = any(word in topic for word in ["physics", "chemistry", "biology", "quantum"])
        is_programming = any(word in topic for word in ["code", "programming", "algorithm", "software", "python", "javascript"])
        
        if is_math or is_science:
            difficulty = "very_hard" if "multi" in topic or "advanced" in topic else "hard"
            reasoning_signals = ["multi_step", "high_depth", "correctness_critical"]
            answer = f"""Based on my analysis of "{topic}", this topic falls into the **{difficulty.replace('_', ' ').title()}** difficulty category.

**Key Complexity Factors:**
• **Multi-step reasoning required**: This topic involves chaining together multiple concepts and operations
• **High prerequisite knowledge**: You'll need a solid foundation in fundamental concepts
• **Precision critical**: Small errors can cascade, so careful attention to detail is essential

**Learning Strategy:**
1. **Start with fundamentals**: Review prerequisite concepts before diving in
2. **Practice incrementally**: Begin with simple examples, gradually increase complexity
3. **Visualize concepts**: Use diagrams, graphs, or interactive tools to understand relationships
4. **Active problem-solving**: Don't just read—work through problems step-by-step
5. **Spaced repetition**: Review regularly to reinforce understanding

**Estimated Study Time**: For mastery, plan for 20-30 hours of focused study, spread over 2-3 weeks.

Would you like me to create a personalized study plan for this topic?"""
            sources = [
                {
                    "title": "MIT OpenCourseWare: Advanced Mathematics",
                    "url": "https://ocw.mit.edu",
                    "type": "ocw",
                    "quote": "Complex mathematical topics require systematic approach and practice."
                }
            ]
            confidence = 0.88
            
        elif is_programming:
            reasoning_signals = ["multi_step", "high_depth"]
            answer = f"""The topic "{topic}" in programming typically requires **medium to hard** difficulty depending on your experience level.

**Complexity Breakdown:**
• **Conceptual understanding**: Moderate - requires understanding of core programming principles
• **Implementation complexity**: Can range from simple to very complex
• **Best practices**: Important to follow coding standards and design patterns

**Learning Path:**
1. **Understand the fundamentals** first
2. **Practice with small projects**
3. **Read quality code examples**
4. **Build progressively complex applications**
5. **Get code reviews** from experienced developers

**Recommended Resources:**
• Official documentation
• Interactive coding platforms (LeetCode, HackerRank)
• Open-source projects on GitHub
• Community forums and discussions

I can help you break this down into manageable learning milestones. What specific aspect would you like to focus on?"""
            confidence = 0.82
            
        else:
            reasoning_signals = ["conceptual"]
            answer = f"""I'd be happy to help assess the difficulty of "{topic}"!

To provide the most accurate assessment, I'd need to understand:
• Your current background and experience level
• The specific aspects you're concerned about
• Your learning goals (basic understanding vs. mastery)

**General Approach:**
Most topics can be mastered with:
- **Structured learning plan**
- **Consistent practice**
- **Active engagement** (not just passive reading)
- **Regular review** and self-testing

Would you like me to:
1. Analyze the specific difficulty of this topic in detail?
2. Create a personalized study plan?
3. Recommend learning resources and strategies?"""
            confidence = 0.75
    
    elif any(word in prompt_lower for word in ["task", "todo", "schedule", "plan"]):
        reasoning_signals = ["conceptual", "cross_domain"]
        answer = f"""I can help you with task management and study planning!

**Based on your context:**
{context_info if context_info else "I see you're working on organizing your study schedule."}

**Here's what I recommend:**

1. **Prioritize by urgency and importance**
   - High priority + urgent = Do first
   - High priority + not urgent = Schedule dedicated time
   - Low priority = Can wait or delegate

2. **Time blocking technique**
   - Allocate specific time slots for each task
   - Include buffer time for unexpected issues
   - Schedule breaks between intensive sessions

3. **Break large tasks into smaller steps**
   - Makes progress more visible
   - Reduces overwhelm
   - Increases motivation

4. **Use the Pomodoro Technique**
   - 25 minutes focused work
   - 5 minute break
   - Repeat 4 times, then take a longer break

Would you like me to:
• Help prioritize your current tasks?
• Create a weekly study schedule?
• Suggest optimal times for different types of work?"""
        confidence = 0.80
        
    elif any(word in prompt_lower for word in ["help", "how", "what can", "guide"]):
        reasoning_signals = ["conceptual"]
        answer = """I'm your Focus Assistant, powered by explainable AI! Here's what I can help you with:

**🎯 Core Capabilities:**

1. **Difficulty Assessment**
   - Analyze topic complexity
   - Provide reasoning breakdown
   - Suggest learning strategies
   - Estimate study time

2. **Study Planning**
   - Create personalized schedules
   - Optimize time allocation
   - Suggest study techniques
   - Track progress

3. **Task Management**
   - Prioritize tasks
   - Break down complex goals
   - Suggest productivity techniques
   - Help with time management

4. **Learning Support**
   - Explain concepts clearly
   - Provide study resources
   - Suggest practice exercises
   - Answer questions with sources

5. **Productivity Tips**
   - Focus techniques
   - Break strategies
   - Motivation support
   - Habit building

**💡 Example Questions:**
• "What's the difficulty of multivariable calculus?"
• "Help me plan my study schedule"
• "How should I approach learning Python?"
• "What are the best study techniques for exams?"

Just ask me anything, and I'll provide explainable, evidence-based responses!"""
        confidence = 0.90
        
    elif any(word in prompt_lower for word in ["explain", "what is", "tell me about", "describe"]):
        reasoning_signals = ["conceptual", "high_depth"]
        # Extract the topic to explain
        topic_match = re.search(r'(?:explain|what is|tell me about|describe)\s+([^?\.]+)', prompt_lower)
        topic = topic_match.group(1).strip() if topic_match else prompt
        
        answer = f"""I'll explain "{topic}" in a clear, structured way:

**Overview:**
{topic} is a fundamental concept that plays an important role in understanding broader principles.

**Key Points:**
1. **Core Definition**: The essential meaning and purpose
2. **Key Components**: The main elements that make it up
3. **How It Works**: The mechanism or process involved
4. **Why It Matters**: Its significance and applications
5. **Common Examples**: Real-world applications or illustrations

**Learning Approach:**
• Start with the basic definition
• Understand each component separately
• See how they work together
• Practice with examples
• Apply to new situations

**Common Challenges:**
• [Students often struggle with...]
• [A common misconception is...]
• [The trickiest part is usually...]

**Next Steps:**
Would you like me to:
1. Go deeper into any specific aspect?
2. Provide worked examples?
3. Suggest practice problems?
4. Connect this to related concepts?

I can also assess the difficulty level of mastering this topic if that would be helpful!"""
        sources = [
            {
                "title": "Educational Resource Library",
                "url": "https://example.com",
                "type": "document",
                "quote": "Structured explanations improve comprehension and retention."
            }
        ]
        confidence = 0.82
        
    elif any(word in prompt_lower for word in ["progress", "stats", "level", "achievement"]):
        reasoning_signals = ["conceptual"]
        answer = f"""Great question about your progress!

**Your Current Status:**
{context_info if context_info else "Based on your activity, here's what I can see:"}

**Progress Insights:**
• **Consistency is key**: Regular study sessions build momentum
• **Quality over quantity**: Focused 2-hour sessions beat distracted 4-hour marathons
• **Track your wins**: Celebrate small achievements to maintain motivation

**Improvement Strategies:**
1. **Set specific, measurable goals**
2. **Break large goals into milestones**
3. **Review progress weekly**
4. **Adjust strategies based on what works**
5. **Maintain a growth mindset**

**Motivation Boost:**
Remember: Every expert was once a beginner. Progress might feel slow, but consistency compounds over time!

Would you like me to:
• Analyze your specific progress metrics?
• Suggest areas for improvement?
• Create a personalized improvement plan?"""
        confidence = 0.78
        
    else:
        # General intelligent response
        reasoning_signals = ["conceptual"]
        answer = f"""I understand you're asking about: "{prompt}"

Let me provide a thoughtful response:

**My Analysis:**
This is an interesting question that touches on several important aspects. Let me break this down:

1. **Understanding the Core**: The fundamental concept here is...
2. **Key Considerations**: Important factors to consider include...
3. **Practical Applications**: This relates to real-world scenarios where...
4. **Best Practices**: Based on research and experience, the recommended approach is...

**Additional Context:**
{context_info if context_info else "I can provide more specific guidance if you share more details about your situation."}

**How I Can Help Further:**
• Provide more detailed explanation
• Assess difficulty or complexity
• Suggest learning resources
• Create a study plan
• Answer follow-up questions

What specific aspect would you like me to explore further?"""
        confidence = 0.75
    
    return {
        "answer": answer,
        "provenance": {
            "source_ids": ["mock_source_1"],
            "snippet_ids": ["mock_snippet_1"],
            "training_example_ids": ["mock_example_1"],
            "reasoning_signals": reasoning_signals
        },
        "sources": sources if sources else [
            {
                "title": "Educational Resource Library",
                "url": "https://example.com",
                "type": "document",
                "quote": "Evidence-based learning strategies improve outcomes."
            }
        ],
        "confidence": confidence
    }

@app.post("/api/feedback")
async def submit_feedback(request: FeedbackRequest):
    """Mock feedback endpoint"""
    return {
        "status": "success",
        "message": "Feedback recorded"
    }

@app.get("/api/feedback/stats")
async def get_feedback_stats():
    """Mock feedback stats"""
    return {
        "total": 0,
        "average_rating": 0,
        "disagreements": 0
    }

# Reviews: allow users to submit and view topic difficulty reviews
@app.post("/api/reviews", response_model=ReviewResponse)
async def submit_review(review: Review):
    reviews = _load_reviews()
    new_review = {
        "topic": review.topic.strip(),
        "user_id": review.user_id,
        "difficulty": review.difficulty,
        "review_text": review.review_text,
        "rating": review.rating,
        "created_at": review.created_at or datetime.utcnow().isoformat() + "Z"
    }
    reviews.append(new_review)
    _save_reviews(reviews)
    return new_review

@app.get("/api/reviews", response_model=List[ReviewResponse])
async def list_reviews(topic: Optional[str] = None):
    reviews = _load_reviews()
    if topic:
        topic_lower = topic.lower()
        reviews = [r for r in reviews if r.get("topic", "").lower() == topic_lower]
    return reviews

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    print(f"🚀 Starting Apox Engine Mock API on http://localhost:{port}")
    print(f"📚 API Documentation: http://localhost:{port}/docs")
    uvicorn.run(app, host="0.0.0.0", port=port)

