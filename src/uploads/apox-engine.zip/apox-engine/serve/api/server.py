#!/usr/bin/env python3
"""
Apox Engine API Server
FastAPI server for difficulty classification, chat, and verification endpoints.
"""

import os
import json
import logging
import uuid
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn
from redis import Redis
import torch

# Import model utilities
import sys
sys.path.append(str(Path(__file__).parent.parent))
from models.model_loader import ModelLoader
from utils.explainability import ExplainabilityEngine
from utils.rag import RAGEngine
from utils.verification import VerificationEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Apox Engine API",
    description="Production-grade LLM training & fine-tuning pipeline API",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
model_loader = ModelLoader()
explainability_engine = ExplainabilityEngine()
rag_engine = RAGEngine()
verification_engine = VerificationEngine()

# Redis for caching (optional)
redis_client = None
try:
    redis_client = Redis(host=os.getenv("REDIS_HOST", "localhost"), port=6379, db=0)
    redis_client.ping()
except:
    logger.warning("Redis not available, caching disabled")


# Request/Response Models
class DifficultyRequest(BaseModel):
    topicText: str = Field(..., description="Topic text to classify")
    userId: Optional[str] = Field(None, description="User ID for personalization")
    uploadedFiles: Optional[List[str]] = Field(default=[], description="Uploaded file IDs")


class DifficultyResponse(BaseModel):
    difficulty: str
    difficulty_score: int
    reasoning_summary: List[str]
    sources: List[Dict[str, Any]]
    confidence: float
    verification_checks: List[str]
    provenance: Dict[str, Any]


class ChatRequest(BaseModel):
    prompt: str
    contextChunks: Optional[List[str]] = Field(default=[], description="Context chunks for RAG")


class ChatResponse(BaseModel):
    answer: str
    provenance: Dict[str, Any]
    sources: List[Dict[str, Any]]
    confidence: float


class VerifyRequest(BaseModel):
    jobSpec: Dict[str, Any]


class VerifyResponse(BaseModel):
    job_id: str
    status: str


class FeedbackRequest(BaseModel):
    response_id: str
    rating: int = Field(..., ge=1, le=5)
    disagreement: Optional[str] = None
    user_id: str


# Endpoints
@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Apox Engine API",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/health")
async def health():
    """Detailed health check"""
    return {
        "status": "healthy",
        "model_loaded": model_loader.is_loaded(),
        "redis_available": redis_client is not None and redis_client.ping() if redis_client else False
    }


@app.post("/ai/difficulty", response_model=DifficultyResponse)
async def classify_difficulty(request: DifficultyRequest):
    """
    Classify topic difficulty with explainability.
    
    Returns structured JSON with difficulty, reasoning, sources, and verification checks.
    """
    try:
        # Check cache
        cache_key = f"difficulty:{hash(request.topicText)}"
        if redis_client:
            cached = redis_client.get(cache_key)
            if cached:
                return JSONResponse(json.loads(cached))
        
        # Load model if not loaded
        if not model_loader.is_loaded():
            model_loader.load_model()
        
        # Retrieve relevant context via RAG
        context_chunks = []
        if request.uploadedFiles:
            for file_id in request.uploadedFiles:
                chunks = await rag_engine.retrieve_file_chunks(file_id)
                context_chunks.extend(chunks)
        
        # Also retrieve from vector store
        rag_results = await rag_engine.retrieve(request.topicText, top_k=5)
        context_chunks.extend([r["text"] for r in rag_results])
        
        # Generate prompt
        prompt = f"Classify the difficulty of the following topic:\n\n{request.topicText}"
        if context_chunks:
            prompt += "\n\nRelevant context:\n" + "\n".join(context_chunks[:3])
        
        prompt += "\n\nRespond with a JSON object containing: difficulty (easy/medium/hard/very_hard), difficulty_score (0-100), reasoning_summary (list of strings), sources (list), confidence (0-1), verification_checks (list)."
        
        # Generate response
        response_text = model_loader.generate(prompt, max_length=512)
        
        # Parse JSON response
        try:
            # Extract JSON from response
            if "```json" in response_text:
                json_start = response_text.find("```json") + 7
                json_end = response_text.find("```", json_start)
                response_text = response_text[json_start:json_end].strip()
            elif "{" in response_text:
                json_start = response_text.find("{")
                json_end = response_text.rfind("}") + 1
                response_text = response_text[json_start:json_end]
            
            response_data = json.loads(response_text)
        except json.JSONDecodeError:
            # Fallback: create structured response
            logger.warning("Failed to parse JSON, using fallback")
            response_data = {
                "difficulty": "medium",
                "difficulty_score": 50,
                "reasoning_summary": ["Unable to parse structured response"],
                "sources": [],
                "confidence": 0.5,
                "verification_checks": []
            }
        
        # Add sources from RAG
        if rag_results:
            response_data["sources"] = [
                {
                    "title": r.get("title", "Unknown"),
                    "url": r.get("url", ""),
                    "type": r.get("type", "document"),
                    "quote": r.get("text", "")[:200]
                }
                for r in rag_results[:3]
            ]
        
        # Generate explainability metadata
        provenance = await explainability_engine.get_provenance(
            prompt=prompt,
            response=response_text,
            model=model_loader.model
        )
        
        response_data["provenance"] = provenance
        
        # Run verification checks
        if "verification_checks" not in response_data:
            response_data["verification_checks"] = []
        
        verification_results = await verification_engine.verify(
            topic=request.topicText,
            response=response_data
        )
        response_data["verification_checks"].extend(verification_results)
        
        # Cache result
        if redis_client:
            redis_client.setex(cache_key, 3600, json.dumps(response_data))
        
        return DifficultyResponse(**response_data)
    
    except Exception as e:
        logger.error(f"Error in difficulty classification: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ai/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Chat endpoint with explainable responses.
    
    Returns answer with provenance and sources.
    """
    try:
        # Retrieve context via RAG
        rag_results = await rag_engine.retrieve(request.prompt, top_k=5)
        context_chunks = request.contextChunks or []
        context_chunks.extend([r["text"] for r in rag_results])
        
        # Build prompt
        prompt = request.prompt
        if context_chunks:
            prompt += "\n\nRelevant context:\n" + "\n".join(context_chunks[:3])
        
        # Load model if needed
        if not model_loader.is_loaded():
            model_loader.load_model()
        
        # Generate response
        answer = model_loader.generate(prompt, max_length=512)
        
        # Get provenance
        provenance = await explainability_engine.get_provenance(
            prompt=prompt,
            response=answer,
            model=model_loader.model
        )
        
        # Format sources
        sources = [
            {
                "title": r.get("title", "Unknown"),
                "url": r.get("url", ""),
                "type": r.get("type", "document"),
                "quote": r.get("text", "")[:200]
            }
            for r in rag_results[:3]
        ]
        
        # Calculate confidence (simplified)
        confidence = min(0.9, 0.5 + len(sources) * 0.1)
        
        return ChatResponse(
            answer=answer,
            provenance=provenance,
            sources=sources,
            confidence=confidence
        )
    
    except Exception as e:
        logger.error(f"Error in chat: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ai/verify", response_model=VerifyResponse)
async def verify(request: VerifyRequest, background_tasks: BackgroundTasks):
    """
    Run verification jobs asynchronously.
    
    Returns job ID and status.
    """
    try:
        job_id = str(uuid.uuid4())
        job_spec = request.jobSpec
        
        # Queue verification job
        background_tasks.add_task(
            verification_engine.run_verification_job,
            job_id=job_id,
            job_spec=job_spec
        )
        
        return VerifyResponse(job_id=job_id, status="pending")
    
    except Exception as e:
        logger.error(f"Error in verification: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/feedback")
async def submit_feedback(request: FeedbackRequest):
    """
    Submit student feedback for continual learning.
    """
    try:
        # Store feedback (in production, use database)
        feedback_data = {
            "response_id": request.response_id,
            "rating": request.rating,
            "disagreement": request.disagreement,
            "user_id": request.user_id,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Save to file (in production, use database)
        feedback_path = Path("data/feedback/feedback.jsonl")
        feedback_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(feedback_path, "a") as f:
            f.write(json.dumps(feedback_data) + "\n")
        
        return {"status": "success", "message": "Feedback recorded"}
    
    except Exception as e:
        logger.error(f"Error submitting feedback: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/feedback/stats")
async def get_feedback_stats():
    """Get feedback statistics (admin endpoint)"""
    try:
        feedback_path = Path("data/feedback/feedback.jsonl")
        if not feedback_path.exists():
            return {"total": 0, "average_rating": 0, "disagreements": 0}
        
        ratings = []
        disagreements = 0
        
        with open(feedback_path, "r") as f:
            for line in f:
                data = json.loads(line)
                ratings.append(data["rating"])
                if data.get("disagreement"):
                    disagreements += 1
        
        return {
            "total": len(ratings),
            "average_rating": sum(ratings) / len(ratings) if ratings else 0,
            "disagreements": disagreements
        }
    
    except Exception as e:
        logger.error(f"Error getting feedback stats: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)

