"""
Model Loader for Apox Engine
Handles loading and inference for fine-tuned models.
"""

import os
import logging
from pathlib import Path
from typing import Optional

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelLoader:
    """Load and manage model for inference"""
    
    def __init__(self, model_path: Optional[str] = None):
        self.model_path = model_path or os.getenv("MODEL_PATH", "models/lora_adapter")
        self.model = None
        self.tokenizer = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
    
    def load_model(self):
        """Load model and tokenizer"""
        if self.model is not None:
            logger.info("Model already loaded")
            return
        
        logger.info(f"Loading model from {self.model_path}")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Check if it's a LoRA adapter
        adapter_config_path = Path(self.model_path) / "adapter_config.json"
        
        if adapter_config_path.exists():
            # Load base model and adapter
            base_model_name = self._get_base_model_name(self.model_path)
            logger.info(f"Loading base model: {base_model_name}")
            
            base_model = AutoModelForCausalLM.from_pretrained(
                base_model_name,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None,
            )
            
            # Load LoRA adapter
            self.model = PeftModel.from_pretrained(base_model, self.model_path)
            self.model = self.model.merge_and_unload()  # Merge for faster inference
        else:
            # Load full model
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_path,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None,
            )
        
        self.model.eval()
        logger.info("Model loaded successfully")
    
    def _get_base_model_name(self, adapter_path: str) -> str:
        """Extract base model name from adapter config"""
        import json
        config_path = Path(adapter_path) / "adapter_config.json"
        
        if config_path.exists():
            with open(config_path, "r") as f:
                config = json.load(f)
                return config.get("base_model_name_or_path", "gpt2")
        
        return "gpt2"  # Default fallback
    
    def generate(self, prompt: str, max_length: int = 512, temperature: float = 0.7) -> str:
        """Generate text from prompt"""
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Model not loaded. Call load_model() first.")
        
        # Tokenize
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
        
        # Decode
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract only the generated part (remove prompt)
        if prompt in generated_text:
            generated_text = generated_text[len(prompt):].strip()
        
        return generated_text
    
    def is_loaded(self) -> bool:
        """Check if model is loaded"""
        return self.model is not None and self.tokenizer is not None

