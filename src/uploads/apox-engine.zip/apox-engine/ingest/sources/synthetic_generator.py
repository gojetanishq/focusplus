#!/usr/bin/env python3
"""
Synthetic Data Generator for Apox Engine
Generates canonical examples for bootstrapping training.
"""

import json
import random
from pathlib import Path
from typing import List, Dict
from dataclasses import dataclass


@dataclass
class SyntheticExample:
    prompt: str
    response: str
    difficulty_label: str
    reasoning_signals: List[str]
    sources: List[str]
    confidence: float
    source_id: str
    snippet_id: str


class SyntheticDataGenerator:
    """Generate synthetic training examples"""
    
    def __init__(self):
        self.examples: List[SyntheticExample] = []
    
    def generate_math_proof_examples(self, n: int = 50) -> List[SyntheticExample]:
        """Generate math proof examples"""
        examples = []
        
        math_topics = [
            ("Pythagorean theorem", "easy"),
            ("Quadratic formula derivation", "medium"),
            ("Integration by parts", "hard"),
            ("Fundamental theorem of calculus proof", "very_hard"),
            ("Chain rule for derivatives", "medium"),
            ("L'Hôpital's rule", "hard"),
            ("Taylor series expansion", "very_hard"),
        ]
        
        for i in range(n):
            topic, difficulty = random.choice(math_topics)
            
            prompt = f"Explain the proof of {topic}."
            
            response = {
                "difficulty": difficulty,
                "difficulty_score": {"easy": 25, "medium": 50, "hard": 75, "very_hard": 90}[difficulty],
                "reasoning_summary": [
                    "Reasoning type: multi-step logical proof",
                    "Context depth: high (requires prerequisite knowledge)",
                    "Cross-domain: mathematics",
                    "Topic specification: clear",
                    "Precision correctness: critical"
                ],
                "sources": ["textbook:calculus_fundamentals", "ocw:18.01"],
                "confidence": 0.85 + random.random() * 0.1,
                "verification_checks": [
                    "Symbolic verification using SymPy",
                    "Cross-reference with standard textbook"
                ],
            }
            
            examples.append(SyntheticExample(
                prompt=prompt,
                response=json.dumps(response),
                difficulty_label=difficulty,
                reasoning_signals=["multi_step", "high_depth", "correctness_critical"],
                sources=response["sources"],
                confidence=response["confidence"],
                source_id="synthetic_math",
                snippet_id=f"math_proof_{i}"
            ))
        
        return examples
    
    def generate_code_task_examples(self, n: int = 50) -> List[SyntheticExample]:
        """Generate programming task examples"""
        examples = []
        
        code_tasks = [
            ("Implement a binary search", "medium"),
            ("Write a quicksort algorithm", "hard"),
            ("Create a REST API endpoint", "medium"),
            ("Design a distributed cache system", "very_hard"),
            ("Implement a hash table", "hard"),
            ("Write unit tests", "easy"),
        ]
        
        for i in range(n):
            task, difficulty = random.choice(code_tasks)
            
            prompt = f"What is the difficulty of implementing: {task}?"
            
            response = {
                "difficulty": difficulty,
                "difficulty_score": {"easy": 25, "medium": 50, "hard": 75, "very_hard": 90}[difficulty],
                "reasoning_summary": [
                    "Reasoning type: algorithmic problem-solving",
                    "Context depth: medium to high",
                    "Cross-domain: computer science",
                    "Topic specification: clear",
                    "Precision correctness: important"
                ],
                "sources": ["textbook:algorithms_intro", "ocw:6.006"],
                "confidence": 0.80 + random.random() * 0.15,
                "verification_checks": [
                    "Code review checklist",
                    "Unit test coverage"
                ],
            }
            
            examples.append(SyntheticExample(
                prompt=prompt,
                response=json.dumps(response),
                difficulty_label=difficulty,
                reasoning_signals=["multi_step", "high_depth"] if difficulty in ["hard", "very_hard"] else ["conceptual"],
                sources=response["sources"],
                confidence=response["confidence"],
                source_id="synthetic_code",
                snippet_id=f"code_task_{i}"
            ))
        
        return examples
    
    def generate_study_planning_examples(self, n: int = 50) -> List[SyntheticExample]:
        """Generate study planning dialogue examples"""
        examples = []
        
        study_scenarios = [
            ("How should I prepare for a calculus exam?", "medium"),
            ("What's the best way to learn a new programming language?", "easy"),
            ("How do I balance multiple difficult courses?", "hard"),
            ("What study techniques work for memorization?", "easy"),
            ("How to approach a research paper?", "very_hard"),
        ]
        
        for i in range(n):
            scenario, difficulty = random.choice(study_scenarios)
            
            prompt = scenario
            
            response = {
                "difficulty": difficulty,
                "difficulty_score": {"easy": 25, "medium": 50, "hard": 75, "very_hard": 90}[difficulty],
                "reasoning_summary": [
                    "Reasoning type: strategic planning",
                    "Context depth: medium",
                    "Cross-domain: learning science",
                    "Topic specification: contextual",
                    "Precision correctness: moderate"
                ],
                "sources": ["textbook:learning_science", "ocw:9.00"],
                "confidence": 0.75 + random.random() * 0.2,
                "verification_checks": [
                    "Review with study plan templates",
                    "Validate against learning science research"
                ],
            }
            
            examples.append(SyntheticExample(
                prompt=prompt,
                response=json.dumps(response),
                difficulty_label=difficulty,
                reasoning_signals=["conceptual", "cross_domain"],
                sources=response["sources"],
                confidence=response["confidence"],
                source_id="synthetic_study",
                snippet_id=f"study_planning_{i}"
            ))
        
        return examples
    
    def generate_all(self, output_path: Path):
        """Generate all synthetic examples and save"""
        all_examples = []
        
        all_examples.extend(self.generate_math_proof_examples(50))
        all_examples.extend(self.generate_code_task_examples(50))
        all_examples.extend(self.generate_study_planning_examples(50))
        
        # Convert to dict format
        output_data = []
        for ex in all_examples:
            output_data.append({
                "prompt": ex.prompt,
                "response": ex.response,
                "difficulty_label": ex.difficulty_label,
                "reasoning_signals": ex.reasoning_signals,
                "sources": ex.sources,
                "confidence": ex.confidence,
                "source_id": ex.source_id,
                "snippet_id": ex.snippet_id,
                "metadata": {
                    "synthetic": True,
                    "generator": "synthetic_generator"
                }
            })
        
        # Save as JSONL
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            for item in output_data:
                f.write(json.dumps(item) + "\n")
        
        print(f"Generated {len(output_data)} synthetic examples to {output_path}")


if __name__ == "__main__":
    generator = SyntheticDataGenerator()
    output_path = Path("data/raw/synthetic.jsonl")
    generator.generate_all(output_path)

