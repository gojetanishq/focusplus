#!/usr/bin/env python3
"""
Data Labeling Pipeline for Apox Engine
Processes raw data and creates labeled training examples.
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
import argparse

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class TrainingExample:
    """Structured training example"""
    prompt: str
    response: str
    difficulty_label: str  # easy, medium, hard, very_hard
    reasoning_signals: List[str]  # multi_step, high_depth, cross_domain, ambiguous, correctness_critical
    sources: List[str]
    confidence_label: float  # 0.0 to 1.0
    provenance: Dict[str, Any]
    
    def to_dict(self):
        return asdict(self)
    
    def to_jsonl(self) -> str:
        return json.dumps(self.to_dict())


class LabelingPipeline:
    """Pipeline for labeling training data"""
    
    def __init__(self):
        self.examples: List[TrainingExample] = []
    
    def process_raw_data(self, raw_data_path: Path) -> List[Dict]:
        """Load raw data files"""
        examples = []
        
        if raw_data_path.suffix == ".jsonl":
            with open(raw_data_path, "r") as f:
                for line in f:
                    examples.append(json.loads(line))
        elif raw_data_path.suffix == ".json":
            with open(raw_data_path, "r") as f:
                data = json.load(f)
                if isinstance(data, list):
                    examples = data
                else:
                    examples = [data]
        
        return examples
    
    def extract_difficulty_label(self, content: str, metadata: Dict) -> str:
        """Extract difficulty label from content and metadata"""
        content_lower = content.lower()
        
        # Keyword-based heuristics (can be replaced with ML classifier)
        if any(word in content_lower for word in ["advanced", "complex", "proof", "theorem", "derivation"]):
            if any(word in content_lower for word in ["multi", "multiple", "several", "many"]):
                return "very_hard"
            return "hard"
        elif any(word in content_lower for word in ["basic", "simple", "intro", "fundamental"]):
            return "easy"
        else:
            return "medium"
    
    def extract_reasoning_signals(self, content: str, metadata: Dict) -> List[str]:
        """Extract reasoning signals"""
        signals = []
        content_lower = content.lower()
        
        if any(word in content_lower for word in ["step", "steps", "multi-step", "procedure"]):
            signals.append("multi_step")
        
        if any(word in content_lower for word in ["deep", "depth", "prerequisite", "foundation"]):
            signals.append("high_depth")
        
        if any(word in content_lower for word in ["domain", "cross", "interdisciplinary", "combine"]):
            signals.append("cross_domain")
        
        if any(word in content_lower for word in ["ambiguous", "unclear", "vague", "interpret"]):
            signals.append("ambiguous")
        
        if any(word in content_lower for word in ["precise", "exact", "correct", "accurate", "critical"]):
            signals.append("correctness_critical")
        
        return signals if signals else ["conceptual"]
    
    def create_training_example(
        self,
        raw_example: Dict,
        source_id: str,
        snippet_id: str
    ) -> TrainingExample:
        """Create a training example from raw data"""
        
        # Extract fields
        prompt = raw_example.get("prompt", raw_example.get("question", ""))
        response = raw_example.get("response", raw_example.get("answer", ""))
        
        # Generate structured response if needed
        if not response.startswith("{"):
            difficulty_label = self.extract_difficulty_label(
                prompt + " " + response,
                raw_example.get("metadata", {})
            )
            reasoning_signals = self.extract_reasoning_signals(
                prompt + " " + response,
                raw_example.get("metadata", {})
            )
            
            # Create structured JSON response
            structured_response = {
                "difficulty": difficulty_label,
                "difficulty_score": self._score_from_label(difficulty_label),
                "reasoning_summary": [
                    f"Reasoning type: {signal.replace('_', ' ')}"
                    for signal in reasoning_signals
                ],
                "sources": raw_example.get("sources", [source_id]),
                "confidence": raw_example.get("confidence", 0.8),
                "verification_checks": raw_example.get("verification_checks", []),
            }
            response = json.dumps(structured_response)
        else:
            # Parse existing structured response
            structured_response = json.loads(response)
            difficulty_label = structured_response.get("difficulty", "medium")
            reasoning_signals = self.extract_reasoning_signals(
                prompt + " " + response,
                raw_example.get("metadata", {})
            )
        
        return TrainingExample(
            prompt=prompt,
            response=response,
            difficulty_label=difficulty_label,
            reasoning_signals=reasoning_signals,
            sources=raw_example.get("sources", [source_id]),
            confidence_label=raw_example.get("confidence", 0.8),
            provenance={
                "source_ids": [source_id],
                "snippet_ids": [snippet_id],
                "training_example_id": f"example_{len(self.examples)}"
            }
        )
    
    def _score_from_label(self, label: str) -> int:
        """Convert label to score"""
        mapping = {
            "easy": 20,
            "medium": 50,
            "hard": 75,
            "very_hard": 90
        }
        return mapping.get(label, 50)
    
    def process_directory(self, input_dir: Path, output_dir: Path):
        """Process all files in input directory"""
        output_dir.mkdir(parents=True, exist_ok=True)
        
        all_examples = []
        
        # Process all JSON/JSONL files
        for file_path in input_dir.glob("*.json*"):
            logger.info(f"Processing {file_path}")
            raw_examples = self.process_raw_data(file_path)
            
            for idx, raw_example in enumerate(raw_examples):
                source_id = raw_example.get("source_id", file_path.stem)
                snippet_id = raw_example.get("snippet_id", f"{file_path.stem}_{idx}")
                
                example = self.create_training_example(raw_example, source_id, snippet_id)
                all_examples.append(example)
        
        # Split into train/val/test (80/10/10)
        total = len(all_examples)
        train_end = int(total * 0.8)
        val_end = int(total * 0.9)
        
        train_examples = all_examples[:train_end]
        val_examples = all_examples[train_end:val_end]
        test_examples = all_examples[val_end:]
        
        # Save splits
        for split_name, examples in [
            ("train", train_examples),
            ("val", val_examples),
            ("test", test_examples)
        ]:
            output_path = output_dir / f"{split_name}.jsonl"
            with open(output_path, "w") as f:
                for example in examples:
                    f.write(example.to_jsonl() + "\n")
            logger.info(f"Saved {len(examples)} examples to {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Label training data")
    parser.add_argument("--input", type=str, required=True, help="Input directory")
    parser.add_argument("--output", type=str, required=True, help="Output directory")
    
    args = parser.parse_args()
    
    pipeline = LabelingPipeline()
    pipeline.process_directory(Path(args.input), Path(args.output))
    
    logger.info("Labeling complete!")


if __name__ == "__main__":
    main()

