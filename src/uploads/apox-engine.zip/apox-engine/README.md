# Apox Engine: Production-Grade LLM Training & Fine-Tuning Pipeline

A comprehensive training and fine-tuning pipeline for an explainable LLM tailored to student productivity applications.

## 🎯 Purpose

The Apox Engine produces trained/fine-tuned models capable of:
- **Difficulty Classification**: Classify topic difficulty with explainable rationale (JSON schema)
- **Explainable Chatbot**: Generate explainable difficulty responses for chatbot use
- **File Summarization**: Summarize student files (PDFs/notes) and extract topic tags
- **Verification**: Provide verification routines (symbolic checks, worked examples)

## 📦 Output Artifacts

- Model weights or LoRA adapters
- Training data snapshots
- Evaluation reports
- Explainability logs
- Deployment container
- Documentation

## 🚀 Quick Start

### Prerequisites

```bash
# Python 3.9+
python --version

# Install dependencies
pip install -r requirements.txt

# Install CUDA toolkit for GPU training (optional)
# See docs/deployment/CUDA_SETUP.md
```

### Local Development

```bash
# 1. Start data ingestion
python ingest/run_ingestion.py --source ocw --output data/raw

# 2. Process and label data
python ingest/processors/labeling_pipeline.py --input data/raw --output data/labeled

# 3. Train model (LoRA example)
python train/scripts/train_lora.py --config train/configs/lora_config.yaml

# 4. Evaluate model
python tests/integration/evaluate_model.py --model-path models/lora_adapter --test-set data/test

# 5. Start API server
cd serve && python api/server.py --port 8000

# 6. Run tests
pytest tests/
```

### Docker Deployment

```bash
# Build image
docker build -t apox-engine:latest .

# Run with docker-compose
docker-compose up -d

# Check logs
docker-compose logs -f api
```

## 📁 Project Structure

```
apox-engine/
├── train/              # Training pipeline
│   ├── configs/        # Training configurations
│   ├── scripts/        # Training scripts
│   └── models/         # Model checkpoints
├── serve/              # API server
│   ├── api/           # FastAPI endpoints
│   ├── models/        # Model loading utilities
│   └── utils/         # Helper functions
├── ingest/             # Data ingestion
│   ├── sources/       # Data source handlers
│   ├── processors/    # Data processing pipelines
│   └── labeling/      # Labeling workflows
├── notebooks/          # Jupyter notebooks
│   ├── exploration/   # Data exploration
│   └── verification/   # Verification examples
├── tests/              # Test suites
│   ├── unit/          # Unit tests
│   ├── integration/   # Integration tests
│   └── e2e/           # End-to-end tests
├── docs/               # Documentation
│   ├── api/           # API documentation
│   └── deployment/    # Deployment guides
└── admin-ui/           # Admin web interface
```

## 🔧 Configuration

### Training Modes

**LoRA Fine-Tuning** (Recommended for large models):
```yaml
# train/configs/lora_config.yaml
model_name: "meta-llama/Llama-2-7b-hf"
lora_rank: 8
lora_alpha: 16
lora_dropout: 0.1
learning_rate: 3e-4
batch_size: 32
gradient_accumulation_steps: 4
```

**Full Fine-Tuning** (For small/medium models):
```yaml
# train/configs/full_config.yaml
model_name: "microsoft/DialoGPT-medium"
learning_rate: 1e-5
batch_size: 16
weight_decay: 0.01
epochs: 3
```

## 📊 Data Pipeline

### Supported Sources

- **MIT/Stanford OCW**: Open courseware materials
- **Public Domain Textbooks**: Curated educational content
- **Teacher-Uploaded Materials**: Custom content
- **Synthetic Examples**: Generated training data
- **Student Reviews**: Feedback integration

### Data Format

Each training example includes:
```json
{
  "prompt": "What is the difficulty of multivariable calculus?",
  "response": "{\"difficulty\": \"hard\", \"reasoning\": [...]}",
  "difficulty_label": "hard",
  "reasoning_signals": ["multi_step", "high_depth", "cross_domain"],
  "sources": ["ocw:18.02", "textbook:thomas_calculus"],
  "confidence_label": 0.9,
  "provenance": {
    "source_ids": ["ocw_18.02_ch3"],
    "snippet_ids": ["snippet_123", "snippet_456"]
  }
}
```

## 🔍 Explainability

The engine provides:
- **Provenance Tracking**: Track which sources influenced each response
- **Saliency Maps**: Token-level importance visualization
- **Reasoning Signals**: Map to 5 core signals (reasoning type, depth, cross-domain, ambiguity, correctness)
- **Top-K Examples**: Retrieve similar training examples

## 🧪 Evaluation

Run comprehensive evaluation:
```bash
python tests/integration/evaluate_model.py \
  --model-path models/lora_adapter \
  --test-set data/test \
  --metrics accuracy,f1,calibration,explainability
```

Metrics include:
- Classification: Accuracy, F1, Confusion Matrix
- Calibration: Expected Calibration Error
- Explainability: Precision@K for source attribution
- Verification: Symbolic checks (SymPy for math)

## 🌐 API Endpoints

### POST /ai/difficulty
Classify topic difficulty with explainability.

**Request:**
```json
{
  "topicText": "Multivariable calculus integration",
  "userId": "user_123",
  "uploadedFiles": []
}
```

**Response:**
```json
{
  "difficulty": "hard",
  "difficulty_score": 85,
  "reasoning_summary": [...],
  "sources": [...],
  "confidence": 0.92,
  "verification_checks": [...],
  "provenance": {...}
}
```

### POST /ai/chat
Chat with explainable responses.

**Request:**
```json
{
  "prompt": "Explain multivariable integration",
  "contextChunks": []
}
```

**Response:**
```json
{
  "answer": "...",
  "provenance": {...},
  "sources": [...],
  "confidence": 0.88
}
```

### POST /ai/verify
Run verification jobs asynchronously.

**Request:**
```json
{
  "jobSpec": {
    "type": "symbolic_check",
    "content": "∫∫ x^2 + y^2 dx dy"
  }
}
```

**Response:**
```json
{
  "job_id": "job_123",
  "status": "pending"
}
```

## 🔄 Student Feedback Loop

Collect and integrate student feedback:

```bash
# Submit feedback
curl -X POST http://localhost:8000/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "response_id": "resp_123",
    "rating": 3,
    "disagreement": "Difficulty was too high",
    "user_id": "user_456"
  }'

# Trigger retraining (admin)
python train/scripts/retrain_from_feedback.py \
  --feedback-db feedback.db \
  --output models/retrained_adapter
```

## 🔒 Safety & Privacy

- **PII Redaction**: Automatic detection and redaction
- **Content Filtering**: Moderation layer for disallowed content
- **Privacy Flags**: Mark private resources in provenance
- **Consent Management**: Data retention policies

## 📚 Documentation

- [API Documentation](docs/api/OPENAPI.md)
- [Deployment Guide](docs/deployment/DEPLOYMENT.md)
- [Training Guide](docs/TRAINING.md)
- [Evaluation Guide](docs/EVALUATION.md)

## 🎓 Example Notebooks

- `notebooks/exploration/data_analysis.ipynb`: Explore training data
- `notebooks/exploration/saliency_visualization.ipynb`: Visualize model attention
- `notebooks/verification/symbolic_checks.ipynb`: Run verification examples

## 🚦 Moving to Production

See [docs/deployment/PRODUCTION_CHECKLIST.md](docs/deployment/PRODUCTION_CHECKLIST.md) for:
- Infrastructure setup
- Monitoring and logging
- Scaling considerations
- Security hardening

## 📝 License

MIT License - See LICENSE file

## 🤝 Contributing

See CONTRIBUTING.md for guidelines.

