# Apox Engine Quick Start Guide

Get up and running with Apox Engine in minutes!

## Prerequisites

- Python 3.9+
- Docker (optional, for containerized deployment)
- GPU (optional, for training)

## Step 1: Install Dependencies

```bash
cd apox-engine
pip install -r requirements.txt
```

## Step 2: Generate Sample Data

```bash
# Generate synthetic training data
python ingest/sources/synthetic_generator.py

# Process and label the data
python ingest/processors/labeling_pipeline.py \
  --input data/raw \
  --output data/labeled
```

## Step 3: Train a Model (Optional)

```bash
# Train with LoRA (recommended for large models)
python train/scripts/train_lora.py --config train/configs/lora_config.yaml

# Or train with full fine-tuning (for small models)
python train/scripts/train_full.py --config train/configs/full_config.yaml
```

## Step 4: Start the API Server

```bash
# Set environment variables
export MODEL_PATH=models/lora_adapter
export PORT=8000

# Start server
cd serve && python api/server.py
```

Or use Docker:

```bash
docker-compose up -d
```

## Step 5: Test the API

```bash
# Health check
curl http://localhost:8000/health

# Classify difficulty
curl -X POST http://localhost:8000/ai/difficulty \
  -H "Content-Type: application/json" \
  -d '{"topicText": "Multivariable calculus integration"}'

# Chat
curl -X POST http://localhost:8000/ai/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Explain multivariable integration"}'
```

## Step 6: Integrate with Frontend

Update your frontend to use the Apox API:

```typescript
import { apoxApi } from '@/services/apoxApi';

// Classify difficulty
const result = await apoxApi.classifyDifficulty("Multivariable calculus");

// Chat
const response = await apoxApi.chat("Explain integration");
```

## Next Steps

- Read the [full documentation](README.md)
- Explore [notebooks](notebooks/)
- Check [deployment guide](docs/deployment/DEPLOYMENT.md)
- Review [API documentation](docs/api/OPENAPI.md)

## Troubleshooting

### API not responding
- Check if server is running: `curl http://localhost:8000/health`
- Check logs: `docker-compose logs api`

### Model not loading
- Verify MODEL_PATH is correct
- Check if model files exist
- Ensure sufficient disk space

### Training fails
- Check GPU availability: `nvidia-smi`
- Reduce batch size in config
- Check available memory

## Getting Help

- Check [documentation](docs/)
- Open an [issue](https://github.com/your-repo/issues)
- Contact maintainers

