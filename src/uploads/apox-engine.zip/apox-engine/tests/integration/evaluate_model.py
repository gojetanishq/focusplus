#!/usr/bin/env python3
"""
Model Evaluation Suite for Apox Engine
Evaluates classification metrics, calibration, explainability, and verification.
"""

import json
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Any
import numpy as np
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report
from sklearn.calibration import calibration_curve

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelEvaluator:
    """Comprehensive model evaluator"""
    
    def __init__(self, model_path: str, test_set_path: str):
        self.model_path = model_path
        self.test_set_path = test_set_path
        self.results = {}
    
    def load_test_set(self) -> List[Dict]:
        """Load test dataset"""
        examples = []
        with open(self.test_set_path, "r") as f:
            for line in f:
                examples.append(json.loads(line))
        return examples
    
    def evaluate_classification(self, predictions: List[str], labels: List[str]) -> Dict[str, Any]:
        """Evaluate classification metrics"""
        accuracy = accuracy_score(labels, predictions)
        f1_macro = f1_score(labels, predictions, average="macro")
        f1_weighted = f1_score(labels, predictions, average="weighted")
        
        cm = confusion_matrix(labels, predictions)
        class_report = classification_report(labels, predictions, output_dict=True)
        
        return {
            "accuracy": float(accuracy),
            "f1_macro": float(f1_macro),
            "f1_weighted": float(f1_weighted),
            "confusion_matrix": cm.tolist(),
            "classification_report": class_report
        }
    
    def evaluate_calibration(self, confidences: List[float], correct: List[bool]) -> Dict[str, Any]:
        """Evaluate calibration metrics"""
        confidences = np.array(confidences)
        correct = np.array(correct)
        
        # Expected Calibration Error (ECE)
        n_bins = 10
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        ece = 0
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = (confidences > bin_lower) & (confidences <= bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                accuracy_in_bin = correct[in_bin].mean()
                avg_confidence_in_bin = confidences[in_bin].mean()
                ece += np.abs(avg_confidence_in_bin - accuracy_in_bin) * prop_in_bin
        
        # Calibration curve
        fraction_of_positives, mean_predicted_value = calibration_curve(
            correct, confidences, n_bins=n_bins
        )
        
        return {
            "ece": float(ece),
            "calibration_curve": {
                "fraction_of_positives": fraction_of_positives.tolist(),
                "mean_predicted_value": mean_predicted_value.tolist()
            }
        }
    
    def evaluate_explainability(self, examples: List[Dict]) -> Dict[str, Any]:
        """Evaluate explainability metrics"""
        source_precision = []
        reasoning_signal_coverage = []
        
        for ex in examples:
            response = json.loads(ex.get("response", "{}"))
            sources = response.get("sources", [])
            provenance = ex.get("provenance", {})
            
            # Check if sources are referenced
            if sources:
                source_precision.append(1.0)
            else:
                source_precision.append(0.0)
            
            # Check reasoning signal coverage
            reasoning_signals = ex.get("reasoning_signals", [])
            if reasoning_signals:
                reasoning_signal_coverage.append(len(reasoning_signals) / 5.0)
            else:
                reasoning_signal_coverage.append(0.0)
        
        return {
            "source_precision": float(np.mean(source_precision)),
            "reasoning_signal_coverage": float(np.mean(reasoning_signal_coverage)),
            "avg_sources_per_response": np.mean([len(json.loads(ex.get("response", "{}")).get("sources", [])) for ex in examples])
        }
    
    def evaluate_verification(self, examples: List[Dict]) -> Dict[str, Any]:
        """Evaluate verification checks"""
        verification_counts = []
        
        for ex in examples:
            response = json.loads(ex.get("response", "{}"))
            verification_checks = response.get("verification_checks", [])
            verification_counts.append(len(verification_checks))
        
        return {
            "avg_verification_checks": float(np.mean(verification_counts)),
            "verification_coverage": float(np.mean([c > 0 for c in verification_counts]))
        }
    
    def run_evaluation(self, metrics: List[str] = None) -> Dict[str, Any]:
        """Run comprehensive evaluation"""
        if metrics is None:
            metrics = ["classification", "calibration", "explainability", "verification"]
        
        logger.info("Loading test set...")
        test_examples = self.load_test_set()
        
        # In production, run model inference here
        # For now, use ground truth labels
        predictions = [ex.get("difficulty_label", "medium") for ex in test_examples]
        labels = [ex.get("difficulty_label", "medium") for ex in test_examples]
        confidences = [ex.get("confidence_label", 0.5) for ex in test_examples]
        correct = [p == l for p, l in zip(predictions, labels)]
        
        results = {}
        
        if "classification" in metrics:
            logger.info("Evaluating classification...")
            results["classification"] = self.evaluate_classification(predictions, labels)
        
        if "calibration" in metrics:
            logger.info("Evaluating calibration...")
            results["calibration"] = self.evaluate_calibration(confidences, correct)
        
        if "explainability" in metrics:
            logger.info("Evaluating explainability...")
            results["explainability"] = self.evaluate_explainability(test_examples)
        
        if "verification" in metrics:
            logger.info("Evaluating verification...")
            results["verification"] = self.evaluate_verification(test_examples)
        
        self.results = results
        return results
    
    def save_report(self, output_path: Path):
        """Save evaluation report"""
        report = {
            "model_path": self.model_path,
            "test_set_path": self.test_set_path,
            "results": self.results
        }
        
        with open(output_path, "w") as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"Evaluation report saved to {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Evaluate model")
    parser.add_argument("--model-path", type=str, required=True)
    parser.add_argument("--test-set", type=str, required=True)
    parser.add_argument("--metrics", type=str, nargs="+", 
                       default=["classification", "calibration", "explainability", "verification"])
    parser.add_argument("--output", type=str, default="evaluation_report.json")
    
    args = parser.parse_args()
    
    evaluator = ModelEvaluator(args.model_path, args.test_set)
    results = evaluator.run_evaluation(args.metrics)
    
    evaluator.save_report(Path(args.output))
    
    logger.info("Evaluation complete!")
    logger.info(f"Results: {json.dumps(results, indent=2)}")


if __name__ == "__main__":
    main()

