#!/usr/bin/env python3
"""
Simple test script for Apox Engine API
Tests all endpoints to verify functionality
"""

import requests
import json
import sys
from typing import Dict, Any

API_BASE_URL = "http://localhost:8000"


def test_health() -> bool:
    """Test health endpoint"""
    print("Testing /health endpoint...")
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Health check passed: {data}")
            return True
        else:
            print(f"❌ Health check failed: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API. Is the server running?")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def test_difficulty() -> bool:
    """Test difficulty classification endpoint"""
    print("\nTesting /ai/difficulty endpoint...")
    try:
        payload = {
            "topicText": "Multivariable calculus integration",
            "userId": "test_user",
            "uploadedFiles": []
        }
        response = requests.post(
            f"{API_BASE_URL}/ai/difficulty",
            json=payload,
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Difficulty classification successful:")
            print(f"   Difficulty: {data.get('difficulty')}")
            print(f"   Score: {data.get('difficulty_score')}")
            print(f"   Confidence: {data.get('confidence')}")
            print(f"   Sources: {len(data.get('sources', []))}")
            return True
        else:
            print(f"❌ Difficulty classification failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def test_chat() -> bool:
    """Test chat endpoint"""
    print("\nTesting /ai/chat endpoint...")
    try:
        payload = {
            "prompt": "Explain multivariable integration",
            "contextChunks": []
        }
        response = requests.post(
            f"{API_BASE_URL}/ai/chat",
            json=payload,
            timeout=30
        )
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Chat successful:")
            print(f"   Answer length: {len(data.get('answer', ''))}")
            print(f"   Confidence: {data.get('confidence')}")
            print(f"   Sources: {len(data.get('sources', []))}")
            return True
        else:
            print(f"❌ Chat failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def test_feedback() -> bool:
    """Test feedback endpoint"""
    print("\nTesting /api/feedback endpoint...")
    try:
        payload = {
            "response_id": "test_resp_123",
            "rating": 4,
            "disagreement": "Test feedback",
            "user_id": "test_user"
        }
        response = requests.post(
            f"{API_BASE_URL}/api/feedback",
            json=payload,
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Feedback submission successful: {data}")
            return True
        else:
            print(f"❌ Feedback submission failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def main():
    """Run all tests"""
    print("=" * 50)
    print("Apox Engine API Test Suite")
    print("=" * 50)
    
    results = []
    
    # Test health
    results.append(("Health Check", test_health()))
    
    # Test difficulty (may fail if model not loaded)
    results.append(("Difficulty Classification", test_difficulty()))
    
    # Test chat (may fail if model not loaded)
    results.append(("Chat", test_chat()))
    
    # Test feedback
    results.append(("Feedback Submission", test_feedback()))
    
    # Summary
    print("\n" + "=" * 50)
    print("Test Summary")
    print("=" * 50)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
        return 0
    else:
        print("⚠️  Some tests failed. Check API server and model loading.")
        return 1


if __name__ == "__main__":
    sys.exit(main())

